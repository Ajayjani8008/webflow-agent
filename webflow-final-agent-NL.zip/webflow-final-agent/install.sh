#!/bin/bash
# Webflow Agent OS v2.0 — Single-File Installer
set -e

PACK="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "=== Webflow Agent OS v2.0 Installer ==="
echo "Source: $PACK"
echo ""

# Copy CLAUDE.md to project root
cp "$PACK/CLAUDE.md" "$PWD/CLAUDE.md"
echo "✓ Copied CLAUDE.md → $PWD/CLAUDE.md"

# Copy docs (registries)
if [ -d "$PWD/docs" ]; then
  echo "  docs/ directory exists — skipping (registries are created by the agent)"
else
  mkdir -p "$PWD/docs/memory" "$PWD/docs/FR" "$PWD/docs/decisions"
  echo "✓ Created docs/ structure"
fi

# Merge .claude/settings if exists
if [ -f "$PWD/.claude/settings.json" ]; then
  echo "  .claude/settings.json exists — skipping (merge manually if needed)"
else
  mkdir -p "$PWD/.claude"
  cp "$PACK/.claude/settings.json" "$PWD/.claude/settings.json"
  echo "✓ Copied .claude/settings.json"
fi

echo ""
echo "=== Done. ==="
echo "CLAUDE.md is ready in your project. Add your WEBFLOW_TOKEN to .claude/settings.json and restart Claude Code."

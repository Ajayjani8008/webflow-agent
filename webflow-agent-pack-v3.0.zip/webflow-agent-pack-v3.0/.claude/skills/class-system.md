---
name: class-system
description: Complete Webflow class naming convention, BEM rules, utility classes, combo class patterns, and common class catalogue for all agents to reference.
---

# Webflow Class System Reference

---

## Naming Convention

```
[block]                         Section/component root
[block]__[element]              Child of block
[block]__[element]--[modifier]  State or variant
```

All lowercase, kebab-case, no underscores except BEM separators.

---

## Global Structure Classes

```css
.container        { max-width: 1200px; margin: 0 auto; padding: 0 var(--space-lg); }
.container--wide  { max-width: 1440px; }
.container--narrow { max-width: 800px; }
.section-pad      { padding: var(--space-5xl) 0; }
.section-pad--sm  { padding: var(--space-3xl) 0; }
.section-pad--lg  { padding: var(--space-6xl) 0; }
```

---

## Button Classes

```css
.btn              { base: inline-flex, align-center, border-radius var(--radius-md), font-weight 600 }
.btn--primary     { background: var(--color-primary), color: white }
.btn--outline     { border: 2px solid var(--color-primary), color: var(--color-primary) }
.btn--ghost       { color: var(--color-primary), no background }
.btn--dark        { background: var(--color-text), color: white }
.btn--sm          { padding: var(--space-sm) var(--space-md), font-size: var(--font-size-sm) }
.btn--lg          { padding: var(--space-md) var(--space-2xl), font-size: var(--font-size-lg) }
.btn--full        { width: 100% }
```

---

## Typography Classes

```css
.eyebrow          { font-size: var(--font-size-xs), font-weight: 600, letter-spacing: 0.1em, text-transform: uppercase, color: var(--color-primary) }
.lead             { font-size: var(--font-size-lg), font-weight: 400, color: var(--color-text-muted) }
.caption          { font-size: var(--font-size-sm), color: var(--color-text-muted) }
.label            { font-size: var(--font-size-xs), font-weight: 600, color: var(--color-text-muted) }
.balance          { text-wrap: balance } /* on headings */
```

---

## Common Section Classes

```
.hero                    Full-viewport or large hero section
.hero__inner             Flex container inside hero
.hero__content           Text/CTA side of hero
.hero__media             Image/video side of hero
.hero__title             H1 heading
.hero__subtitle          Supporting text under H1
.hero__cta               Primary CTA button
.hero__cta-group         Wrapper for multiple CTAs

.section-header          Eyebrow + heading + subtitle block
.section-header__eyebrow Small uppercase label
.section-header__title   H2 heading
.section-header__subtitle Lead paragraph

.cards-grid              Grid of cards
.cards-grid__list        The grid itself (display: grid)
.cards-grid__item        Alias for card (if non-symbol)

.card                    Generic card block
.card__image             Card top image
.card__body              Card content area
.card__tag               Category/label pill
.card__title             H3 card heading
.card__description       Card body text
.card__meta              Date, author, or metadata line
.card__footer            Bottom area (CTA, price)
.card__cta               Card link/button
.card--featured          Featured variant

.features-list           List of feature items (icon + text)
.feature                 Single feature item
.feature__icon           Icon (image or SVG embed)
.feature__title          Feature name
.feature__description    Feature description

.testimonials            Testimonials section
.testimonial             Single testimonial
.testimonial__quote      Quote text
.testimonial__author     Author info wrapper
.testimonial__photo      Author photo
.testimonial__name       Author name
.testimonial__role       Author title/company

.cta-section             Full-width CTA banner
.cta-section__inner      Centered content
.cta-section__title      CTA heading
.cta-section__subtitle   CTA supporting text
.cta-section__actions    Button group

.pricing-card            Pricing plan card
.pricing-card__badge     "Popular" or "Best Value" label
.pricing-card__price     Price display
.pricing-card__period    "/month" or similar
.pricing-card__features  Feature list
.pricing-card__cta       Sign up button
.pricing-card--featured  Highlighted plan

.faq                     FAQ section
.faq__list               FAQ items container
.faq__item               Single Q&A pair
.faq__question           Question (click trigger)
.faq__answer             Answer (initially hidden)

.stats                   Statistics bar/grid
.stat                    Single stat item
.stat__value             The number
.stat__label             What it measures

.form-block              Form wrapper section
.form__group             Field + label pair
.form__label             Input label
.form__input             Text input
.form__textarea          Textarea
.form__select            Dropdown
.form__submit            Submit button
.form__success           Success message
.form__error             Error message
```

---

## Nav Classes

```
.navbar              Nav wrapper (Webflow Navbar element)
.navbar__inner       Flex container inside nav
.nav__brand          Logo + site name area
.nav__logo           Logo image
.nav__site-name      Site name text
.nav__menu           Navigation links list
.nav__link           Individual nav link
.nav__link--active   Active/current page link
.nav__cta            CTA button in nav
.nav__hamburger      Mobile menu toggle
.nav--scrolled       Added via interaction when page scrolled
```

---

## Footer Classes

```
.footer              Footer element
.footer__inner       Grid/flex container
.footer__brand       Logo + tagline column
.footer__links       Nav links columns
.footer__column      Single column of links
.footer__column-title Column heading
.footer__link        Individual footer link
.footer__bottom      Copyright bar
.footer__copyright   Copyright text
.footer__legal       Legal links (Privacy, Terms)
.footer__social      Social icons row
.footer__social-link Individual social icon link
```

---

## Responsive Utility Classes

```
.hide-mobile          display: none at mobile
.hide-tablet          display: none at tablet
.show-mobile          display: none at desktop+, block at mobile
.text-center-mobile   text-align: center at mobile only
.full-width-mobile    width: 100% at mobile
```

---

## Combo Class Pattern

Webflow combo classes: first class is base, second is modifier.
In node `classes` array: base class first, modifier second.

```json
{ "classes": ["btn", "btn--primary"] }
{ "classes": ["card", "card--featured"] }
{ "classes": ["container", "container--narrow"] }
```

The base class (`btn`, `card`) defines the foundation.
The modifier (`btn--primary`) overrides specific properties.
Never put structural styles in modifier — only the differentiating property.

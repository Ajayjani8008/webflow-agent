---
name: figma-bridge
description: Complete conversion reference — Figma node types to Webflow elements, design token mapping, auto-layout to flex, CMS detection, and component detection rules.
---

# Figma → Webflow Bridge Reference

---

## Figma Node → Webflow Element

| Figma node type | Condition | Webflow element | Class hint |
|----------------|-----------|----------------|-----------|
| `FRAME` | Root, no fill | `section` | `[section-name]` |
| `FRAME` | `layoutMode=HORIZONTAL` | `div-block` flex-row | `[section]__row` |
| `FRAME` | `layoutMode=VERTICAL` | `div-block` flex-col | `[section]__col` |
| `FRAME` | `fill=IMAGE`, no children | `image` | `[section]__image` |
| `FRAME` | ≥2 children, same structure | Symbol candidate → `div-block` or CMS Collection item | `[name]-card` |
| `FRAME` | Contains button-like child | `link-block` | `[section]__cta` |
| `FRAME` | ≥3 same frames, editorial | CMS Collection List | — |
| `GROUP` | any | `div-block` | `[section]__group` |
| `TEXT` | fontSize ≥ 48 | `heading` H1 | `[section]__title` |
| `TEXT` | fontSize 36–47 | `heading` H2 | `section__heading` |
| `TEXT` | fontSize 28–35 | `heading` H3 | `card__title` |
| `TEXT` | fontSize 22–27 | `heading` H4 | `subsection__title` |
| `TEXT` | fontSize 16–21 | `paragraph` | `body-text` |
| `TEXT` | fontSize ≤ 15 | `text-span` | `caption` or `label` |
| `RECTANGLE` | fill=IMAGE | `image` | `[section]__image` |
| `RECTANGLE` | fill=SOLID | decorative `div-block` | CSS background |
| `VECTOR` / `ELLIPSE` | any | SVG embed or background | decorative |
| `INSTANCE` | known component | Symbol instance | reuse from component_registry |
| `INSTANCE` | unknown component | `div-block` | rebuild as Symbol |

---

## Auto-Layout → Webflow Flex

| Figma property | Webflow class style |
|---------------|---------------------|
| `layoutMode: HORIZONTAL` | `display: flex; flex-direction: row` |
| `layoutMode: VERTICAL` | `display: flex; flex-direction: column` |
| `primaryAxisAlignItems: CENTER` | `justify-content: center` |
| `primaryAxisAlignItems: MAX` | `justify-content: flex-end` |
| `primaryAxisAlignItems: SPACE_BETWEEN` | `justify-content: space-between` |
| `counterAxisAlignItems: CENTER` | `align-items: center` |
| `counterAxisAlignItems: MAX` | `align-items: flex-end` |
| `itemSpacing: N` | `gap: {variable}` |
| `paddingLeft = paddingRight = N` | `padding-left: {var}; padding-right: {var}` |
| `paddingTop = paddingBottom = N` | `padding-top: {var}; padding-bottom: {var}` |
| `layoutSizingHorizontal: FILL` | `width: 100%` |
| `layoutSizingHorizontal: HUG` | no width (fit-content) |
| Fixed width | `width: Npx` or `max-width: Npx` |

---

## Figma Color → Webflow Variable

```python
# Convert Figma RGBA (0–1 float) to hex
def figma_to_hex(r, g, b, a=1):
    return f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
```

Match to existing variable (±15 per channel):
```python
def matches_variable(hex_color, variable_hex, tolerance=15):
    r1,g1,b1 = int(hex_color[1:3],16), int(hex_color[3:5],16), int(hex_color[5:7],16)
    r2,g2,b2 = int(variable_hex[1:3],16), int(variable_hex[3:5],16), int(variable_hex[5:7],16)
    return abs(r1-r2)<=tolerance and abs(g1-g2)<=tolerance and abs(b1-b2)<=tolerance
```

Common matches:
| Figma hex range | Map to variable |
|----------------|----------------|
| Dark (#0a0a0a – #2a2a2a) | `--color-text` |
| Light (#f0f0f0 – #ffffff) | `--color-surface` |
| Medium gray (#8a8a8a – #aaaaaa) | `--color-text-muted` |
| Brand primary | `--color-primary` |
| Brand secondary | `--color-secondary` |

---

## Figma Spacing → Variable Scale

| Figma px | Nearest variable |
|---------|----------------|
| 2–6 | `--space-xs` (4px) |
| 6–12 | `--space-sm` (8px) |
| 12–20 | `--space-md` (16px) |
| 20–28 | `--space-lg` (24px) |
| 28–40 | `--space-xl` (32px) |
| 40–56 | `--space-2xl` (48px) |
| 56–80 | `--space-3xl` (64px) |
| 80–112 | `--space-4xl` (96px) |
| 112–160 | `--space-5xl` (128px) |
| >160 | `--space-6xl` (192px) or custom |

If Figma value is >15% off from nearest scale → flag as "custom variable needed".

---

## Figma Typography → Webflow Class Properties

| Figma fontSize | Variable | Webflow text size |
|--------------|---------|-----------------|
| 12 | `--font-size-xs` | 12px |
| 14 | `--font-size-sm` | 14px |
| 16 | `--font-size-md` | 16px |
| 18 | `--font-size-lg` | 18px |
| 20 | `--font-size-xl` | 20px |
| 24 | `--font-size-2xl` | 24px |
| 30 | `--font-size-3xl` | 30px |
| 36 | `--font-size-4xl` | 36px |
| 48 | `--font-size-5xl` | 48px |
| 60 | `--font-size-6xl` | 60px |
| 72 | `--font-size-7xl` | 72px |

| Figma fontWeight | CSS | Webflow font weight |
|-----------------|-----|---------------------|
| 300 | 300 | Light |
| 400 | 400 | Normal |
| 500 | 500 | Medium |
| 600 | 600 | Semi Bold |
| 700 | 700 | Bold |
| 800 | 800 | Extra Bold |

---

## CMS Detection Heuristics

A frame is a CMS Collection candidate if:
- ≥3 instances with same structure
- Contains text that would be written/updated by editors (not brand copy)
- Has an image that would change per item
- Would need its own detail page (blog posts, services, team members, products)

→ Create CMS Collection, bind via Collection List
→ Each item node → `collection-item` with `xattr` bindings

A frame is a Symbol candidate if:
- ≥2 instances, same structure
- Content may differ per instance (text overrides)
- NOT editorial (doesn't need CMS)

→ Create Webflow Symbol

A frame is one-off if:
- Appears once
- Content is brand/design (not editorial)
- No repeated pattern

→ Static div-block, no symbol

---

## Interaction Detection from Figma

| Figma indicator | Recommended interaction |
|----------------|------------------------|
| Variant with "Hover" state defined | Webflow Hover interaction |
| Multiple frames showing progressive reveal | Scroll Into View |
| Overlay or modal frame | Click → Show/Hide |
| Tab bar with multiple content frames | Webflow Tabs component |
| Arrow/chevron elements beside list | Accordion click interaction |
| "Loading" variant | Custom JS skeleton/spinner |

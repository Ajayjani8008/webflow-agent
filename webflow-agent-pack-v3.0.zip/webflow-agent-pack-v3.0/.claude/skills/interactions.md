---
name: interactions
description: Complete Webflow Interactions 2.0 reference — trigger types, animation properties, easing values, standard timing, and custom JS patterns.
---

# Webflow Interactions Reference

---

## Trigger Types

### Element-based triggers

| Trigger | Use case | Webflow UI label |
|---------|---------|----------------|
| Mouse click | Modals, accordions, tabs, toggles | "Mouse Click (Tap)" |
| Mouse hover | Card lifts, button states, tooltips | "Mouse Hover" |
| Mouse move | Cursor effects, parallax on hover | "Mouse Move in Element" |
| Scroll into view | Fade-in reveals, counters | "Scroll Into View" |
| Scroll out of view | Reverse reveals | "Scroll Out of View" |

### Page-based triggers

| Trigger | Use case | Webflow UI label |
|---------|---------|----------------|
| Page load | Intro animations | "Page Load" |
| Page scroll | Parallax, sticky nav change | "Page Scroll" |
| Page scroll into view | Section-specific parallax | "While Scrolling in View" |

---

## Animatable Properties

**GPU composited (use these — no layout reflow):**
- `opacity` (0 to 1)
- `transform: translateX/Y/Z()`
- `transform: scale()`
- `transform: rotate()`
- `filter: blur()`

**Layout-triggering (avoid in animations):**
- `width`, `height` — causes reflow
- `margin`, `padding` — causes reflow
- `top`, `left`, `right`, `bottom` — causes reflow
- `font-size` — causes reflow

Exception: height 0 → auto for accordions — acceptable but test performance.

---

## Easing Values

| Name | CSS | When to use |
|------|-----|------------|
| ease-out | `cubic-bezier(0, 0, 0.2, 1)` | Things appearing (reveals, hover in) |
| ease-in | `cubic-bezier(0.4, 0, 1, 1)` | Things disappearing (hover out) |
| ease-in-out | `cubic-bezier(0.4, 0, 0.2, 1)` | Bi-directional (page scroll parallax) |
| spring | Webflow spring preset | Playful/bouncy UIs |
| linear | `linear` | Progress bars, counters |

**Standard easing:** `ease-out` for 90% of use cases.

---

## Standard Timing

| Interaction type | Duration |
|----------------|---------|
| Hover in | 200ms |
| Hover out | 150ms (slightly faster than in) |
| Scroll reveal | 500ms |
| Page load step | 400–600ms |
| Accordion open | 300ms |
| Accordion close | 250ms |
| Modal appear | 250ms |
| Modal dismiss | 200ms |
| Stagger between items | 60–100ms |
| Parallax | continuous (no explicit duration) |

---

## Interaction Patterns — Step by Step

### Scroll reveal (most used)

Designer steps:
1. Select element or section (e.g., `.card`)
2. Add interaction → Scroll Into View
3. Set initial state: `opacity: 0`, `transform: translateY(24px)`
4. Set action: `opacity: 1`, `transform: translateY(0)`, duration 500ms, ease-out
5. If list: enable stagger, 80ms
6. Enable "Limit: once" (don't repeat on scroll up)

### Hover card lift

Designer steps:
1. Select `.card`
2. Add interaction → Mouse Hover
3. On hover:
   - `transform: translateY(-4px)` duration 200ms ease-out
   - `box-shadow: 0 12px 32px rgba(0,0,0,0.12)` duration 200ms
4. On hover out:
   - Reverse (or explicitly set translateY(0), shadow none), 150ms ease-in

### Sticky nav change on scroll

Designer steps:
1. Select `.navbar`
2. Add interaction → Page Scroll
3. Scroll position 80px:
   - Target: `.navbar`
   - Set `background-color: var(--color-surface)` (or white)
   - `box-shadow: 0 2px 16px rgba(0,0,0,0.08)`
   - Duration: 200ms
4. Scroll position 0px: reverse

### Accordion

Designer steps:
1. Wrap `.faq__question` + `.faq__answer` in `.faq__item`
2. Set `.faq__answer` initial: `height: 0px`, `opacity: 0`, `overflow: hidden`
3. Add interaction → Mouse Click on `.faq__question`
4. On click (open):
   - `.faq__answer`: `height: auto`, `opacity: 1`, 300ms ease-out
5. On click again (close):
   - `.faq__answer`: `height: 0px`, `opacity: 0`, 250ms ease-in
6. For multiple items: use "affect: siblings" or target specific child

### Page load hero sequence

Designer steps:
1. Add interaction → Page Load (on body or wrapper element)
2. Timeline:
   - 0ms: `.hero__title` start state: opacity 0, translateY 16px
   - 0ms: start action: opacity 1, translateY 0, 600ms ease-out
   - 150ms: `.hero__subtitle` opacity 0 → 1, translateY 12px → 0, 500ms ease-out
   - 300ms: `.hero__cta` opacity 0 → 1, scale 0.95 → 1, 400ms ease-out

---

## Custom JS Interactions

For interactions Webflow cannot do natively:

### Smooth anchor scroll
```javascript
window.Webflow = window.Webflow || [];
window.Webflow.push(function() {
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      const target = document.querySelector(a.getAttribute('href'));
      if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
});
```

### Counter animation (triggers on scroll into view)
```javascript
window.Webflow = window.Webflow || [];
window.Webflow.push(function() {
  const counters = document.querySelectorAll('[data-counter]');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseFloat(el.dataset.counter);
      const duration = 1500;
      const start = performance.now();
      const update = now => {
        const progress = Math.min((now - start) / duration, 1);
        const ease = 1 - Math.pow(1 - progress, 3); // ease-out cubic
        el.textContent = Math.round(ease * target).toLocaleString();
        if (progress < 1) requestAnimationFrame(update);
      };
      requestAnimationFrame(update);
      observer.unobserve(el);
    });
  }, { threshold: 0.5 });
  counters.forEach(el => {
    el.dataset.counter = el.textContent.replace(/[^0-9.]/g, '');
    el.textContent = '0';
    observer.observe(el);
  });
});
```

Usage: add `data-counter` attribute to any stat number element.

### CSS-only marquee
```css
@keyframes marquee {
  from { transform: translateX(0); }
  to   { transform: translateX(-50%); }
}
.marquee__track {
  display: flex;
  width: max-content;
  animation: marquee 30s linear infinite;
}
.marquee__track:hover { animation-play-state: paused; }
```

### Cursor follower
```javascript
window.Webflow = window.Webflow || [];
window.Webflow.push(function() {
  const cursor = document.querySelector('.cursor');
  if (!cursor) return;
  document.addEventListener('mousemove', e => {
    requestAnimationFrame(() => {
      cursor.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
    });
  });
});
```

---

## Mobile Interaction Rules

- Disable parallax effects at tablet/mobile (too slow on scroll)
- Scroll reveals: keep at mobile (users still need visual feedback)
- Hover interactions: Webflow auto-handles via tap on mobile (first tap = hover, second = click)
- Counter animations: keep (scroll-triggered, works fine on mobile)
- Custom cursor: hide at mobile (`.cursor { display: none; }` in mobile breakpoint)

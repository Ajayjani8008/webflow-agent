---
name: figma-to-webflow
description: Full pipeline — Figma URL → Webflow layout. Runs figma-analyst to read design (8 levels deep), echoes back understanding, waits for user confirmation of Design Spec, then webflow-builder creates the layout using native Webflow elements after user confirms the pre-build plan.
---

# /figma-to-webflow

**Usage:** `/figma-to-webflow [Figma URL]`
**Auto-trigger:** Any Figma URL in user message — no command needed.

---

## Pipeline

### Phase 1 — Read Design (foreground)

Route to `figma-analyst`:
- Checks FIGMA_TOKEN
- Parses URL → file_key + node_id
- Calls Figma REST API
- Traverses node tree (8 levels — saves full tree to `/tmp/figma_tree.txt`, shows summary only)
- Classifies each layer → Webflow element type (native elements first)
- Detects slider/tabs/carousel → maps to native Webflow elements, NOT html-embed
- Extracts design tokens → Webflow Variables
- Produces understanding echo-back

**PAUSE 1 — Echo-back confirmation:**
figma-analyst shows:
- Sections found and their types
- Interactive elements and how they'll be built
- CMS requirements
- Questions about anything unclear

Wait for user to say "yes, looks right" or provide corrections.

**PAUSE 2 — Design Spec confirmation:**
figma-analyst shows full Design Spec.
User confirms: section name + approach (A / B / C) + any corrections.

### Phase 2 — Class Plan (parallel with Phase 3)

Route to `class-manager`:
- Designs BEM class system for all new elements
- Checks `class_registry.md` for reuse — never creates duplicate classes
- Produces class plan with variable connections

### Phase 3 — Variable Check (parallel with Phase 2)

Route to `style-manager`:
- Checks which design tokens map to existing variables
- Creates new variables via API for any that don't exist
- Updates `variable_registry.md`

### Phase 4 — Pre-Build Confirmation (mandatory)

Route to `webflow-builder` (Step 2.5):
- Shows exact node tree outline to user:
  - Structure of what will be built
  - Native-first compliance check
  - Classes that will be used
  - What requires Designer after the build
- **PAUSE 3:** Wait for user "yes" before any API POST

### Phase 5 — Build Layout (foreground)

Route to `webflow-builder`:
- Checks target page exists (creates if not)
- Reads current page DOM (compressed summary only — no full dump)
- Saves build checkpoint to `/tmp/wf_checkpoint.json`
- POSTs section node tree to page DOM via API
- Updates checkpoint after each section
- Produces build comparison report (what was requested vs built)

### Phase 6 — Interactions (foreground)

If interactions detected in Design Spec:
Route to `interaction-builder`:
- Checks portability preference (from Phase 1 echo-back)
- Portable: CSS + custom JS approach
- Non-portable: Webflow IX2 spec for Designer setup
- Documents in `interaction_registry.md`

### Phase 7 — Background (parallel fire-and-forget)

- `doc-updater` → updates `page_registry`, `class_registry`, `variable_registry`
- If new Symbol needed: `component-builder` → documents Symbol spec

---

## Approach Options

**A) Full API build** — webflow-builder creates all nodes via REST API. Best for structured sections. Interactions and Symbols still require Designer.

**B) Spec only** — prints complete Webflow node JSON + class styles for manual paste into Designer. Useful when you want to review before building, or when API access is limited.

**C) Hybrid** — API creates structural nodes (sections, divs, headings, images), user applies Webflow styling and interactions in Designer. Best for pixel-perfect designs where spacing needs visual tweaking.

---

## What native elements are used

The pipeline enforces native Webflow elements — no custom HTML for supported patterns:

| Figma pattern | Built as |
|--------------|---------|
| Slider / carousel | `slider` node type (native) |
| Tabs | `tabs` node type (native) |
| Navigation bar | `navbar` node type (native) |
| Form | `form-block` node type (native) |
| Grid of cards | `grid` or `div-block` with CSS grid |
| Any layout | `section` + `container` + `div-block` |
| HTML embed | Only with explicit justification |

---

## Prerequisites

```bash
# Check before running
echo $FIGMA_TOKEN        # must be set
echo $WEBFLOW_API_KEY    # must be set (API Mode)
echo $WEBFLOW_SITE_ID    # must be set (API Mode)
# OR: Webflow MCP connector active (MCP Mode — no keys needed)
```

If any are missing, agent stops and provides setup instructions.

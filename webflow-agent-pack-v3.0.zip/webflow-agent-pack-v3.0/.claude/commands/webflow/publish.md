---
name: publish
description: Publishes the Webflow site to staging or production domains via REST API.
---

# /publish

**Usage:** `/publish [staging|production]`

**WARNING:** This pushes your draft changes live. Confirm before running.

---

## Publish to staging

```bash
# Get staging domain
curl -s \
  -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print('Domains:', d.get('customDomains',[]), '| Default:', d.get('defaultDomain'))"

# Publish to staging (default webflow.io domain)
curl -s -X POST \
  -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{ "publishToWebflowSubdomain": true }' \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/publish" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print('Publish status:', d)"
```

## Publish to production (custom domain)

```bash
curl -s -X POST \
  -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "publishToWebflowSubdomain": false,
    "customDomains": ["{{SITE_DOMAIN}}"]
  }' \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/publish"
```

---

## Pre-publish checklist

Run before `/publish production`:

```
[ ] /quality-gate passes
[ ] All pages verified at Desktop + Tablet + Mobile
[ ] SEO meta set on all new pages
[ ] No console errors in browser
[ ] Forms tested (submit, success, error states)
[ ] CMS items published (not draft)
[ ] Custom code: no console.log or debug output
[ ] 404 page exists and is styled
```

## After publish

Verify live site:
```bash
curl -I "https://{{SITE_DOMAIN}}" | grep "HTTP/"
# Should return: HTTP/2 200
```

Check CMS is live:
```bash
curl -s "https://{{SITE_DOMAIN}}/services" | grep -c "service-card"
# Should return count > 0
```

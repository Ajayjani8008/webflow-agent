---
name: sync-cms
description: Syncs CMS content from an external source (CSV, JSON, API) into Webflow CMS collections. Maps fields, transforms data, and batch-creates or updates items.
---

# /sync-cms

**Usage:** `/sync-cms`

Agent asks:
- Which collection? (name or ID)
- Source: CSV file path / JSON file path / external API URL / manual data
- Field mapping: source column → Webflow field slug
- Behavior: create new items only / update existing / full replace

Pipeline:
1. `cms-builder` → reads source data
2. Maps fields to collection schema (checks cms_registry.md)
3. Transforms data (date formatting, image URLs, etc.)
4. Batch POST to Webflow CMS (100 items per call max)
5. Reports: created N, updated N, failed N (with reasons)
6. Publishes all new items if user confirms

---

## CSV import example

CSV file:
```
name,slug,short-description,featured
"Service One","service-one","We help with X",true
"Service Two","service-two","We help with Y",false
```

Agent transforms and calls:
```bash
curl -X POST \
  -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "items": [
      { "isArchived": false, "isDraft": false, "fieldData": { "name": "Service One", "slug": "service-one", "short-description": "We help with X", "featured": true } },
      { "isArchived": false, "isDraft": false, "fieldData": { "name": "Service Two", "slug": "service-two", "short-description": "We help with Y", "featured": false } }
    ]
  }' \
  "https://api.webflow.com/v2/collections/$COLLECTION_ID/items/bulk"
```

## JSON import example

```json
[
  { "title": "Post 1", "body": "Content here", "author": "Jane" }
]
```

Agent maps `title` → `name`, `body` → `body`, `author` → `author` and creates items.

## Notes

- Image fields: provide publicly accessible URLs — Webflow will fetch them
- Rich text: provide HTML string (Webflow accepts HTML in RichText fields)
- Relationship fields: provide the referenced item's Webflow ID (must exist first)
- Rate limit: Webflow allows 60 API requests/minute — agent auto-paginates with delay

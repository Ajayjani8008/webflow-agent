---
name: quality-gate
description: Runs all quality checks before any publish. SEO audit, security review, performance check, responsive verification, and accessibility check.
---

# /quality-gate

**Usage:** `/quality-gate`

Runs in sequence:

### 1. SEO audit (`seo-optimizer`)

```bash
# Check all pages have title + description
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/pages" \
  | python3 -c "
import sys,json
pages = json.load(sys.stdin).get('pages',[])
missing = [p['slug'] for p in pages if not p.get('seo',{}).get('title')]
print('Missing SEO title:', missing or 'none')
"
```

### 2. Security check (`security-reviewer`)

Scans site custom code + all page embeds for:
- Exposed API keys
- XSS vulnerabilities in custom JS
- Insecure form handling
- Mixed content

### 3. Performance audit (`performance-optimizer`)

Checks:
- Asset sizes via Webflow Assets API
- Custom code weight
- Third-party script count

### 4. Class audit (`class-manager`)

Checks class_registry.md against recently built nodes for consistency.

### 5. CMS audit (`cms-builder`)

```bash
# Verify no draft items that should be published
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/collections/$COLLECTION_ID/items?limit=100" \
  | python3 -c "
import sys,json
items = json.load(sys.stdin).get('items',[])
drafts = [i.get('fieldData',{}).get('name') for i in items if i.get('isDraft')]
print('Draft items:', drafts or 'none')
"
```

### Output

```
Quality Gate Report — {{SITE_NAME}}

SEO:
  ✓ All pages have title
  ✗ /contact missing meta description
  ✓ CMS templates have dynamic meta

Security:
  ✓ No exposed API keys
  ✓ No XSS patterns in custom code
  ✓ Forms have spam protection

Performance:
  ✓ No images > 500KB
  ✗ hero-image.jpg is 820KB — compress to WebP
  ✓ Custom JS < 50KB

Classes:
  ✓ All classes in registry
  ✓ No hardcoded colors found

CMS:
  ✓ All items published
  ✓ All collections have template pages

VERDICT: NEEDS FIXES (2 issues)
Fix before publishing: /contact meta description, hero image compression
```

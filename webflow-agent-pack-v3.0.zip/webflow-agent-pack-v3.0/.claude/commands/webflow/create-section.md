---
name: create-section
description: Builds a section on an existing Webflow page. Collects full requirements (no building until confirmed), runs class-manager for class plan, style-manager for variables, webflow-builder with pre-build confirmation for DOM construction, and interaction-builder if animations needed. Always uses native Webflow elements.
---

# /create-section

**Usage:** `/create-section`

---

## Step 1 — Collect requirements (ask all at once)

Agent asks these questions in one message:

```
To build your section, I need:

1. Which page? (page slug or ID, e.g. "home", "services", "about")
2. Section type:
   - hero (big headline, image/video, CTA button)
   - cards grid (repeating items — how many columns?)
   - feature list (icon + text pairs)
   - testimonials
   - pricing table
   - FAQ / accordion
   - CTA banner
   - form (contact / newsletter / custom)
   - custom (describe it)
3. Content: static / CMS-connected / mixed?
   If CMS: which collection? (or should one be created?)
4. Background: solid color / gradient / full-bleed image / video / none?
5. Layout: full-width / contained (max-width container)?
6. Animations:
   - scroll reveal on entry? (yes/no)
   - hover effects on cards/buttons? (yes/no)
   - other? (describe)
7. Will this section be copied to other Webflow sites?
   (affects animation approach — native IX2 vs portable CSS/JS)
```

Wait for all answers before proceeding.

---

## Step 2 — Echo-back confirmation

After receiving answers, echo back:

```
Building: [section type] called "[section-name]" on /[page-slug]
  Layout: [describe structure]
  Content: [static/CMS — collection name]
  Native elements: section + container + [specific elements]
  Animations: [approach based on portability answer]
  New classes needed: [list]
  New variables needed: [list or "none"]

Is this correct?
```

Wait for "yes" or corrections.

---

## Step 3 — Pipeline (runs after both confirmations)

1. `class-manager` → design BEM class system, check registry for reuse
2. `style-manager` → create any missing variables
3. `webflow-builder` → shows pre-build node outline → waits for "yes" → builds and POSTs
4. `interaction-builder` → produces interaction specs (if animations requested)
5. `doc-updater` → update registries (background)

---

## Native element enforcement

Sections ALWAYS use:
- `section` wrapper (not `div-block` at top level)
- `container` for max-width content
- Native `slider` for carousels (NOT html-embed)
- Native `tabs` for tabbed content (NOT custom HTML)
- Native `navbar` for navigation (NOT div-based nav)
- Native `form-block` for forms (NOT html-embed)
- `grid` or CSS grid on `div-block` for card layouts

HTML embeds require explicit justification.

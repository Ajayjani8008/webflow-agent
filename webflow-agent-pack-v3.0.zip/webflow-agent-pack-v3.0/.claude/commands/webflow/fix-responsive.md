---
name: fix-responsive
description: Audits and fixes responsive layout issues across Webflow breakpoints. Checks each section at Mobile/Tablet/Desktop. Produces class-level fixes.
---

# /fix-responsive

**Usage:** `/fix-responsive`

Agent asks:
- Which page or section?
- Which breakpoint is broken? (Mobile / Tablet / Desktop / all)
- Screenshot of the broken layout

Routes to `systematic-debugger` → `style-manager`:

1. Identifies the broken class
2. Checks class_registry for expected responsive overrides
3. Produces specific fix: which class, which breakpoint, which property, what value

---

## Webflow breakpoints (widths where overrides apply)

| Breakpoint | Width | Webflow label |
|-----------|-------|--------------|
| Desktop | 992px+ | Base (default) |
| Tablet | 768–991px | Tablet |
| Mobile landscape | 480–767px | Mobile Landscape |
| Mobile portrait | ≤479px | Mobile |

---

## Common responsive fixes

| Problem | Fix |
|---------|-----|
| 3-col grid becomes horizontal scroll on mobile | grid-cols: 3 → 1 at mobile breakpoint |
| Text too large on mobile | font-size override at mobile (--font-size-4xl → --font-size-3xl) |
| Section padding too much on mobile | padding override (--space-5xl → --space-3xl) |
| Flex row stacks badly | flex-direction: row → column at tablet |
| Nav links overflow | Show hamburger at tablet + mobile (display: none on nav links) |
| Image bleeds outside container | width: 100%, max-width: 100% at mobile |
| Absolute positioned element wrong | Switch to relative positioning at mobile |

---

## Verification

After fixes: user verifies in Webflow Designer using the breakpoint toolbar (top of Designer). Must check:
- Desktop (992px+)
- Tablet (768px)
- Mobile landscape (480px)
- Mobile portrait (375px — iPhone common size)

---
name: class-manager
description: Manages Webflow CSS class naming, audits class usage, detects duplicate or unused classes, enforces BEM naming convention, and connects classes to the correct elements via node tree. Maintains class_registry.md. Run before any new section is built and after any refactor.
model: claude-sonnet-4-6
---

# Class Manager

Parse from prompt: `SITE:` `MCP_MODE:` `CLASS_REG:` `TASK:` `DESIGN SPEC:`.
Registry content passed inline — do not re-read files already in prompt.
HARD STOP: registry content missing and task requires it → report, stop.

---

## RULE: No doc-updater self-call

This agent does NOT spawn doc-updater. The orchestrator calls doc-updater once at pipeline end. This agent writes to session_state.md and class_registry.md directly.

---

## STEP 0 — Registry Check

Read CLASS_REG from prompt. Class exists? → reuse, never duplicate. Propose modifier if variant needed.

---

## BEM NAMING (zero exceptions)

```
[block]                       section or component root
[block]__[element]            child element
[block]__[element]--[mod]     variant / state modifier
```

**Rules:**
- kebab-case only: `hero__title` not `heroTitle`
- No abbreviations: `navigation__link` not `nav__lnk`
- No color names: `btn--primary` not `btn--blue`
- No size absolutes: `text-xl` not `text-24`
- No numbers: `card` not `card-1` (use stagger in interactions)
- No page prefixes: `hero` not `home-hero`
- No tag names: `hero__content` not `hero__div`

**Utility classes (global — no block prefix):**
```
.container     .btn     .btn--primary     .btn--outline
.btn--sm       .btn--lg .show-desktop     .hide-desktop
.show-mobile   .text-center   .text-left  .visually-hidden
```

**Combo class rule (Webflow):**
```
["btn", "btn--primary"]    ✓ base first, modifier second
["btn--primary"]           ✗ modifier without base
["btn", "primary"]         ✗ orphan modifier
```

**Refuse these:**
```
.div1  .text-blue  .bigHeading  .section_wrapper  .card2  .new-card  .temp
```

---

## STEP 1 — Design Class System

Output for every new section:

```
═══════════════════════════════════════════
CLASS PLAN — [section-name]
═══════════════════════════════════════════

NEW CLASSES
  .services-grid              Section wrapper
  .services-grid__inner       Flex/grid container inside section
  .services-grid__header      Heading area (check: reuse .section-header?)
  .services-grid__list        Cards wrapper (grid)
  .service-card               Card root → SYMBOL candidate
  .service-card__icon         Icon image
  .service-card__title        Card H3
  .service-card__desc         Card body text
  .service-card__link         Card CTA

REUSE FROM REGISTRY
  .container                  ✓ max-width wrapper
  .section-header             ✓ eyebrow + heading + subtitle pattern
  .btn--primary               ✓ already defined

MODIFIERS NEEDED
  .service-card--featured     Highlighted card (background: --color-primary)

CLASS → VARIABLE CONNECTIONS
  .services-grid              background: var(--color-surface-alt)
                              padding: var(--space-5xl) 0
  .services-grid__list        display: grid
                              grid-template-columns: repeat(3, 1fr)
                              gap: var(--space-xl)
  .service-card               background: var(--color-surface)
                              border-radius: var(--radius-lg)
                              padding: var(--space-xl)
                              transition: transform var(--duration-base) ease-out,
                                          box-shadow var(--duration-base) ease-out
  .service-card__title        font-size: var(--font-size-2xl)
                              font-weight: 600

RESPONSIVE OVERRIDES
  @tablet  .services-grid__list → grid-template-columns: repeat(2, 1fr)
  @mobile  .services-grid__list → grid-template-columns: 1fr
           .service-card → padding: var(--space-lg)
═══════════════════════════════════════════
```

---

## STEP 2 — Append to class_registry.md

```markdown
## services-grid
**Purpose:** Services section wrapper
**Styles:** background var(--color-surface-alt), padding var(--space-5xl) 0
**Used on:** home, /services

## service-card
**Purpose:** Individual service card — Symbol candidate
**Styles:** bg var(--color-surface), radius var(--radius-lg), padding var(--space-xl)
           transition: transform + box-shadow var(--duration-base) ease-out
**Modifiers:** .service-card--featured
**Responsive:** Mobile: padding var(--space-lg)
**Interaction:** card-hover-lift
**Used on:** home, /services
```

---

## STEP 3 — Verify Node Tree Compliance

When webflow-builder creates nodes, every `"classes"` array must:
1. Have primary BEM class first
2. Include applicable utility classes
3. Contain no class not in the class plan

Unregistered class found → add to registry first, then continue.

---

## SESSION STATE WRITE

```
class-manager [YYYY-MM-DD HH:MM]:
  TASK: designed classes for [section]
  NEW_CLASSES: [comma-separated list]
  REUSED_CLASSES: [comma-separated list or "none"]
  STATUS: complete
  NEXT: style-manager
```

---
name: screenshot-to-webflow
description: Screenshot/reference image → Webflow. Claude reads the image with vision inline, builds a build_spec, then builds. No design-analyst agent.
---

# /screenshot-to-webflow

1. **Read the image with vision inline** — classify layout, elements, spacing, typography → `docs/memory/webflow/build_spec.json` (same schema as kb/figma.md). Add `"confidence":"low|medium"` on estimated colors/spacing.
2. Map to existing vars (registry `## Variables` slice); unmatched → `new_vars`, create inline.
3. SMALL → build inline. MEDIUM/LARGE → spawn `webflow-builder` with the spec + PAGE.
4. No confirmation for a single section. Surface pending designer work → done.

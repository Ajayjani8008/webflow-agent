---
name: security-review
description: Security scan — XSS, exposed secrets, form security, SRI, clickjacking, mixed content. Inline. No quality-reviewer agent.
---

# /security-review

Do inline. kb/quality.md → SECURITY scope. Webflow `ws-` token exposure = CRITICAL. BLOCK on any HIGH+. Page passwords ≠ auth; no secrets in CMS fields.

---
name: sync-cms
description: Syncs external content (CSV/JSON/API) into Webflow CMS collections — inline bulk operations. No cms-builder agent.
---

# /sync-cms

Do inline. kb/cms.md for endpoints.

1. Map source fields → collection fields → transform (images = public URLs, RichText = HTML string, refs = existing item IDs).
2. `POST /collections/{id}/items/bulk` (100/call, 60 req/min). Large sets → chunk sequentially; log dropped/failed rows, never silently truncate.
3. Verify item counts by read-back (GET items → count ≥ expected). Update `## CMS` in registry.md.

---
name: create-cms-collection
description: Creates a Webflow CMS collection with fields and sample items — inline via REST/MCP. Schema documented in registry before creation. No cms-builder agent.
---

# /create-cms-collection

Do inline (CMS work is linear API calls — no agent). Load kb/cms.md once for endpoints, field types, traps.

1. **Schema first.** Design collection (displayName/singularName/slug + field table). Grep `## CMS` in registry.md — exists → extend, don't duplicate. Write schema to registry BEFORE creating.
2. **Create.** POST collection → POST fields one-by-one. ⚠ NEVER POST `name`/`slug` fields (auto-exist → 422 aborts). Any field 422 → STOP, record fields_created vs fields_failed, report `failed`.
3. **Items.** POST sample items (≥3 unless told otherwise). Bulk max 100/call, 60 req/min.
4. **Verify (mandatory evidence).** GET collection → field slugs match plan; GET items → count ≥ expected.
5. Update `## CMS` in registry.md inline. Designer-only binding steps → pending_designer_work.md ledger.

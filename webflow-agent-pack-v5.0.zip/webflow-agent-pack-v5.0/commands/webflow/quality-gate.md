---
name: quality-gate
description: Full pre-publish gate — code, security, performance, SEO in one inline pass. Writes quality_gate_verdict.json. No quality-reviewer agent.
---

# /quality-gate

Do inline (findings must land in your context to act on them). Load kb/quality.md once for the four checklists.

1. Collect code ONCE: `GET /pages/{id}/custom_code`, `GET /sites/{id}/custom_code`, embed nodes from DOM. Don't re-fetch per dimension.
2. Run all four scopes against kb/quality.md: code · security · performance · SEO.
3. Consolidate findings by severity → `VERDICT: PASS | PASS WITH FIXES | BLOCK` (BLOCK = any CRITICAL, or HIGH in security).
4. Write `docs/memory/webflow/quality_gate_verdict.json` `{verdict, criticals:[], highs:[], date}` (publish checks it).
5. Auto-fixable (SEO meta, defer attrs) → apply, list changes. Surface unchecked pending_designer_work.

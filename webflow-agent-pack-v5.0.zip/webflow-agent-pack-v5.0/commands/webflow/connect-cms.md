---
name: connect-cms
description: Connects existing page elements to CMS fields via xattr bindings — inline. Collection List wrapper binding is Designer-only. No cms-builder agent.
---

# /connect-cms

Do inline. xattr schema in kb/cms.md (`textContent|src|alt|href|innerHTML|style` → field slug).

1. Map element ↔ field, apply xattr bindings via DOM PATCH (GET → merge → POST; never blind replace).
2. Collection List wrapper collection-binding + Limit/Sort/Filter + RichText (template pages only) = Designer work → pending_designer_work.md ledger.
3. Unconfirmed bindings = `partial`, never claim complete. Unbound collection = incomplete — say so. Verify by DOM read-back.

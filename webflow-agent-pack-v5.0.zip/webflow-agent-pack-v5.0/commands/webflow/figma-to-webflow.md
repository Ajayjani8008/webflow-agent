---
name: figma-to-webflow
description: Figma URL → Webflow. Claude reads the Figma file directly (MCP/REST), builds a compact build_spec inline, then builds. No design-analyst agent. Single section = no confirmation; full page = one confirm.
---

# /figma-to-webflow

Claude reads Figma natively — do NOT spawn an analysis agent.

1. **Read the design inline.** Parse the URL → `file_key` + `node_id` (`figma.com/design/FILE_KEY/...?node-id=1-234` → `1:234`). Then either:
   - Figma MCP present (`mcp__claude_ai_Figma__*`) → read the node tree with it, or
   - `GET /v1/files/{file_key}/nodes?ids={node_id}` with `FIGMA_TOKEN` (skip `geometry=paths`; skip `/styles` unless text styles missing).
   Walk depth-limited (5 levels / 40 nodes per section). See kb/figma.md for node→Webflow classification, tag rules, and var mapping.
2. **Write `docs/memory/webflow/build_spec.json`** (schema in kb/figma.md): classify each node to a Webflow type, map colors/spacing to existing vars (grep `## Variables` registry slice; unmatched → `new_vars`), flag native elements (slider/tabs/form/dropdown/accordion), note cms/symbol candidates.
3. **Create `new_vars` inline** (a handful) before building. kb/api.md.
4. **Classify scope:** single section → build now, no confirmation. Full page (>40 nodes) → ask which section OR list sections and get ONE confirm.
5. **Build:** SMALL → build inline. MEDIUM/LARGE → spawn `webflow-builder` with the `build_spec.json` path + PAGE + registry slice (one section per call).
6. CMS candidates needing a collection → do CMS inline (see /webflow:create-cms-collection).
7. Surface pending designer work → done.

Auto-triggers on `figma.com/design` URLs.

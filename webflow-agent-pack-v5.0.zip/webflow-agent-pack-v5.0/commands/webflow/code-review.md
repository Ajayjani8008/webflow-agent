---
name: code-review
description: Reviews all custom code (embeds, head/footer code) for native-first violations, shortcut CSS, var compliance, JS quality. Inline. No quality-reviewer agent.
---

# /code-review

Do inline. kb/quality.md → CODE scope. Collect custom_code + embeds once; check native-first violations, shortcut CSS, hardcoded hex/px vs vars, `Webflow.push()` wrapping, DOMPurify on innerHTML. Findings by severity + VERDICT (BLOCK on CRITICAL).

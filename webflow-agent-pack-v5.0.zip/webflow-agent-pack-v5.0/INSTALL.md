# Webflow Agent Pack v5.0 (2026-07-08)

Complexity-routed, token-optimized. **2 agents** (down from 6), inline skill-style work, lazy KB. Main Claude is the orchestrator. See webflow-kb/architecture.md.

## Install (copy into ~/.claude/)
```bash
cp -r agents/webflow    ~/.claude/agents/
cp -r commands/webflow  ~/.claude/commands/
cp rules/webflow/core.md    ~/.claude/rules/webflow/
cp rules/common/agents.md   ~/.claude/rules/common/
cp -r webflow-kb        ~/.claude/
```
**Delete the removed v4 agent files** so they don't double-load context:
```bash
rm -f ~/.claude/agents/webflow/{webflow-orchestrator,design-analyst,cms-builder,quality-reviewer}.md
```
Also remove any v3 leftovers in ~/.claude/rules/webflow/ (class-naming.md, responsive.md, interactions.md, cross-site-portability.md).

## Contents
- **agents/webflow/ (2)** — webflow-builder (heavy DOM builds), systematic-debugger (evidence-gated bugs). These are the only jobs that get an isolated context.
- **commands/webflow/ (19)** — all `/webflow:*` entry points, names unchanged. Most run inline; only medium/large builds and debug spawn an agent.
- **rules/** — always-loaded core (~120 lines). Classifier + hard invariants + native-first ladder. This is the enforcement layer; main Claude IS the orchestrator.
- **webflow-kb/ (skills / lazy knowledge)** — read on demand to do work inline: figma (Figma+screenshot extraction), cms, quality (code/security/perf/SEO), naming, responsive, interactions, portability, api, lessons (global memory), architecture.

## What changed from v4
- Removed `webflow-orchestrator` → main Claude orchestrates (no nested-agent layer).
- Removed `design-analyst` → Claude reads Figma/screenshots directly (Figma MCP/REST + vision) inline.
- Removed `cms-builder` → CMS is inline API/MCP work (kb/cms.md).
- Removed `quality-reviewer` → quality/security/perf/SEO reviewed inline (kb/quality.md).
- All rule enforcement, evidence gates, ledgers, and native-first discipline retained.

## Requirements
Webflow MCP connector (preferred) or WEBFLOW_API_KEY + WEBFLOW_SITE_ID. Figma needs Figma MCP or FIGMA_TOKEN.

## Old projects
First session auto-consolidates v3 per-registry files (class_registry.md etc.) into docs/memory/webflow/registry.md. build_state.json resume unchanged.

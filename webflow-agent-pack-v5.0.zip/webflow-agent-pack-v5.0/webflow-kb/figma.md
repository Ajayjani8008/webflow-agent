# Figma / screenshot → Webflow (inline extraction)

Claude reads the design **directly — no design-analyst agent.** Figma MCP (`mcp__claude_ai_Figma__*`) or REST (`FIGMA_TOKEN`). Screenshot = vision mode (no token). Output = one compact `build_spec.json`, then build (inline for SMALL, `webflow-builder` for MEDIUM/LARGE).

## Flow
```
Figma MCP/REST (or vision) → build_spec.json → build (inline | webflow-builder)
```
Do extraction + classification + var mapping + CMS/symbol detection in a SINGLE inline pass. Keep it small — the whole spec ≤4KB.

## URL parse
`figma.com/design/FILE_KEY/...?node-id=1-234` → node_id `1:234`.

## REST (minimal — when no Figma MCP)
```
GET /v1/files/{file_key}/nodes?ids={node_id}
```
Skip `geometry=paths`, skip `/styles` unless text styles missing inline. Max depth: 5 (section) | 6 (page). Max nodes: 40 (section) | 80 (page). >40 nodes on a whole-page URL → extract ONE section at a time.

## build_spec.json (the only intermediate file)

```json
{
  "section": "hero",
  "portability": "single-site",
  "new_vars": [],
  "native_required": [],
  "cms_candidates": [],
  "symbol_candidates": [],
  "tree": [{
    "id": "1:2", "wf": "Section", "class_hint": "hero",
    "layout": {"dir": "column", "gap": "--space-lg", "pad": "--space-xl"},
    "children": [
      {"id": "1:3", "wf": "Heading", "tag": "h1", "text": "...",
       "style": {"color": "--color-text", "size": "--font-3xl"}}
    ]
  }]
}
```
Rules: ≤4KB total. Var names not hex in `style`/`layout`. Omit nulls. Screenshot mode → add `"confidence":"low|medium"` on estimated colors/spacing.

## Classification (inline)
- Text by fontSize → `Heading` h1 ≥48 | h2 36–47 | h3 28–35 | h4 22–27 | `Paragraph` 16–21 | span ≤15.
- Auto-layout frame → `Section` (top) or `DivBlock` (nested); record `layout {dir, gap, pad}` as var names.
- Image fill → `Image`; vector/icon → `Image` or skip if decorative <16px.
- Slider/tabs/nav/form/accordion → native WF types in `wf` — never html-embed.
- CMS/symbol candidate only if ≥2 identical subtrees — one line each.

## Token mapping (inline)
Spacing snap: 4/8/16/24/32/48/64/96/128 → xs…4xl. Colors ±15 RGB to existing vars (grep `## Variables` registry slice); else `new_vars` (name + value + type), create before building.

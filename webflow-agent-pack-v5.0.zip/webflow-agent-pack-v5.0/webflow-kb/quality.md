# Quality / Security / Performance / SEO — inline checklists

Run inline (no agent). Collect code ONCE per pass: `GET /pages/{id}/custom_code`, `GET /sites/{id}/custom_code` (headCode/footerCode), embed nodes from DOM. Don't re-fetch per scope. Scope = code | security | performance | seo | full.

## CODE scope
- Native-first violations (HIGH): html-embed replicating slider/tabs/form/navbar; counter not `[data-counter]`+footer JS; scroll reveal not `[data-reveal]`+IntersectionObserver.
- Shortcut CSS (HIGH): class-stylable props (layout/spacing/typography/color/hover/breakpoints) in headCode or embed `<style>` → must be class styles (style_tool/Designer). headCode whitelist: `@keyframes`, `:root`, third-party resets.
- `data-*` hooks without `PORTABILITY: cross-site` justification.
- Var compliance: hardcoded hex/px → map to vars (`grep "#[0-9a-fA-F]\{6\}"`).
- JS: Webflow-dependent code wrapped in `Webflow.push()`; innerHTML requires `DOMPurify.sanitize`.

## SECURITY scope
XSS (innerHTML/outerHTML/document.write/eval/unsanitized template literals) | exposed secrets (`key:|token:|secret:|api_key:`; Webflow `ws-` token = CRITICAL) | form security (HTTPS action, no sensitive fields to third parties) | mixed content | third-party scripts need SRI (`integrity=sha384` + crossorigin) | clickjacking (X-Frame-Options SAMEORIGIN via Project Settings → Publishing → Custom headers) | URL-param → DOM injection. Note: Webflow page passwords ≠ real auth; no secrets in CMS fields.

## PERFORMANCE scope
CWV targets: LCP <2.5s, CLS <0.1, INP <200ms (priority LCP→CLS→INP). Checks: custom_code size >10k chars; hero image `<link rel=preload as=image>`; img width/height set (CLS); scripts defer/async; font-display:swap + max 2 typefaces; Collection List limit/filter server-side; no nested Collection Lists (→ Finsweet CMS Nest); assets >200KB (`GET /sites/{id}/assets`).

## SEO scope
Per page (`GET /sites/{id}/pages`): title ≤60 keyword-first (home brand-lead; CMS `[Item] | [Section] | [Site]`), meta 120–160, OG 1200×630 <1MB. Fixes via `PATCH /pages/{id}`. CMS template meta must be Designer-bound (dynamic — cannot automate → ledger). JSON-LD: Organization in footerCode via `PUT /sites/{id}/custom_code`; FAQPage per-page embed.

## Output
```
QUALITY REPORT — scope: [x]
[SEVERITY] finding — location — exact fix    (CRITICAL/HIGH/MEDIUM/LOW, sorted)
VERDICT: PASS | PASS WITH FIXES | BLOCK
```
BLOCK = any CRITICAL, or HIGH in security scope. On full/pre-publish scope write `docs/memory/webflow/quality_gate_verdict.json` `{verdict, criticals:[], highs:[], date}`.
Auto-fixable findings (SEO meta, defer attrs) → apply directly when the task says fix, list what changed.

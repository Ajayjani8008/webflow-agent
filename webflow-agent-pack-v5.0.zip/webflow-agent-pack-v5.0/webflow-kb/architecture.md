# Webflow Agent System v5 — Architecture

v5.0 (2026-07-08). Reduces v4 (6 agents) → **2 agents**. Everything else is inline (skill-style) work driven by the always-loaded rules + lazy KB. v4 pack kept as the prior version.

## Principle
**Main Claude IS the orchestrator and the senior Webflow developer.** It classifies, routes, builds, and enforces the rules itself. An agent is spawned ONLY when isolation genuinely pays off. Anything Claude can do inline — reading a design, CMS API calls, quality review, planning, SEO — is done inline, never delegated to a wrapper agent that only re-does built-in ability at extra token cost.

## Three layers
1. **Rules (always loaded, ~120 lines)** — the enforcement layer. `rules/webflow/core.md` (complexity classifier + hard invariants + native-first ladder + memory protocol) and `rules/common/agents.md` (platform routing). Main Claude obeys these; no orchestrator agent needed.
2. **Agents (2 — isolation only):**
   - `webflow-builder` — heavy MEDIUM/LARGE section/page DOM construction + read-back verify. Isolated so ~30 tool calls and large read-backs never bloat main context. Enforces styles-mandatory + verify + handoff gates.
   - `systematic-debugger` — evidence-gated bug investigation. Isolated exploratory reads; enforces "never guess."
3. **Skills / knowledge (inline, lazy `webflow-kb/`):** loaded on demand, at most once per session, to do work inline — `figma.md` (Figma/screenshot extraction), `cms.md` (CMS ops), `quality.md` (code/security/perf/SEO), `naming.md`, `responsive.md`, `interactions.md`, `portability.md`, `api.md`, `lessons.md`.
4. **Commands (19 `/webflow:*` entry points):** thin user-facing routers. Most run inline; only build (medium/large) and debug spawn an agent.

## Removed from v4 (→ absorbed inline)
- `webflow-orchestrator` → main Claude orchestrates via core.md. Removes a whole nested-agent layer (was: main → orchestrator → builder).
- `design-analyst` → Claude reads Figma directly (Figma MCP / REST) or a screenshot via vision, writes `build_spec.json` inline. kb/figma.md.
- `cms-builder` → inline API/MCP CMS work. kb/cms.md.
- `quality-reviewer` → inline review (findings must reach main context to act on anyway). kb/quality.md.

## Quality preserved (unchanged)
Evidence rule (site read-back), pending-Designer-work ledger, status honesty (complete/partial/failed), DOM-replace merge protocol, native-first ladder, slug trap, IX2-no-API, component-init hazard, 4-breakpoint checks, stopping conditions.

## Memory (two levels — unchanged)
Global = `rules/webflow/core.md` + `webflow-kb/` (incl. lessons.md, permanent). Project = `docs/memory/webflow/{project.md, registry.md, pending_designer_work.md, build_state.json, handoff/}`. handoff/ now only holds the 2 spawnable agents' evidence; inline work writes evidence straight to project.md/registry.md.

## Backward compatibility
- All 19 `/webflow:*` command names unchanged; bodies rewired.
- Agent names `webflow-builder`, `systematic-debugger` unchanged. References to `design-analyst`/`cms-builder`/`quality-reviewer`/`webflow-orchestrator` are gone — remove those agent files from `~/.claude/agents/webflow/`.
- build_state.json resume unchanged. Old per-type registries still consolidate into registry.md on first session in an old project.

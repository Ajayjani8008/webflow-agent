# /code-review

Review all custom code in this Webflow site.

## Steps

1. Read `docs/memory/webflow/project_overview.md` for stack context
2. Fetch all pages with custom code:
   ```bash
   curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
     "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/pages" \
     | python3 -c "import sys,json; [print(p['id'], p['slug']) for p in json.load(sys.stdin).get('pages',[])]"
   ```
3. For each page with custom code, fetch:
   ```bash
   curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
     "https://api.webflow.com/v2/pages/{PAGE_ID}/custom-code"
   ```
4. Fetch site-wide custom code:
   ```bash
   curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
     "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/custom-code"
   ```
5. Route to `code-reviewer` agent with all collected code
6. Present findings grouped by severity: Critical → High → Medium → Low → Info

## Output format

```
## Code Review — [Site Name] — [Date]

### Critical (must fix before publish)
- [file/page]: [issue] → [fix]

### High (fix this sprint)
- [file/page]: [issue] → [fix]

### Medium (fix when touching the file)
- [file/page]: [issue] → [fix]

### Low (style / preference)
- [file/page]: [issue] → [suggestion]

### Passed
- [list of checks that passed]

**Score: X/20 checks passed**
```

## Also checks

- All custom JS wrapped in `Webflow.push()` or `DOMContentLoaded`
- No `var` declarations (use `const`/`let`)
- No `document.write()`
- No synchronous XHR
- `innerHTML` only used with `DOMPurify.sanitize()` or static strings
- No `eval()`
- No console.log left in production code
- Event listeners cleaned up on nav (for SPAs)
- CSS: no `!important` overrides except when Webflow forces it
- CSS: all values use variables (`var(--color-*)`, `var(--space-*)`)
- Third-party scripts loaded with `defer` or `async`
- No API keys or tokens in any custom code

## After review

If any Critical or High issues found:
- List exact fix for each
- Ask user which to fix now vs later
- Route fixes back through `code-reviewer` for re-check

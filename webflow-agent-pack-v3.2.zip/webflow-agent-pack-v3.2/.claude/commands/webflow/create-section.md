---
name: create-section
description: Builds a section on an existing Webflow page. Collects full requirements (no building until confirmed), runs class-manager for class plan, style-manager for variables, webflow-builder with pre-build confirmation for DOM construction, and interaction-builder if animations needed. Always uses native Webflow elements.
---

# /create-section

**Usage:** `/create-section`

---

## Step 1 — Requirements + build preview (single confirmation gate)

Ask all questions AND show a build preview in the same response. User confirms once.

```
To build your section I need:

1. Which page? (slug, e.g. "home", "services")
2. Section type: hero / cards grid / feature list / testimonials / pricing / FAQ / CTA banner / form / custom
3. Content: static / CMS-connected?  If CMS: which collection (or create new)?
4. Background: color / gradient / image / video / none?
5. Layout: full-width / contained?
6. Animations: scroll reveal? hover effects? other?
7. Cross-site reuse? (affects animation approach — IX2 vs portable CSS/JS)

Once you answer, I'll build:
  section.[name] → container → [layout] → [elements]
  All native elements: slider/tabs/forms use Webflow native nodes, not html-embed.
  Reply with answers or corrections. I'll confirm the class plan before any API call.
```

Wait for answers. No second echo-back gate — the webflow-builder pre-build plan is the final confirmation before DOM is written.

---

## Step 2 — Pipeline (runs after requirements answered)

1. `class-manager` → design BEM class system, check registry for reuse
2. `style-manager` → create any missing variables
3. `webflow-builder` → shows pre-build node outline → waits for "yes" → builds and POSTs
4. `interaction-builder` → produces interaction specs (if animations requested)
5. `doc-updater` → update registries (background)

---

## Native element enforcement

Sections ALWAYS use:
- `section` wrapper (not `div-block` at top level)
- `container` for max-width content
- Native `slider` for carousels (NOT html-embed)
- Native `tabs` for tabbed content (NOT custom HTML)
- Native `navbar` for navigation (NOT div-based nav)
- Native `form-block` for forms (NOT html-embed)
- `grid` or CSS grid on `div-block` for card layouts

HTML embeds require explicit justification.

---
name: project-map
description: Rebuilds docs/maps/project_map.md after major features. Maps all pages, collections, symbols, and their relationships. Shows blast radius — what breaks if a Symbol or class is changed.
model: claude-sonnet-4-6
---

# Project Map

Parse from prompt: `SITE:` `SITE_ID:` `MCP_MODE:` and registry content passed inline.
Map current site state. Show dependency blast radius.

---

## WHEN TO RUN

Run after:
- Major feature addition (new pages, collections, symbols)
- Symbol refactor
- CMS schema change
- Before any destructive architectural change

---

## STEP 1 — Gather State

**MCP Mode**: use `data_sites_tool`, `data_pages_tool`, `data_cms_tool` to get live data.

**API Mode**:
```bash
# Pages
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/pages" \
  | python3 -c "import sys,json; [print(p.get('slug'), '|', p.get('title')) for p in json.load(sys.stdin).get('pages',[])]"

# Collections
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/collections" \
  | python3 -c "import sys,json; [print(c['id'], '|', c['displayName'], '|', c['slug']) for c in json.load(sys.stdin).get('collections',[])]"
```

Read registries passed inline: PAGE_REG, CMS_REG, COMP_REG, CLASS_REG.

---

## STEP 2 — Build Project Map

Write to `docs/maps/project_map.md`:

```markdown
# Project Map — {SITE_NAME}
**Last updated:** YYYY-MM-DD

## Page Tree

```
/ (home)
├── /about
├── /services
│   └── /services/{slug}    ← CMS Template: Services
├── /blog
│   └── /blog/{slug}        ← CMS Template: Blog Posts
├── /contact
└── _components             ← Hidden — Symbol source page
```

## CMS Collections

| Collection | ID | Items | Template page | Bound on |
|-----------|-----|-------|--------------|---------|
| Services | [id] | [N] | /services/{slug} | home (preview), /services |
| Blog Posts | [id] | [N] | /blog/{slug} | home (featured), /blog |

## Symbols

| Symbol | Pages used | Classes | CMS bound? |
|--------|-----------|---------|-----------|
| Main Nav | ALL pages | .nav, .nav__link, .nav__cta | no |
| Site Footer | ALL pages | .footer, .footer__links | no |
| Service Card | home, /services | .service-card | yes → Services |
| Blog Card | home, /blog | .blog-card | yes → Blog Posts |
| Section Header | home, /services, /about | .section-header | no |
| CTA Banner | /services, /about, /blog | .cta-section | no |

## Class Dependency Map

| Class | Symbol | Pages | If changed → impacts |
|-------|--------|-------|---------------------|
| .service-card | Service Card | home, /services | 2 pages |
| .nav__link | Main Nav | ALL | ALL pages |
| .btn--primary | global utility | ALL | ALL pages, all CTAs |
| .section-header__title | Section Header | home, /services, /about | 3 pages |

## Blast Radius Table

| Change | Pages affected | Symbols affected | Risk |
|--------|---------------|-----------------|------|
| Rename .btn → .button | ALL | Main Nav, CTA Banner | HIGH — affects every CTA |
| Delete Services collection | /services, /services/{slug}, home | Service Card | HIGH — 3 pages break |
| Change .nav__link styles | ALL | Main Nav | HIGH — site-wide nav change |
| Delete CTA Banner symbol | /services, /about, /blog | — | MEDIUM — 3 pages lose section |
| Add field to Services | none | Service Card (rebind) | LOW — additive |

## Variables in Use

| Variable | Used by classes | If changed → impacts |
|----------|----------------|---------------------|
| --color-primary | .btn--primary, .nav__cta, .hero__cta | ALL CTAs + nav |
| --space-5xl | .hero, .services-grid, .cta-section | Section spacing |
| --font-size-6xl | .hero__title | Hero headlines only |
```

---

## STEP 3 — Flag High-Risk Items

Identify:
- Classes used on 5+ pages → any change is HIGH risk → recommend Symbol instead of class
- Symbols used on ALL pages → any change requires full site test
- Collections with many references → deletion cascades

Output:
```
HIGH RISK ITEMS (change carefully):
  .btn--primary → used ALL pages (utility class — never rename)
  Main Nav symbol → used ALL pages — test all breakpoints if changed
  Services collection → delete = breaks /services, /services/{slug}, home preview
```

---

## BUILD HANDOFF WRITE (write before session state)

```python
import json, os
handoff = {
  "agent": "project-map",
  "status": "complete",  # computed — see status rule below
  "outputs": {
    "map_updated": True,
    "pages_mapped": 0
  },
  "evidence": {
    "map_file_written": "docs/maps/project_map.md",  # path of map file actually written
    "pages_mapped": 0  # count of pages actually mapped
  },
  "pending_designer_work": [],
  "registries_to_update_via_doc_updater": [],
  "next": "complete"
}
os.makedirs('docs/memory/webflow/handoff', exist_ok=True)
json.dump(handoff, open('docs/memory/webflow/handoff/project-map.json', 'w'), indent=2)
```

**Status honesty rule:** `status` is computed from actual results — set `"complete"` only when all steps succeeded AND `evidence` is non-empty (map file written, pages_mapped > 0). Otherwise set `"partial"` or `"failed"`. Never hardcode `"complete"`.

---

## SESSION STATE WRITE

```
project-map [YYYY-MM-DD HH:MM]:
  TASK: rebuilt project map
  PAGES: [N]
  COLLECTIONS: [N]
  SYMBOLS: [N]
  HIGH_RISK_ITEMS: [list or "none"]
  STATUS: complete
  NEXT: doc-updater
```

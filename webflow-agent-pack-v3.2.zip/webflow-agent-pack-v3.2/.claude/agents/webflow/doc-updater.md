---
name: doc-updater
description: Updates docs/memory/webflow/ registries after every implementation. Reads what was built, appends to the correct registry file, and keeps the project's persistent memory current. Runs in background after every build agent completes.
model: claude-haiku-4-5-20251001
---

# Doc Updater

Parse from prompt: `TASK:` `SESSION LOG:` `AGENTS THAT RAN:` `REGISTRIES_TO_UPDATE:`.
Called ONCE per pipeline by the orchestrator at pipeline end. Never called by individual agents.

Update only. Never overwrite. Append-only for all registries except fixing stale IDs.
Never modify: `project_overview.md`, `docs/FR/` files, `docs/decisions/` ADRs.

---

## SCOPE RULE — collect REGISTRIES_TO_UPDATE from handoff files

Read ALL files in `docs/memory/webflow/handoff/*.json` (glob) and collect the union of every agent's `registries_to_update_via_doc_updater` array:

```python
import json, glob
registries = set()
for f in glob.glob('docs/memory/webflow/handoff/*.json'):
    h = json.load(open(f))
    registries.update(h.get('registries_to_update_via_doc_updater', []))
print('Registries to update:', sorted(registries))
```

Merge this set with any `REGISTRIES_TO_UPDATE:` listed in the prompt. Only update registries in the merged set. Skip all others entirely — do not read or write unlisted files.

Typical values:
- Simple section build: `class_registry, variable_registry, page_registry`
- CMS build adds: `cms_registry`
- Component build adds: `component_registry`
- Interaction-only change: `interaction_registry`

If no handoff files exist AND REGISTRIES_TO_UPDATE is missing from prompt → default to: `class_registry, variable_registry, page_registry` only.

---

## page_registry.md

```markdown
## /[slug]
**Type:** Static | CMS Template
**Sections:** [list]
**CMS:** [collection name + Collection List location, or "none"]
**Symbols:** [list]
**Classes:** [primary section classes]
**Interactions:** [interaction names]
**SEO:** [title set | meta set | OG set | pending]
**Status:** Draft | Published
**Built:** YYYY-MM-DD
```

## cms_registry.md

```markdown
## [Collection Name]
**Webflow slug:** [slug]
**Collection ID:** [id]
**Singular:** [name]
**Template page:** /[slug]/{slug}

| Field slug | Type | Required | Notes |
|-----------|------|---------|-------|
| name | PlainText | yes | |
| [field] | [type] | yes/no | [notes] |

**SEO bindings:** [field bindings for meta]
**Built:** YYYY-MM-DD
```

## component_registry.md

```markdown
## [Symbol Name]
**Root class:** .[class]
**Modifiers:** .[variant] × N
**CMS:** yes → [collection] | no
  - .[element] → [field-slug]
**Interaction:** [name]
**Cross-site safe:** yes | no
**Used on:** [pages]
**Built:** YYYY-MM-DD
```

## class_registry.md

```markdown
## [class-name]
**Purpose:** [one line]
**Styles:** [key properties with variable references]
**Responsive:** [breakpoint overrides or "none"]
**Symbol:** [symbol name or "none"]
**Used on:** [pages]
```

## variable_registry.md

Append new rows to the variables table:
```markdown
| --[variable-name] | [value] | [description / used for] |
```

## interaction_registry.md

```markdown
## [interaction-name]
**Trigger:** [type] | **Element:** .[class]
**Initial:** [state] | **Final:** [state]
**Duration:** [ms] | **Easing:** [curve] | **Stagger:** [ms or "none"]
**Used on:** [pages]
**Type:** IX2 | CSS | Custom JS
**Built:** YYYY-MM-DD
```

## error_learnings.md (only when directed by systematic-debugger)

```markdown
## [YYYY-MM-DD] [Bug title]
**Issue:** [what broke]
**Root cause:** [why]
**Fix:** [what solved it]
**Pattern:** [prevention]
```

---

## OUTPUT

```
doc-updater: Updated
  ✓ [registry].md — [what was added]
  ✓ [registry].md — [what was added]
```

## BUILD HANDOFF WRITE (write before session state)

```python
import json, os
handoff = {
  "agent": "doc-updater",
  "status": "complete",  # computed — see status rule below
  "outputs": {
    "registries_updated": []  # fill with actual list
  },
  "evidence": {
    "handoff_files_read": [],  # paths of docs/memory/webflow/handoff/*.json actually read
    "registry_entries_appended": 0  # count of entries actually appended across registries
  },
  "pending_designer_work": [],
  "registries_to_update_via_doc_updater": [],
  "next": "complete"
}
os.makedirs('docs/memory/webflow/handoff', exist_ok=True)
json.dump(handoff, open('docs/memory/webflow/handoff/doc-updater.json', 'w'), indent=2)
```

**Status honesty rule:** `status` is computed from actual results — set `"complete"` only when all steps succeeded AND `evidence` is non-empty (handoff files read, entries actually appended). Otherwise set `"partial"` or `"failed"`. Never hardcode `"complete"`.

## SESSION STATE WRITE

```
doc-updater [YYYY-MM-DD HH:MM]:
  REGISTRIES_UPDATED: [list]
  SESSION_COMPLETE: yes
  STATUS: complete
```

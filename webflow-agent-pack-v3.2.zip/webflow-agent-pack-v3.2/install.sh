#!/bin/bash
# Webflow Agent Pack v3.2 — Installer
set -e

PACK="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE="$HOME/.claude"

echo "=== Webflow Agent Pack v3.2 Installer ==="
echo "Source: $PACK"
echo "Target: $CLAUDE"
echo ""

mkdir -p "$CLAUDE/agents/webflow" "$CLAUDE/commands/webflow" "$CLAUDE/rules/webflow" "$CLAUDE/rules/common" "$CLAUDE/skills"

echo "Copying 19 agents..."
cp "$PACK/.claude/agents/webflow/"*.md "$CLAUDE/agents/webflow/"

echo "Copying 19 commands..."
cp "$PACK/.claude/commands/webflow/"*.md "$CLAUDE/commands/webflow/"

echo "Copying 5 rules..."
cp "$PACK/.claude/rules/webflow/"*.md "$CLAUDE/rules/webflow/"
cp "$PACK/.claude/rules/common/"*.md "$CLAUDE/rules/common/"

echo "Copying skills..."
cp "$PACK/.claude/skills/"*.md "$CLAUDE/skills/"

# v3.2: platform-scoped registries — Webflow memory lives in docs/memory/webflow/
# (Divi uses docs/memory/divi/, Elementor uses docs/memory/elementor/ — never mixed)
echo "Seeding project memory (docs/memory/webflow/) in current directory..."
if [ ! -d "docs/memory/webflow" ]; then
  mkdir -p docs/memory/webflow/handoff
  cp "$PACK/docs/memory/webflow/"*.md "$PACK/docs/memory/webflow/"*.json docs/memory/webflow/ 2>/dev/null || true
  echo "  Seeded registry templates."
else
  echo "  docs/memory/webflow already exists — skipped (never overwrites existing registries)."
fi

echo ""
echo "=== NEXT: Add Webflow MCP Token ==="
echo ""
echo "1. Get token: Webflow Dashboard → Account Settings → Integrations → API Access"
echo ""
echo "2. Add to ~/.claude/settings.json (mcpServers section):"
echo '   "webflow": {'
echo '     "command": "npx",'
echo '     "args": ["-y", "@webflow/mcp-server@latest"],'
echo '     "env": { "WEBFLOW_TOKEN": "YOUR_TOKEN" }'
echo '   }'
echo ""
echo "3. Restart Claude Code"
echo ""
echo "=== Done. /webflow: commands are now active. ==="

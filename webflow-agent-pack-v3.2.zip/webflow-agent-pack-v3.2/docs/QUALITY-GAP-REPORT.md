# Quality Gap Report — Native Webflow Work Only

Date: 2026-07-02. Scope: v3.1 pack, native Webflow paths (elements, class styles, variables, IX2, breakpoints, CMS binding). Method: 3 independent audits (silent-failure paths, native capability coverage, QA enforcement), deduplicated.

**Core diagnosis:** "Pipeline says success, site shows nothing" is the expected behavior of the current design, not an edge case. Every PASS/FAIL decision flows from agent-authored JSON whose templates default to `complete`. The pack has exactly one real site-truth read (webflow-builder VERIFY BUILD) and it is advisory — not wired to any status field. Three whole categories of visible output — class styles, responsive breakpoints, IX2 interactions — are structurally guaranteed to require human Designer work that no artifact tracks.

---

## A. Why you get NO RESULT (blank/unstyled/missing output while pipeline reports success)

### A1. Class styles are never created — THE top cause  `CRITICAL`
- webflow-builder attaches class **names** to nodes (`"classes": ["hero"]`). No pipeline step ever tasks style application: orchestrator A2/E1 task style-manager with **variables only**, never its STEP 2 class-style application.
- API mode has no styles endpoint documented anywhere (webflow-api.md lists none); styles exist only as "DESIGNER STEPS" text.
- Result: page renders as unstyled stacked HTML → looks blank/broken. Both agents legitimately report `complete`; every gate passes.
- Files: webflow-orchestrator.md (A2/E1 prompts), webflow-builder.md (BUILD/QUALITY CHECKLIST), style-manager.md (STEP 2 never invoked), webflow-api.md.

### A2. Gates verify self-reported JSON, never the site  `CRITICAL`
- STEP 3 verification reads `build_handoff.json` / `session_state.md` — files the audited agent itself wrote. Handoff templates in style-manager, class-manager, webflow-builder **hardcode** `"status": "complete"`; no failure/partial branch exists.
- VERIFY BUILD can print `Section found: False` and the agent still writes `complete` — verify outcome is not wired to handoff status.
- No gate ever calls element_snapshot_tool / style read-back / pages GET.
- Files: webflow-orchestrator.md:99–131, webflow-builder.md (VERIFY BUILD → HANDOFF WRITE), style-manager.md, class-manager.md.

### A3. Single shared build_handoff.json — parallel clobber  `CRITICAL`
- Every agent writes the SAME file. A2/E1 run class-manager + style-manager in parallel → last writer wins. Gate condition "both STATUS: complete in build_handoff.json" is impossible to satisfy from one file.
- A crashed agent is masked by the previous agent's stale `complete`. quality-gate's 5 parallel agents clobber each other the same way. doc-updater's "union of all registries from each handoff" is unrecoverable.
- Files: webflow-orchestrator.md (A2/E1/N), all agent handoff writers, quality-gate.md.

### A4. Nothing reaches the live site — no publish in any pipeline  `CRITICAL`
- All API/MCP writes are staged-only. Pipelines A–E end at doc-updater; nothing states the staged/live distinction or prompts publish. User opens live URL → nothing there.
- Files: webflow-orchestrator.md (pipelines), publish.md (separate command only).

### A5. `POST /pages/{id}/dom` replaces ALL page content  `CRITICAL`
- webflow-api.md warns the endpoint "replaces ALL content", but the builder's API flow POSTs `/tmp/build_nodes.json` directly — no GET-current-DOM → merge step. Building section 2 silently deletes section 1.
- Files: webflow-builder.md (BUILD — API MODE), webflow-api.md.

### A6. Native components never initialize when created via API  `CRITICAL`
- Slider/Tabs/Navbar are mandated as native nodes, but API-created instances lack Designer-assigned `w-slider-*`/`w-tab-*` IDs → Webflow.js never initializes them: blank slider tracks, dead tabs, broken mobile nav **on the original site**. cross-site-portability.md documents this mechanism but frames it only as a copy problem; the builder is never told.
- Files: webflow-builder.md (NODE TYPE REFERENCE), cross-site-portability.md.

### A7. IX2 interactions = untracked human homework  `HIGH`
- IX2 cannot be created via API/MCP. interaction-builder outputs specs, sets `designer_steps_required: True` **and** `status: complete`. Nothing tracks whether a human ever built them; no user-facing warning that the site has zero animations until then. If initial-hidden states were pre-applied → elements frozen invisible.
- Files: interaction-builder.md, webflow-orchestrator.md (A5 gate).

### A8. Responsive overrides = untracked DESIGNER STEPS text  `HIGH`
- style-manager's STYLE EFFICIENCY RULE deliberately skips tablet/mobile via style_tool, emitting "RESPONSIVE DESIGNER STEPS" prose; handoff sets `responsive_steps_provided: True` + `complete`. Builder checklist only requires overrides be *listed*. Desktop right, tablet/mobile broken, gates green.
- Files: style-manager.md, webflow-builder.md (RESPONSIVE REQUIREMENTS + checklist).

### A9. Build success detection broken  `HIGH`
- API build: `Built: 0 nodes` not treated as failure; `curl -s` hides HTTP status; only `section`-type IDs captured.
- PAGE_ID never sourced: orchestrator prompts pass no page id/slug; checkpoint defaults `'page_id': ''`; no locale handling → build lands on wrong page/locale, "success" reported.
- MCP build procedure = 4 comment lines; no error protocol for element_builder partial writes / mid-build 429s.
- Checkpoint/resume: `sections_built.append` unconditional (duplicates on resume); "start fresh" never clears build_state.json or deletes partial nodes → duplicated or missing sections.
- Files: webflow-builder.md.

### A10. Blank-by-design content not surfaced  `HIGH`
- Image `src` intentionally empty ("user uploads in Designer"); "DESIGNER STEPS NOW" + "✗ NOT built" exist only as terminal text — not persisted in handoff, not aggregated, not blocking. Hero ships as empty boxes, pipeline complete.
- Files: webflow-builder.md (BUILD REPORT / AFTER BUILD).

---

## B. Native capability coverage gaps (quality lacking even when something builds)

| # | Gap | Consequence | Sev |
|---|-----|-------------|-----|
| B1 | `dropdown`, `lightbox`, background-video absent from node-type reference | Nav dropdowns/mega-menus/galleries faked with div+JS or omitted | HIGH |
| B2 | Form spec = `form-block → form-form → inputs` only; no label/input/textarea/select/checkbox/radio/submit node types, no `form-success`/`form-error` divs | Structurally incomplete forms, no success/error states | HIGH |
| B3 | CMS binding under-specified: one `xattr` example; no link-block href→CMS page, RichText binding, list limit/sort/filter, nested-list limits, conditional visibility; cms-builder claims "connects collections to elements" but has zero connect steps | Empty or unbound collection lists; template pages unbound | CRITICAL |
| B4 | Variable binding ambiguity: pack mandates `var(--space-5xl)` strings, but native Webflow variables are Designer-bound with generated names; native-bind vs `:root` inject never resolved | `var()` references undefined → properties silently invalid | HIGH |
| B5 | Breakpoint-specific style setting has no documented API/MCP method (style_tool breakpoint params unspecified) | "Verify 4 breakpoints" unactionable; box checked, no breakpoint work exists | HIGH |
| B6 | `<details>/<summary>` accordion labeled "Level 1" but Webflow has no native details element — requires html-embed (L7, banned) | Agent silently violates its own ban or deadlocks | MEDIUM |
| B7 | Combo classes: applying two class names via API ≠ Designer combo style (modifier becomes free-standing global class, different cascade) | Modifier styles bleed or fail to override | MEDIUM |
| B8 | `component` node listed with `componentId` but no list endpoint, no "instances only reference existing Designer components" note | Phantom componentId, fake success; registry entries for Symbols that never exist | MEDIUM |
| B9 | richtext: no `.w-richtext` tag-level styling guidance, no CMS RichText binding steps | Blog templates ship unstyled/unbound | MEDIUM |
| B10 | cms-builder schema template requires `Slug` field but field-type table lacks it (slug/name are auto-created, not addable) | 422 mid-schema → partial collections | MEDIUM |

---

## C. QA theater (declared checks with no enforcement)

| # | Gap | Consequence | Sev |
|---|-----|-------------|-----|
| C1 | quality-gate description promises "responsive verification and accessibility check" — body runs SEO/security/perf/class/CMS agents; neither check exists | The two checks most tied to visible quality never run | CRITICAL |
| C2 | publish checklist ("quality-gate passes", "verified at 3 breakpoints") is inert markdown — publish curl has no dependency on any gate verdict | NEEDS FIXES verdict + successful production publish coexist | CRITICAL |
| C3 | figma-to-webflow Phase 5 "comparison report" = structural node diff only; no visual fidelity step (no render/screenshot vs Figma) anywhere in pack | Structurally correct, visually wrong builds pass every gate | CRITICAL |
| C4 | fix-responsive ends at fix list + "user verifies in Designer" — no applied-check, no re-audit | Fixes exist only as text | HIGH |
| C5 | systematic-debugger has no "nothing appears on page" classification/evidence route (styles-not-attached, draft-vs-published, wrong page, IX2 opacity-0) | Pack's most likely failure mode has no diagnostic path | HIGH |
| C6 | Builder QUALITY CHECKLIST: no PASS/FAIL semantics, no blocking of `complete`; several items unverifiable by the agent itself | Self-attestation with no consequence | HIGH |
| C7 | Registry-based audits (hex/px, classes) check self-reported registries, not live site styles | Clean on paper, wrong on site, divergence undetected | HIGH |
| C8 | Post-publish check = HTTP 200 + `grep -c "service-card"` (hardcoded class) | Blank/opacity-0 pages pass | MEDIUM |
| C9 | create-section pipeline has no verification/quality stage at all | Every gap above flows through uninspected | MEDIUM |
| C10 | class-manager STEP 3 "Verify Node Tree Compliance" is dead code — runs before builder in every pipeline, never re-invoked | Orphan modifiers/unplanned classes never caught | MEDIUM |

---

## Severity summary

| Severity | Count | Themes |
|---|---|---|
| CRITICAL | 9 | styles never created; self-reported gates; handoff clobber; no publish; DOM replace-all; components don't init; CMS binding; QG missing checks; no visual fidelity |
| HIGH | 12 | IX2/responsive untracked homework; broken success detection; page-id/locale; missing native elements; variable binding; checklist theater |
| MEDIUM | 10 | combos, richtext, symbols, slug field, dead steps, weak post-publish check |

## Fix priority if/when requested

1. **A1 + A2** — wire style application into pipelines + make gates read site state (element_snapshot/style read-back) and forbid pre-filled `complete`. Fixes most "no result" cases.
2. **A3** — per-agent handoff files (`build_handoff.{agent}.json`).
3. **A5 + A9** — GET-merge before DOM POST; treat 0-nodes/found:False as failure; pass PAGE_ID explicitly.
4. **A4 + A6 + A7 + A8** — end-of-pipeline "PENDING DESIGNER WORK" ledger + staged-vs-live notice.
5. **B3, B1, B2** — native binding/element guidance.
6. **C1–C3** — real responsive/visual checks in quality-gate; publish blocked on verdict.

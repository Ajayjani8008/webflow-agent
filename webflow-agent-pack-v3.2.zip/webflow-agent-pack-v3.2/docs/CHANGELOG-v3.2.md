# Webflow Agent Pack v3.2 — Changelog

**Released:** 2026-07-03
**Base:** v3.1 (2026-07-02, quality-gap fixes)

## Platform-Scoped Registries (breaking change)

All registry, handoff, and ledger paths moved from shared `docs/memory/` to
platform-scoped `docs/memory/webflow/`. Webflow is Webflow, Divi is Divi —
platforms never share registry files again.

### Why
Prior packs (Webflow, Divi, Elementor) all wrote to relative `docs/memory/`.
Running two platforms from the same working directory contaminated registries:
`session_state.md` and `style_registry.md` accumulated mixed Webflow + Divi
entries, and doc-updater appended Webflow variables into Divi's style registry.

### What changed
- All 19 agents + commands: every `docs/memory/...` path is now `docs/memory/webflow/...`
  (mechanical path replace only — no agent logic touched, zero behavior change otherwise)
- Handoff files: `docs/memory/webflow/handoff/*.json`
- Designer ledger: `docs/memory/webflow/pending_designer_work.md`
- Design specs: `docs/memory/webflow/design_spec_current.md`
- Build state: `docs/memory/webflow/build_state.json`
- Webflow uses `variable_registry.md` (NOT `style_registry.md` — that filename is Divi's)

### Pack additions
- `docs/memory/webflow/` template set: clean seed files for all 8 registries +
  `handoff/` dir. install.sh seeds them into the project working directory
  (never overwrites existing registries).

### Migration from v3.1 or earlier
If an existing project has files at `docs/memory/` root:
1. `mkdir -p docs/memory/webflow/handoff`
2. Move Webflow files: `build_state.json`, `class_registry.md`,
   `variable_registry.md`, `cms_registry.md`, `component_registry.md`,
   `interaction_registry.md`, `page_registry.md`, `pending_designer_work.md`,
   `session_state.md`, `handoff/` → into `docs/memory/webflow/`
3. If `session_state.md` or `style_registry.md` contain mixed platform entries,
   split by entry: Webflow entries (class-manager BEM, webflow-builder node IDs,
   IX2) stay; Divi entries (et_pb_*, CPT, divi-builder) go to `docs/memory/divi/`
4. Webflow variables found in `style_registry.md` belong in
   `docs/memory/webflow/variable_registry.md`

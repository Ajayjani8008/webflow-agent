# Interaction Registry (Webflow)

All interactions/animations with timing, easing, trigger specs. Same interaction type = same timing site-wide.

_No interactions registered yet._

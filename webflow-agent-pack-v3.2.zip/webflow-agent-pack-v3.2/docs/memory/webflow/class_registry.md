# Class Registry (Webflow)

All CSS classes used on this site. Check before creating any new class.

---

## Global Utilities (pre-registered — do not recreate)

| Class | Type | Description |
|-------|------|-------------|
| `.container` | utility | Max-width centering wrapper with horizontal padding |
| `.btn` | utility-base | Base button class — all buttons carry this as first class |
| `.btn--primary` | utility-modifier | Primary CTA button (combo with .btn) |
| `.btn--outline` | utility-modifier | Outline/secondary button (combo with .btn) |

_No section classes registered yet._

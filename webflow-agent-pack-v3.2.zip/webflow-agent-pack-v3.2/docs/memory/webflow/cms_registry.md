# CMS Registry (Webflow)

All CMS collections, fields, and bindings. Document schema here BEFORE creating in Webflow.

_No collections registered yet._

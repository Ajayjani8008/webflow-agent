# Variable Registry (Webflow)

All Webflow design variables (Base collection). Check before creating any new variable.

_No variables registered yet._

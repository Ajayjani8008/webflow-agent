---
name: project-map
description: Rebuilds docs/maps/project_map.md after major features. Maps all pages, collections, symbols, and their relationships. Shows blast radius — what breaks if a Symbol or class is changed.
model: claude-haiku-4-5-20251001
---

## CONTEXT — Parse from prompt first (mandatory)

Called by webflow-orchestrator via Agent tool. Before doing ANYTHING else, parse:
- `SITE: [name] | SITE_ID: [id] | DOMAIN: [domain]` — site context for all API calls
- `MCP_MODE: true/false` — **if true: use `mcp__claude_ai_Webflow__*` tools; if false: use REST API**
- `TASK:` — your specific instructions
- Registry content pasted inline — use it directly, no need to re-read those files

**If MCP_MODE: true** → check your tool list for `mcp__claude_ai_Webflow__*`, use them as primary.
**If MCP_MODE: false** → use Webflow REST API v2 with `$WEBFLOW_API_KEY`.

If called directly without orchestrator: check tool list yourself for MCP tools; read `docs/memory/project_overview.md` for site context.

**HARD STOP conditions** — stop immediately and report to user:
- SITE or SITE_ID missing and cannot be determined → stop, ask
- Required registry file empty when task depends on it → stop, report
- MCP tool call returns error → stop, show exact error, do not retry blindly

---

# Project Map Agent (Webflow)

Rebuild `docs/maps/project_map.md`. Fire in background after major features.

---

## Build the Map

Read all registry files and produce:

```markdown
# Project Map — {SITE_NAME}
Last updated: YYYY-MM-DD

## Site Structure

/ (Home)
├── /about
├── /services
│   └── /services/{slug}     [CMS: Services collection]
├── /blog
│   ├── /blog/category/{slug} [CMS: Categories]
│   └── /blog/{slug}          [CMS: Blog Posts]
├── /team
├── /contact
└── /404, /search, /privacy

## CMS Collections

| Collection | ID | Items | Template page | References |
|-----------|-----|-------|--------------|-----------|
| Services | col_xxx | 12 | /services/{slug} | — |
| Blog Posts | col_xxx | 34 | /blog/{slug} | Authors (ref), Categories (multi-ref) |
| Team Members | col_xxx | 8 | — (listed on /team) | — |

## Symbols (Blast Radius)

| Symbol | Used on pages | Change impact |
|--------|--------------|--------------|
| Main Nav | ALL pages | HIGH — edit carefully |
| Site Footer | ALL pages | HIGH — edit carefully |
| Service Card | /services, / | MEDIUM — 2 pages |
| CTA Banner | /services, /about, /blog | MEDIUM — 3 pages |
| Section Header | / , /about, /services, /blog, /team | HIGH — 5 pages |

## Class Usage

| Class | Used in Symbols | Used on pages | Change impact |
|-------|----------------|--------------|--------------|
| .container | ALL symbols | ALL pages | CRITICAL |
| .btn--primary | Nav, CTA Banner, Hero | ALL pages | HIGH |
| .service-card | Service Card symbol | /services, / | MEDIUM |
| .hero__title | / | / only | LOW |

## Variables (Blast Radius)

| Variable | Used by classes | Change impact |
|---------|----------------|--------------|
| --color-primary | btn--primary, nav__link--active, card__tag | HIGH — affects all CTAs |
| --color-text | body, all text elements | CRITICAL |
| --space-xl | cards, sections, containers | HIGH |

## Interactions

| Interaction | Trigger element | Pages |
|-------------|----------------|-------|
| card-hover-lift | .service-card, .blog-card | /services, /blog, / |
| scroll-reveal | .section, .card | All content pages |
| nav-scroll-change | .navbar | All pages |
| hero-load | .hero | / , /about |

## Custom Code

| Location | Purpose | Risk |
|---------|---------|------|
| Site footer | Analytics, chat widget | LOW |
| Site head | Preconnect fonts, meta | LOW |
| /blog/{slug} | Article schema JSON-LD | LOW |
| /contact | Form validation JS | MEDIUM |
```

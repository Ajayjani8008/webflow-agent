#!/bin/bash
# Webflow Agent Pack — Installer
# Run once: bash install.sh
# After this, agents are available in every project on this machine.

set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.claude"

echo ""
echo "Installing Webflow Agent Pack..."
echo ""

# Agents
mkdir -p "$DEST/agents/webflow"
cp "$DIR/.claude/agents/webflow/"*.md "$DEST/agents/webflow/"
echo "✓  Agents     →  ~/.claude/agents/webflow/   ($(ls "$DEST/agents/webflow/" | wc -l | tr -d ' ') agents)"

# Commands
mkdir -p "$DEST/commands/webflow"
cp "$DIR/.claude/commands/webflow/"*.md "$DEST/commands/webflow/"
echo "✓  Commands    →  ~/.claude/commands/webflow/ ($(ls "$DEST/commands/webflow/" | wc -l | tr -d ' ') commands)"

# Skills (add only — never overwrite existing skills)
mkdir -p "$DEST/skills"
for f in "$DIR/.claude/skills/"*.md; do
  name=$(basename "$f")
  if [ ! -f "$DEST/skills/$name" ]; then
    cp "$f" "$DEST/skills/$name"
    echo "✓  Skill       →  ~/.claude/skills/$name"
  else
    echo "~  Skill        $name already exists — skipped"
  fi
done

# Rules
mkdir -p "$DEST/rules/webflow" "$DEST/rules/common"
cp "$DIR/.claude/rules/webflow/"*.md "$DEST/rules/webflow/"
cp "$DIR/.claude/rules/common/"*.md  "$DEST/rules/common/" 2>/dev/null || true
echo "✓  Rules       →  ~/.claude/rules/webflow/"

echo ""
echo "Global install complete. Agents available in every project."
echo ""
echo "──────────────────────────────────────────────"
echo "NEXT: set up your Webflow project"
echo "──────────────────────────────────────────────"
echo ""
echo "1. Copy project files into your project folder:"
echo ""
echo "   cp \"$DIR/CLAUDE.md\"    /path/to/your/project/"
echo "   cp -r \"$DIR/docs/\"     /path/to/your/project/"
echo ""
echo "2. Fill in your site details:"
echo "   Open: /path/to/your/project/docs/memory/project_overview.md"
echo "   Add:  Site Name, Site ID, Domain"
echo ""
echo "3. Set credentials (pick one):"
echo "   A) Connect Webflow in claude.ai → Integrations → Webflow  (recommended)"
echo "   B) Add to .claude/settings.local.json in your project:"
echo "      { \"env\": { \"WEBFLOW_API_KEY\": \"wf_...\", \"WEBFLOW_SITE_ID\": \"...\" } }"
echo ""
echo "4. Open your project in Claude Code and start building."
echo ""
echo "Read HOW_TO_USE.md for full guide."
echo ""

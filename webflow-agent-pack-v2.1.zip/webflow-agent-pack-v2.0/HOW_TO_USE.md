# Webflow Agent System — Complete Guide
**Version: 2.0 — 2026-05-30**

---

## What's New in v2.0

### Bug Fixes & Quality Improvements (40–50% → 90%+ target)

| Fix | What changed |
|-----|-------------|
| Native-first enforcement gate | Orchestrator Pipeline E now BLOCKS html-embed without Level 1-6 exhaustion justification + user approval |
| style-manager rewrite | Now uses `mcp__claude_ai_Webflow__style_tool` (MCP) or outputs DESIGNER STEPS (API mode). No more CSS injection via `headCode` |
| Responsive overrides applied | style-manager Step 3.5 actually applies tablet/mobile breakpoint overrides (were specced but never sent to Webflow in v1.x) |
| Accordion animation fixed | Uses `max-height` CSS transition (was animating `height` — forbidden, janky) |
| Structured session state | All agents use typed-field schema in `session_state.md`. Verification gate uses field checks, not string matching |
| build_state.json | Checkpoint file is now JSON (was `.md`) — prevents `json.load()` parse failures on session resume |
| Class audit step | webflow-builder Step 4.5 cross-checks built nodes against class plan, flags unregistered classes |
| Code reviewer auto-trigger | Runs automatically (Pipeline E step 3.5) when any custom JS/CSS/HTML embed is added |
| fr-analyst model | Downgraded to Sonnet (was Opus — no gain using frontier model for requirements analysis) |
| Tabs/accordion routing | interaction-builder now routes unambiguously: native Tabs always first, `<details>`/`<summary>` for accordion |
| screenshot-analyst native table | Step 2.8 now classifies slider/tabs/accordion/form/navbar to native types before spec writing |

---

---

## What Is This?

A multi-agent AI system for building Webflow sites inside Claude Code.

You describe what you want. The **orchestrator** figures out which specialist to call. The specialist does the work — calling Webflow APIs, reading Figma files, building DOM nodes, managing CMS, writing interactions — and writes results back so the next agent picks up exactly where the last one stopped.

**One entry point. 19 specialist agents. Fully automated.**

---

## What's Inside

```
webflow/
├── install.sh                  ← run once to install globally
├── HOW_TO_USE.md               ← this file
└── template/
    ├── CLAUDE.md               ← project instructions (copy to your project)
    ├── docs/memory/            ← project state files (copy to your project)
    └── .claude/
        ├── agents/             ← 19 agent definition files
        ├── commands/           ← 19 slash commands
        ├── skills/             ← 5 reference skill files
        ├── rules/              ← 4 coding rule files
        └── settings.json       ← permissions + hooks + model config
```

### The 19 Agents

| Agent | Role | Model |
|-------|------|-------|
| **webflow-orchestrator** | Entry point. Detects intent, routes to correct specialist, verifies output, passes context between agents | Sonnet |
| **figma-analyst** | Reads Figma API, traverses node tree 8 levels, classifies every layer, extracts design tokens, produces Design Spec | Sonnet |
| **screenshot-analyst** | Reads any image/screenshot via vision, estimates layout/spacing/colors, produces Design Spec with confidence ratings | Sonnet |
| **webflow-builder** | Builds pages and sections via MCP tools or REST API. Native elements first, html-embed last resort | Sonnet |
| **class-manager** | Designs BEM class system before any build. Checks registry, never duplicates, enforces naming | Sonnet |
| **style-manager** | Creates/manages Webflow Variables (colors, spacing, typography). Never hardcodes values | Sonnet |
| **cms-builder** | Creates CMS collections, designs schemas, adds fields, populates items, connects to page elements | Sonnet |
| **interaction-builder** | Designs Webflow Interactions 2.0 or portable CSS/JS. Consistent timing/easing across site | Sonnet |
| **component-builder** | Creates Webflow Symbols (reusable components). Builds node structure, registers in registry | Sonnet |
| **seo-optimizer** | Sets title, meta description, OG tags, structured data (JSON-LD), canonical URLs via API | Sonnet |
| **performance-optimizer** | Audits Core Web Vitals, image optimization, JS weight. Returns specific fixes with LCP/CLS impact | Sonnet |
| **systematic-debugger** | Root-cause diagnosis only. Never guesses. Requests evidence first, classifies fast-track vs full investigation | Sonnet |
| **code-reviewer** | Reviews custom HTML/CSS/JS embeds for quality, security basics, and class consistency | Sonnet |
| **security-reviewer** | Scans for XSS, exposed API keys, insecure forms, unsafe third-party scripts | Sonnet |
| **fr-analyst** | Turns vague feature requests into 3 structured FR docs. Waits for human confirmation before planning | Sonnet |
| **planner** | Reads FR docs, produces phase-by-phase implementation plan with agent assignments | Opus |
| **architect** | Architecture decisions — CMS schema, page hierarchy, Symbol structure, ADRs | Opus |
| **doc-updater** | Updates all memory registry files after every build. Runs in background | Haiku |
| **project-map** | Rebuilds blast-radius map after major features. Shows what breaks if a Symbol or class changes | Haiku |

### The 19 Slash Commands

```
/webflow:figma-to-webflow        Figma URL → Webflow layout
/webflow:screenshot-to-webflow   Screenshot or image → Webflow layout
/webflow:create-page             New page with SEO meta
/webflow:create-section          New section on existing page
/webflow:create-component        New Webflow Symbol
/webflow:create-cms-collection   New CMS collection with fields
/webflow:sync-cms                Import CSV/JSON/API data into CMS
/webflow:set-variables           Install or update CSS design variables
/webflow:connect-cms             Connect page elements to CMS fields
/webflow:add-interaction         Add animation or interaction
/webflow:fix-spacing             Audit and fix spacing inconsistency
/webflow:fix-responsive          Audit and fix breakpoint issues
/webflow:publish                 Publish to staging or production
/webflow:plan                    Feature request → FR docs → plan
/webflow:debug                   Root-cause debug (mandatory for bugs)
/webflow:quality-gate            Full pre-publish audit
/webflow:webflow-audit           Site health check
/webflow:code-review             Custom code quality review
/webflow:security-review         Security scan
```

### The 5 Reference Skills

Available to all agents during their work:

| Skill | Contains |
|-------|---------|
| `webflow-api` | Complete Webflow REST API v2 — endpoints, auth, rate limits, node types |
| `figma-bridge` | Figma node → Webflow element mapping, auto-layout to flex rules |
| `class-system` | Full BEM class catalogue, naming rules, combo class patterns |
| `cms-patterns` | Common CMS schemas, Collection List patterns, field types |
| `interactions` | Webflow Interactions 2.0 reference, easing values, timing standards |

### The Memory Files

Each project gets its own `docs/memory/` folder. Agents read and write these to stay in sync across sessions:

| File | What it stores |
|------|---------------|
| `project_overview.md` | Site name, ID, domain, purpose — fill once at setup |
| `session_state.md` | What each agent did, handoff context, status |
| `build_state.md` | In-progress build checkpoint — what's built, what's not, node IDs |
| `page_registry.md` | All pages, sections, symbols used, classes applied |
| `class_registry.md` | Every CSS class — BEM name, element, purpose |
| `variable_registry.md` | All design tokens — name, value, type |
| `cms_registry.md` | All CMS collections — schema, field slugs, item count |
| `component_registry.md` | All Symbols — structure, variants, where used |
| `interaction_registry.md` | All interactions — trigger, timing, easing, elements |
| `error_learnings.md` | Bug patterns found and fixed — prevents repeating mistakes |

---

## Install

### Step 1 — Run the installer (once per machine)

```bash
cd /path/to/webflow-agnet/webflow
bash install.sh
```

Done. All 19 agents, 19 commands, 5 skills, and 4 rules are now globally available in every project on this machine.

**What gets installed where:**

```
~/.claude/
├── agents/webflow/     ← 19 agent files (globally available)
├── commands/webflow/   ← 19 slash commands
├── skills/             ← 5 skill files added
└── rules/webflow/      ← 4 rule files (auto-applied)
```

### Step 2 — Set up your Webflow project

In your project folder, copy the project files from the template:

```bash
# Replace /path/to/your/project with your actual project folder
cp /path/to/webflow-agnet/webflow/template/CLAUDE.md   /path/to/your/project/
cp -r /path/to/webflow-agnet/webflow/template/docs/    /path/to/your/project/
```

Open `/path/to/your/project/docs/memory/project_overview.md` and fill in your site details:

```markdown
Site Name: My Webflow Site
Site ID:   64abc123def456
Domain:    mysite.com
Purpose:   SaaS landing page for project management tool. Targets small business owners.
```

### Step 3 — Connect to Webflow

**Option A — Webflow MCP Connector (recommended)**

Connect Webflow in claude.ai → Integrations → Webflow.
Agents detect MCP tools automatically. No API keys needed. Site found by name.

**Option B — REST API Key**

Create `.claude/settings.local.json` in your project (never commit this file):

```json
{
  "env": {
    "WEBFLOW_API_KEY": "wf_your_api_key_here",
    "WEBFLOW_SITE_ID": "your_site_id_here",
    "FIGMA_TOKEN": "figd_your_figma_token_here"
  }
}
```

**Get API key:** Webflow → Account Settings → Integrations → API Access → Generate Token
Required scopes: `pages:read pages:write cms:read cms:write sites:read assets:read custom_code:write sites:publish`

**Get Site ID:** Webflow → Project Settings → General → Site ID

**Get Figma token** (only needed for Figma pipeline): Figma → Settings → Security → Personal access tokens → Generate

---

## How to Use

### Just talk — orchestrator handles routing

Open Claude Code in your project folder and describe what you want. No special syntax needed.

```
"Build me a hero section with a big headline, subtext, and a CTA button"
"Here's my Figma design: https://www.figma.com/design/..."
"The testimonials slider is broken on mobile"
"I want to add a blog with categories and author pages"
```

The orchestrator reads your message, detects intent, echoes back what it understood, and asks you to confirm before calling any agent.

### What you say → what happens

| You say / send | Pipeline triggered |
|---------------|-------------------|
| Figma URL | figma-analyst → class-manager → style-manager → webflow-builder |
| Screenshot or image attached | screenshot-analyst → class-manager → style-manager → webflow-builder |
| "build a [section/page]" | class-manager → style-manager → webflow-builder |
| "not working" / "broken" / "fix" | systematic-debugger → fix agent |
| "add hover/scroll/animation" | interaction-builder |
| "create CMS / blog / team / services" | cms-builder |
| "add color/spacing/font variable" | style-manager |
| "create nav/footer/card component" | component-builder |
| "set SEO / meta / OG tags" | seo-optimizer |
| "fix performance / LCP slow" | performance-optimizer |
| "security check" | security-reviewer |
| `feat::` prefix or "I want to add..." | fr-analyst → planner → build |
| Unclear / vague | orchestrator asks one clarifying question |

### Figma → Webflow (step by step)

```
1. Paste Figma URL in your message
2. figma-analyst fetches design, traverses all layers, extracts tokens
3. Agent echoes: sections found, elements classified, CMS detected, interactions listed
4. You confirm or correct the spec
5. class-manager designs the class system (checks registry first)
6. style-manager creates any missing variables in Webflow
7. webflow-builder builds the DOM nodes via MCP or REST API
8. interaction-builder adds animations if spec includes them
9. seo-optimizer sets page meta if it's a new page
10. doc-updater updates all registries in background
```

### Screenshot → Webflow

Same as Figma but attach any image — screenshot of a reference site, Figma export, design mockup photo. The screenshot-analyst estimates layout and confidence-rates every element. Low-confidence items are flagged for your confirmation before building starts.

### Resuming after interruption

If a build was interrupted (token limit, API error, you closed Claude), open the project again. The orchestrator reads `docs/memory/build_state.md` and tells you what was completed and what's left. Say "resume" and it continues from the checkpoint.

---

## How Agents Work Together

```
Your message
    ↓
webflow-orchestrator
  ├─ reads session_state.md + all registries
  ├─ detects MCP or REST API mode
  ├─ detects intent → selects pipeline
  ├─ echoes back + waits for confirm
  │
  ├─ Agent("figma-analyst", prompt with full context)
  │     ↓ returns Design Spec
  │  [VERIFY GATE — checks session_state.md]
  │
  ├─ Agent("class-manager", prompt with Design Spec)
  │     ↓ returns class plan
  │  [VERIFY GATE]
  │
  ├─ Agent("style-manager", ...)  ←── parallel
  ├─ Agent("cms-builder", ...)    ←── parallel (if CMS needed)
  │  [VERIFY GATE — both must complete]
  │
  ├─ Agent("webflow-builder", prompt with spec + classes + variables)
  │     ↓ returns node IDs
  │  [VERIFY GATE — node IDs must be present]
  │
  ├─ Agent("interaction-builder", prompt with node IDs)
  └─ Agent("doc-updater", full session log)  ← always, background
```

Each agent runs in its own isolated context. It receives everything it needs in its prompt. All persistent state lives in `docs/memory/` — not in any agent's memory. This is why the system survives token limits and session restarts.

**Verification gates:** the orchestrator checks `session_state.md` after every agent call. If an agent didn't complete its work, the orchestrator stops and tells you — it never silently skips past a failure.

---

## MCP vs REST API

| | MCP Mode | REST API Mode |
|---|---|---|
| How to enable | Connect Webflow in claude.ai integrations | Set `WEBFLOW_API_KEY` + `WEBFLOW_SITE_ID` env vars |
| Site detection | Automatic by name | Must set `WEBFLOW_SITE_ID` manually |
| Build tool | `element_builder`, `whtml_builder` | POST to `/v2/pages/{id}/dom` |
| Styles/Variables | `style_tool`, `variable_tool` | Webflow Variables API |
| CMS | `data_cms_tool` | Webflow CMS REST API |
| Priority | Primary (used first) | Fallback (used if MCP not available) |

Agents detect which mode is active at session start. You don't configure this — it's automatic.

---

## Sharing With Another User

The entire system lives in this `webflow/` folder. To share:

```bash
# Zip it
zip -r webflow-agents.zip webflow/ --exclude "*/.DS_Store" --exclude "*/.remember/*"
```

Recipient installs:

```bash
unzip webflow-agents.zip
cd webflow
bash install.sh
```

Then they copy `template/CLAUDE.md` and `template/docs/` into their project, fill in their site details, set credentials — done.

---

## Updating an Agent

Edit in `template/.claude/agents/` (the source of truth), then re-run `install.sh`:

```bash
# Edit
code template/.claude/agents/webflow-builder.md

# Push to global
bash install.sh
```

---

## Adding a New Platform (e.g. WordPress)

This system installs under `~/.claude/agents/webflow/`. A WordPress system would go under `~/.claude/agents/wordpress/`. Completely separate. No conflicts.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Agent not calling specialists | Check `docs/memory/session_state.md` — orchestrator logs every call and gate result |
| "SITE or SITE_ID missing" | Fill `docs/memory/project_overview.md` or set `WEBFLOW_SITE_ID` env var |
| MCP tools not detected | Check Webflow connector is connected in claude.ai → Integrations. API fallback activates automatically |
| Build stopped mid-section | Normal — token limit checkpoint. Restart session, orchestrator resumes from `build_state.md` |
| Classes being duplicated | Run `/webflow:webflow-audit` to sync `class_registry.md` with actual site |
| Figma fetch failing | Check `FIGMA_TOKEN` is set. Verify URL has `node-id` param. Regenerate token in Figma → Settings → Security |
| Interaction not applying | interaction-builder needs node IDs from webflow-builder — check `session_state.md` has "webflow-builder done" entry before calling interaction-builder |

# CMS Registry — {{SITE_NAME}}

Auto-updated by `doc-updater` + `cms-builder`. Document every collection here BEFORE creating in Webflow.

---

<!-- EXAMPLE ENTRY — remove when adding real entries

## Services

**Webflow slug:** services
**Collection ID:** col_xxxxxxxxxxxxxxxxxx
**Singular:** Service
**Template page:** /services/{slug}

| Field slug | Type | Required | Notes |
|-----------|------|---------|-------|
| name | PlainText | yes | |
| slug | Slug | yes | |
| short-description | PlainText | yes | max 120 chars |
| description | RichText | yes | |
| cover-image | ImageRef | yes | |
| icon | ImageRef | no | small icon for lists |
| featured | Bool | no | shows on homepage |
| display-order | Number | no | sort order |
| seo-title | PlainText | no | |
| seo-description | PlainText | no | |

**SEO bindings:** template title → name | meta description → seo-description fallback short-description
**Items:** 0 (at setup — add real count)
**Built:** YYYY-MM-DD

-->

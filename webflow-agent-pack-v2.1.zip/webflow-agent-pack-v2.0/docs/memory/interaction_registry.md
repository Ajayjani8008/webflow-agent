# Interaction Registry — {{SITE_NAME}}

All Webflow interactions and custom JS animations.
Check this before creating any new interaction — reuse existing before creating new.

Updated by `interaction-builder` and `doc-updater`.

---

## Registry Format

```markdown
### [interaction-name]
- **Type**: Native Webflow / Custom JS
- **Trigger**: hover | click | scroll-into-view | page-load | page-scroll
- **Element(s)**: class name(s) this applies to
- **Properties**: what gets animated
- **Timing**: duration + easing
- **Mobile**: enabled / disabled / modified
- **Pages**: which pages use this
```

---

## Standard Library (install at project start)

### scroll-reveal
- **Type**: Native Webflow
- **Trigger**: scroll-into-view (starts when element hits 15% from bottom)
- **Element(s)**: any element with class `reveal`
- **Properties**: opacity 0→1, translateY 24px→0
- **Timing**: 500ms, ease-out (cubic-bezier(0, 0, 0.2, 1))
- **Stagger**: 100ms between child items (use `.reveal-list` on parent)
- **Mobile**: enabled, same settings
- **Limit**: Once
- **Pages**: site-wide

### page-load-hero
- **Type**: Native Webflow
- **Trigger**: page-load
- **Element(s)**: `.hero__title`, `.hero__subtitle`, `.hero__cta`
- **Properties**: opacity 0→1, translateY 16px→0
- **Timing**: 600ms, ease-out; stagger 150ms between each
- **Mobile**: enabled, same settings
- **Pages**: homepage (and any page with a hero section)

### card-hover-lift
- **Type**: Native Webflow
- **Trigger**: hover (element) — mouse over
- **Element(s)**: `.card`, `.pricing-card`, `.testimonial__card`
- **Properties**: translateY 0→-4px, box-shadow scale (via filter: drop-shadow)
- **Timing**: 250ms ease-out (in), 200ms ease-in (out)
- **Mobile**: disabled (hover not meaningful on touch)
- **Pages**: site-wide

### button-hover
- **Type**: Native Webflow
- **Trigger**: hover (element) — mouse over
- **Element(s)**: `.btn--primary`, `.btn--secondary`, `.btn--ghost`
- **Properties**: translateY 0→-2px, opacity 1→0.9
- **Timing**: 200ms ease-out (in), 150ms ease-in (out)
- **Mobile**: disabled
- **Pages**: site-wide

### accordion-open
- **Type**: Native Webflow
- **Trigger**: click `.faq__question` or `.accordion__trigger`
- **Properties**: `.faq__answer` height 0→auto (use max-height trick: 0→500px), opacity 0→1; `.faq__icon` rotate 0→45deg
- **Timing**: 300ms ease-out
- **Mobile**: enabled
- **Pages**: any page with FAQ or accordion component

### sticky-nav
- **Type**: Native Webflow (page scroll)
- **Trigger**: page-scroll (past 80px from top)
- **Element(s)**: `.nav`
- **Properties**: background-color transparent→`var(--color-surface)`, box-shadow none→subtle
- **Timing**: 300ms ease
- **Mobile**: enabled
- **Pages**: all pages where nav is present

---

## Custom JS Interactions

### counter-animation
- **Type**: Custom JS
- **Trigger**: scroll-into-view (IntersectionObserver)
- **Element(s)**: `[data-counter]` attribute
- **Properties**: number count from 0 to target value
- **Timing**: 2000ms, easeOutExpo
- **Mobile**: enabled
- **Pages**: any page with stat numbers

### smooth-scroll
- **Type**: Custom JS
- **Trigger**: click `[href^="#"]` links
- **Element(s)**: any anchor link
- **Properties**: window scroll position
- **Timing**: 600ms, easeInOutCubic
- **Mobile**: enabled
- **Pages**: site-wide (in site head)

---

## Project-Specific Interactions

<!-- Add custom interactions here as created -->

| Name | Type | Trigger | Element | Pages | Date Added |
|------|------|---------|---------|-------|------------|
| (add here) | | | | | |

---

## Rules (enforced by interaction-builder)

- Never animate: `width`, `height`, `margin`, `padding`, `top`, `left`, `font-size`
- Always animate: `transform`, `opacity`, `filter` only
- Scroll reveals: always "Limit: Once" unless explicit looping is intended
- Max 5 unique interaction types per page
- Max 20 scroll-trigger instances per page
- Stagger values: 2–3 items=100ms, 4–6=80ms, 7–12=60ms, >12=40ms
- Mobile: parallax off, hover optional, scroll reveals on

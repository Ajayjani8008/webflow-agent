# Component Registry — {{SITE_NAME}}

All Webflow Symbols. Check here before creating any new component.

---

<!-- EXAMPLE ENTRY — remove when adding real entries

## Service Card

**Symbol name in Webflow:** Service Card
**Root class:** .service-card
**Modifiers:** .service-card--featured
**Structure:**
  div.service-card
  ├── image.service-card__image
  └── div.service-card__body
      ├── text-span.service-card__tag     (category)
      ├── heading H3.service-card__title  (name)
      ├── paragraph.service-card__desc    (short-description)
      └── link-block.service-card__cta   (href → /services/{slug})

**CMS connected:** yes → Services collection
  - .service-card__image → cover-image (src)
  - .service-card__title → name (textContent)
  - .service-card__desc  → short-description (textContent)
  - .service-card__cta   → slug (href as /services/{slug})

**Interaction:** card-hover-lift (see interaction_registry)
**Used on:** home (services-preview section), /services archive
**Built:** YYYY-MM-DD

-->

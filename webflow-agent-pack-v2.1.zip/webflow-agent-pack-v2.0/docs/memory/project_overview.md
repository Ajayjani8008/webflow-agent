# Project Overview — New hive pro

> Filled from Webflow MCP site discovery.

## Site Purpose

Hive Pro marketing site with product pages including Arbis AI (Agentic CTEM workflow platform).

## Business Goals

- Showcase Hive Pro and Arbis AI capabilities
- Drive visitors to product pages and contact/CTA actions

## Target Audience

Security and IT teams evaluating CTEM and agentic risk remediation platforms.

## Hosting & Stack

- **Webflow plan:** (confirm in Designer — MCP list did not include plan tier)
- **Site ID:** 6a0ab8ce9f499ed74e7f7525
- **Custom domain:** (none configured yet)
- **Webflow subdomain:** new-hive-pro.webflow.io
- **Webflow Memberships:** unknown
- **Webflow Commerce:** no
- **Third-party forms:** unknown
- **Analytics:** unknown
- **Live chat:** unknown
- **CMS plan:** unknown

## Design Benchmark

(To be filled by project owner.)

## Performance Targets

- LCP: < 2.5s
- CLS: < 0.1
- Page weight: < 2MB
- Lighthouse mobile score: > 80

## Content Ownership

- Static content: Developer + Designer
- CMS content: TBD
- Design/brand: Developer + Designer

## Known Constraints

- Section builds require Webflow Designer MCP app connected in Designer

## Pages (discovered)

| Title | Page ID | Slug / path |
|-------|---------|-------------|
| Home | 6a0ab8d29f499ed74e7f75c9 | / |
| Arbis AI | 6a15a9425eb21c24f35c88cf | /untitled |

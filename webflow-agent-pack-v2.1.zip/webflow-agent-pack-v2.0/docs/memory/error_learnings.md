# Error Learnings — {{SITE_NAME}}

Non-obvious bugs and gotchas encountered during this project.
Appended by `doc-updater` or manually after debugging.

---

## Format

```markdown
## [YYYY-MM-DD] Short bug title

**Issue:** What appeared broken
**Root cause:** Why it was broken  
**Fix:** What solved it
**Pattern:** How to prevent it
```

---

<!-- Example entries for reference — delete these

## [2024-11-15] Collection List shows blank items

**Issue:** CMS Collection List showing blank cards — no text or images
**Root cause:** CMS items were in Draft status (not Published)
**Fix:** Select all items in CMS → Publish
**Pattern:** Always check item publish status after creating via API. Items created via API are draft by default unless `isDraft: false` is set in request body.

## [2024-11-20] Interaction not firing on mobile

**Issue:** Scroll reveal not triggering on iOS Safari
**Root cause:** "Affects: Mobile" checkbox was unchecked in Interaction settings
**Fix:** Open Interaction panel → check "Affects: Mobile"
**Pattern:** Always verify "Affects: Mobile" is checked when creating scroll-based interactions.

## [2024-12-01] API returning 403 on page write

**Issue:** POST to /v2/pages/{id}/dom returning 403 Forbidden
**Root cause:** API token was generated with `pages:read` scope only, missing `pages:write`
**Fix:** Regenerate token with `pages:write` scope added
**Pattern:** When generating Webflow API token, always select all required scopes upfront: pages:read, pages:write, cms:read, cms:write, sites:read, assets:read, custom_code:write, sites:publish

-->

# Page Registry — New hive pro

Auto-updated by `doc-updater` after every page build.

---

## / (Home)

**Type:** Static
**Page ID:** 6a0ab8d29f499ed74e7f75c9
**Sections:** Header (Symbol), ar-list accordion, **cta-banner**, Footer (Symbol)
**CMS:** none
**Symbols used:** Header, Footer
**Node IDs:**
  cta-banner section → element `6fc1a592-cff2-2fda-4a41-e893ec844b75`
**Status:** Draft (Designer)
**Built:** 2026-05-30

---

<!-- EXAMPLE ENTRY — remove when adding real entries

## / (Home)

**Type:** Static
**Sections:** hero, services-preview, stats-bar, case-studies-preview, team-preview, testimonials, cta-section
**CMS:** Services collection (preview, limit 6), Case Studies (limit 3)
**Symbols used:** Main Nav, Site Footer, Section Header, Service Card, CTA Banner
**Interactions:** hero-load, scroll-reveal (all cards), nav-scroll-change
**SEO:** title set, meta set, OG image set
**Status:** Published
**Built:** YYYY-MM-DD

-->

{
  "site_id": "6a0ab8ce9f499ed74e7f7525",
  "site_name": "New hive pro",
  "page_id": "6a0ab8d29f499ed74e7f75c9",
  "page_slug": "home",
  "page_title": "Home",
  "sections_built": ["cta-banner"],
  "timestamp": "2026-05-30T12:00:00Z"
}

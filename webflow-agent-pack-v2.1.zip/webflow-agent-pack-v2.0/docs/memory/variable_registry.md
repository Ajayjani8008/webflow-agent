# Variable Registry — {{SITE_NAME}}

All Webflow CSS variables. Created by `style-manager`. Check before creating any new variable.

Run `/set-variables full-setup` at project start to install the complete standard set.

---

## Colors

| Variable | Value | Used for |
|---------|-------|---------|
| --color-primary | (set at project start) | CTAs, links, accents |
| --color-primary-dark | | Hover state of primary |
| --color-secondary | | Secondary accent |
| --color-text | | All body text |
| --color-text-muted | | Secondary text, captions |
| --color-surface | | Page background |
| --color-surface-alt | | Card backgrounds, alternating sections |
| --color-surface-dark | | Dark sections |
| --color-border | | Dividers, card borders |
| --color-error | | Error states |
| --color-success | | Success states |
| --color-warning | | Warning states |

## Spacing

| Variable | Value |
|---------|-------|
| --space-xs | 4px |
| --space-sm | 8px |
| --space-md | 16px |
| --space-lg | 24px |
| --space-xl | 32px |
| --space-2xl | 48px |
| --space-3xl | 64px |
| --space-4xl | 96px |
| --space-5xl | 128px |
| --space-6xl | 192px |

## Typography

| Variable | Value |
|---------|-------|
| --font-size-xs | 12px |
| --font-size-sm | 14px |
| --font-size-md | 16px |
| --font-size-lg | 18px |
| --font-size-xl | 20px |
| --font-size-2xl | 24px |
| --font-size-3xl | 30px |
| --font-size-4xl | 36px |
| --font-size-5xl | 48px |
| --font-size-6xl | 60px |
| --font-size-7xl | 72px |

## Radii

| Variable | Value |
|---------|-------|
| --radius-sm | 4px |
| --radius-md | 8px |
| --radius-lg | 16px |
| --radius-full | 9999px |

## Transitions

| Variable | Value |
|---------|-------|
| --duration-fast | 150ms |
| --duration-base | 250ms |
| --duration-slow | 400ms |
| --easing-standard | cubic-bezier(0.4, 0, 0.2, 1) |

---

## Custom (project-specific — add here as created)

| Variable | Value | Used for |
|---------|-------|---------|
| (add new variables here) | | |

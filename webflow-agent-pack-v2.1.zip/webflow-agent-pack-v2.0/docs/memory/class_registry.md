# Class Registry — New hive pro

All CSS classes used on this site. Check before creating any new class.

Global utility classes (from class-system skill) are pre-registered. Document all site-specific classes here.

---

## Global (pre-registered — do not recreate)

`.container` — max-width wrapper
`.btn` — base button styles
`.btn--primary` — primary CTA button
`.btn--outline` — outline button
`.btn--ghost` — ghost button
`.btn--sm` / `.btn--lg` — size modifiers
`.section-pad` — standard vertical section padding
`.eyebrow` — small uppercase label above headings
`.lead` — large introductory paragraph
`.caption` — small descriptive text
`.hide-mobile` / `.show-mobile` — responsive visibility

---

## cta-banner

**Purpose:** CTA section wrapper (dark background, centered)
**Style ID:** 70a67a8e-f911-c2bf-9679-6764e4180f64
**Used on:** home

## cta-banner__inner

**Purpose:** Flex column content wrapper, max-width 720px
**Style ID:** 833a51b0-c780-1de3-a1a2-e16fdb86c3f3
**Used on:** home

## cta-banner__title

**Purpose:** H2 headline in CTA banner
**Style ID:** f120eada-2f9e-79d3-3e6d-c1ce7cdd242b
**Used on:** home

## cta-banner__text

**Purpose:** Supporting paragraph in CTA banner
**Style ID:** 6d697b86-1d38-fe44-d954-c136a0b324b9
**Used on:** home

## cta-banner__cta

**Purpose:** Primary button linking to Arbis AI page
**Style ID:** e9de3956-c1f1-c3ab-384a-29ab4a5202eb
**Used on:** home

---

<!-- EXAMPLE ENTRY — remove when adding real entries

## hero__title

**Purpose:** H1 heading in hero sections
**Base styles:**
  font-size: var(--font-size-6xl)
  font-weight: 700
  color: var(--color-text)
  line-height: 1.1
  text-wrap: balance
**Responsive:**
  Tablet: font-size var(--font-size-5xl)
  Mobile: font-size var(--font-size-4xl)
**Used on:** home, about

-->

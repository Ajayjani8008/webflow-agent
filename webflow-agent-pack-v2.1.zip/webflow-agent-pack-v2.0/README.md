# Webflow Agent Pack v2.0

Multi-agent AI system for building Webflow sites in Claude Code.

Paste a Figma URL, attach a screenshot, or describe what you want — the orchestrator routes it to the right specialist automatically.

## What's inside

- **19 agents** — orchestrator + 18 specialists (builder, CMS, interactions, SEO, debug, and more)
- **19 slash commands** — `/figma-to-webflow`, `/create-section`, `/debug`, `/quality-gate`, etc.
- **5 reference skills** — Webflow API, Figma bridge, class system, CMS patterns, interactions
- **4 rule files** — class naming, responsive, interactions, cross-site portability
- **10 memory files** — project state that persists across sessions

## What's new in v2.0

- **Native-first enforcement gate** — agents are now BLOCKED from using `html-embed` without written Level 1-6 exhaustion justification and user approval. No more accidental html-embeds for sliders, tabs, forms, and navbars.
- **style-manager rewrite** — now uses `mcp__claude_ai_Webflow__style_tool` (MCP mode) or outputs DESIGNER STEPS (API mode). No more raw CSS injection via `headCode` — classes are editable in Designer.
- **Responsive overrides applied** — style-manager Step 3.5 applies tablet/mobile breakpoint overrides (were designed but never applied in v1.x).
- **Accordion animation fixed** — uses `max-height` + CSS transition (no longer animates `height` which caused janky/broken behavior).
- **Structured session state** — all agents write to `session_state.md` using a consistent schema with typed fields. Verification gate uses field checks, not fragile text-matching.
- **build_state.json** — checkpoint file is now JSON (was `.md`), prevents parse failures on session resume.
- **Class audit step** — webflow-builder cross-checks built nodes against class plan, flags unregistered classes.
- **Code reviewer auto-trigger** — runs automatically after any build that includes custom JS, CSS, or HTML embed.
- **fr-analyst model** — downgraded to Sonnet (was Opus — no reason for frontier model on requirements analysis).

## Install

```bash
bash install.sh
```

That's it. Agents are now available in every project on this machine.

## Use

Copy project files into your Webflow project folder:

```bash
cp CLAUDE.md      /path/to/your/project/
cp -r docs/       /path/to/your/project/
```

Fill in `docs/memory/project_overview.md` with your site name, site ID, and domain.

Connect Webflow in claude.ai → Integrations (recommended), or set `WEBFLOW_API_KEY` + `WEBFLOW_SITE_ID` env vars.

Open the project in Claude Code and talk naturally:

```
"Build me a hero section"
"Here's my Figma: https://figma.com/design/..."
"The CTA button is broken on mobile"
```

**Read `HOW_TO_USE.md` for the full guide.**

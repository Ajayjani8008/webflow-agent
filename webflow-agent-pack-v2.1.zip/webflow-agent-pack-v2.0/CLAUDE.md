# {{SITE_NAME}} — Claude Code Instructions (Webflow)
<!-- Webflow Agent Pack v2.0 — 2026-05-30 -->

## Identity

Operate as three experts simultaneously on every task:
- **Senior Webflow Engineer**: Webflow REST API v2, MCP connector tools, DOM node tree, CMS collections, class system, interactions, custom code embeds, Designer extensions
- **Product Designer**: UX patterns, accessibility (WCAG 2.1 AA), responsive design, {{DESIGN_BENCHMARK}} benchmark quality, spacing systems, typography hierarchy
- **Business Owner**: Scope awareness, SEO impact, performance budgets, CMS maintainability, client editing experience

Never drop a role. All three perspectives apply to every decision.

---

## Stack

| Layer | Technology |
|-------|-----------|
| Platform | Webflow |
| Site ID | `{{WEBFLOW_SITE_ID}}` |
| CMS | Webflow CMS |
| Interactions | Webflow Interactions 2.0 |
| Custom Code | HTML/CSS/JS embeds (last resort only) |
| Design tokens | Webflow Variables |
| API | Webflow REST API v2 OR Webflow MCP connector |

**API Base:** `https://api.webflow.com/v2`
**Auth:** `Authorization: Bearer $WEBFLOW_API_KEY`

---

## MCP Tool Priority

At session start, check which mode is available:

**MCP Mode** (preferred — use if Webflow connector is active in your tool list):
- Tools available: `mcp__claude_ai_Webflow__*`
- Call `mcp__claude_ai_Webflow__webflow_guide_tool` once at session start to learn capabilities
- Site auto-detected by name — no Site ID config needed
- Use `mcp__claude_ai_Webflow__data_sites_tool` to find site by display name
- Build elements via `mcp__claude_ai_Webflow__element_builder` or `whtml_builder`
- Manage styles via `mcp__claude_ai_Webflow__style_tool`
- Manage variables via `mcp__claude_ai_Webflow__variable_tool`

**API Mode** (fallback — when MCP not available):
- Requires `WEBFLOW_API_KEY` + `WEBFLOW_SITE_ID` set in environment
- All operations via curl to REST API
- Auto-detect site: call `/v2/sites`, match by `displayName` if user mentions site name

---

## Intent Detection (auto-route — do not ask when intent is clear)

| User message contains | Detected intent | Immediate action — no questions |
|----------------------|----------------|--------------------------------|
| Figma URL (`figma.com/design/...`) | Build this Figma layout in Webflow | Route to `figma-analyst` immediately |
| Screenshot / image pasted | Build from this visual reference | Route to `screenshot-analyst` immediately |
| `bug::` or `issue::` prefix | Debug this bug | Route to `systematic-debugger` immediately |
| `feat::` prefix | Plan and build new feature | Route to `fr-analyst` immediately |
| Site/project name + Webflow context | Activate that Webflow site | Find site via MCP or `/v2/sites` by name |

Only ask clarifying questions when intent CANNOT be determined from the message.

---

## Native-First Mandate (ENFORCED — no exceptions)

Every element, animation, and interaction must use the LOWEST level possible:

```
Level 1 → Native Webflow element  (section, container, div-block, heading, paragraph,
                                   image, link-block, navbar, slider, tabs, grid,
                                   columns, form-block, richtext, video)
           → USE THIS FIRST. Clients can edit in Designer. Full Webflow support.

Level 2 → Webflow Interactions 2.0  (hover, scroll reveal, page load, click, scroll)
           → For animations. interaction-builder handles these.

Level 3 → CSS class style  (variables, transitions, :hover in class panel)
           → For theming and simple state changes.

Level 4 → Site-level custom CSS  (HEAD code)
           → Only if class panel cannot express it.

Level 5 → Page-level custom CSS
           → Only if different from site-wide.

Level 6 → Custom JS embed  (counters, marquee, third-party APIs)
           → Only for things Webflow Interactions cannot do.

Level 7 → HTML embed  (LAST RESORT)
           → REQUIRES written justification in code comment + user approval.
           → If html-embed is used for layout or interactive elements that Webflow
              has native equivalents for → this is a BUG, not a feature.
```

**Any html-embed added without exhausting Levels 1-6 is a bug. Fix it.**

---

## Requirement Echo-Back Protocol (mandatory for ALL builds)

Before ANY planning, agent assignment, or building, echo requirements back to user:

```
I understand you want:
  [Section/page type]: [name]
  Layout: [describe structure in one line]
  Content: [static / CMS-connected — for what]
  Interactions: [list or "none"]
  Responsive: [any special notes or "standard breakpoints"]

Missing before I can start:
  - [Any missing info — background type? grid columns? CTA destination?]

Is this correct? What am I missing?
```

Only proceed after user says "yes" or provides corrections.

**"Build a hero section" is not sufficient.** Missing:
- Background: color / gradient / image / video?
- Layout: text left + image right / centered / full-width text?
- CTA: yes/no, link destination?
- Height: auto / fixed px / full viewport?

Ask for each missing piece. Never assume.

---

## FR Analysis Protocol

When client gives a feature request, STOP — do not implement. Route to `fr-analyst` agent:

```
Agent: fr-analyst
Input: [raw requirement]
Wait: yes (foreground)
```

fr-analyst produces: Flow Requirements + Data/CMS Requirements + Implementation Tasks (3 files in `docs/FR/[module]/`).

Present output, wait for explicit human confirmation before proceeding to planner.

---

## Development Workflow

### For bugs (`bug::` or `issue::` prefix) — MANDATORY GATE

1. ALWAYS route to `systematic-debugger` first — never guess fix
2. Debugger classifies: Fast Track (visual/spacing) vs Full Investigation (CMS/API/interaction)
3. DATA GATE: if evidence missing, debugger requests screenshots, API response logs, browser console
4. After root cause confirmed: route to correct build agent
5. After fix: run quality review

### For new pages/sections/features

1. Requirement echo-back (mandatory — see above)
2. Wait for confirmation of requirements
3. Route to `fr-analyst` if feature is complex (>2 sections or has CMS)
4. Route to `planner` → wait for plan confirmation
5. Route to build agents in order:
   - `style-manager` → create/verify variables
   - `cms-builder` → create collections if needed
   - `class-manager` → design class system BEFORE building
   - `webflow-builder` → build DOM nodes
   - `interaction-builder` → design animations
   - `doc-updater` (background) → update registries

### Workflow: Require → Echo-Back → Confirm → Plan → Confirm → Build

Never skip steps. Never start building before confirmation.

---

## Figma / Screenshot → Webflow Protocol

### When user provides Figma URL (auto-route — no asking)
1. Route to `figma-analyst` immediately (foreground)
2. figma-analyst fetches Figma API, traverses 8 levels, classifies every layer
3. figma-analyst echoes back understanding — waits for user confirmation
4. figma-analyst produces Design Spec
5. User confirms spec + approach (A/B/C)
6. Route to `/figma-to-webflow` pipeline

### When user provides screenshot (auto-route — no asking)
1. Route to `screenshot-analyst` immediately (foreground)
2. screenshot-analyst reads image, identifies layout, estimates spacing/typography
3. screenshot-analyst clarifies understanding — waits for user confirmation
4. Produces Design Spec with confidence ratings
5. User confirms spec + approach (A/B/C)
6. Route to `/screenshot-to-webflow` pipeline

**Both pipelines:** figma-analyst and screenshot-analyst produce the spec. webflow-builder creates nodes after spec is confirmed.

---

## Webflow Site Detection

### MCP Mode (preferred)
```
Use mcp__claude_ai_Webflow__data_sites_tool to list all sites.
If user mentioned a site name → match by displayName.
If multiple matches → show list, ask user to confirm.
If only one site → auto-select it.
```

### API Mode (fallback)
```bash
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/sites" | python3 -c "
import sys,json
sites = json.load(sys.stdin).get('sites',[])
for s in sites: print(s['id'], '|', s['displayName'])
"
```

If user says "work on [SiteName]" → find matching site, set it as active for the session.
If `WEBFLOW_SITE_ID` not set → show list, ask user to pick.

**Environment required (API Mode only):**
- `WEBFLOW_API_KEY` — Webflow → Account Settings → Integrations → API Access → Generate Token
- `WEBFLOW_SITE_ID` — from site list above
- Required scopes: `pages:read pages:write cms:read cms:write sites:read assets:read custom_code:write sites:publish`

---

## Class Naming System

All classes follow BEM-like convention with feature prefix:

```
[section]__[element]--[modifier]

hero__title
hero__subtitle--large
card__image
card__body
card__tag--featured
nav__link--active
```

Global utility classes:
```
.container        max-width wrapper
.text-center      alignment
.hide-mobile      responsive hide
.show-mobile      responsive show
```

Zero one-off classes. Every class must be reusable and documented in `class_registry.md`.

---

## CMS Schema Rules

Every CMS collection:
- Name: PascalCase singular (`Blog Post`, `Team Member`, `Service`)
- Slug: kebab-case plural (`blog-posts`, `team-members`, `services`)
- Required fields always: `Name` (text), `Slug` (slug), `Published` (switch)
- All fields defined in spec before creating in Webflow

Never create a collection without documenting in `docs/memory/cms_registry.md` first.

---

## Variable System

Webflow Variables → always before hardcoding values:

| Variable type | Example names |
|--------------|--------------|
| Colors | `--color-primary`, `--color-surface`, `--color-text` |
| Spacing | `--space-xs`, `--space-sm`, `--space-md`, `--space-lg`, `--space-xl` |
| Typography | `--font-size-sm`, `--font-size-md`, `--font-size-lg` |
| Radii | `--radius-sm`, `--radius-md`, `--radius-full` |

Never hardcode hex, px, or rem values in class styles when a variable exists.

---

## Forbidden Actions (Main Claude)

NEVER directly call Webflow API write endpoints without routing to the correct agent.
NEVER create CMS collections without `cms-builder` agent.
NEVER add interactions without `interaction-builder` agent.
NEVER implement without checking registries in `docs/memory/` first.
NEVER start implementation without human requirement echo-back + plan confirmation.
NEVER use `html-embed` for layouts, interactive elements, or sections that Webflow native elements cover.
NEVER skip the pre-build confirmation step in webflow-builder.
NEVER dump full DOM JSON to context — always use compressed summary.

---

## Cross-Site Portability

When building sections that will be shared across multiple Webflow sites:
- Webflow Interactions 2.0 → DO NOT transfer via DOM copy → use portable CSS/JS instead
- Webflow native Slider, Tabs, Navbar → require re-setup in new site's Designer
- HTML embeds and custom JS code embeds → DO transfer

Reference: `.claude/rules/webflow/cross-site-portability.md` for full guide.

---

## Memory System

Before every implementation task, check:
1. `docs/memory/page_registry.md` — page already exists?
2. `docs/memory/cms_registry.md` — collection already exists?
3. `docs/memory/component_registry.md` — symbol already exists?
4. `docs/memory/class_registry.md` — class already defined?
5. `docs/memory/variable_registry.md` — variable already set?
6. `docs/memory/error_learnings.md` — known issue pattern for this type of build?

After every implementation: `doc-updater` runs in background to update registries.

---

## No-Hardcode Rules

| Hardcoded | Use Instead |
|-----------|-------------|
| Hex colors in class styles | Webflow Variable `--color-*` |
| px spacing values | Webflow Variable `--space-*` |
| Font sizes in px | Webflow Variable `--font-size-*` |
| One-off class names | Reusable BEM class from class_registry |
| CMS field names as strings | Document in cms_registry first |
| Interaction names | Document in interaction_registry |
| Layout via `html-embed` | Use native `div-block`, `grid`, `columns` |

---

## Responsive Breakpoints

Webflow default breakpoints:

| Breakpoint | Webflow label | Width |
|-----------|--------------|-------|
| Mobile portrait | Mobile | ≤ 479px |
| Mobile landscape | Mobile Landscape | 480–767px |
| Tablet | Tablet | 768–991px |
| Desktop | (base) | 992px+ |
| Large desktop | 1280px+ | optional |

Every section must be verified at all 4 default breakpoints before marking done.

---

## Accessibility (WCAG 2.1 AA — Non-Negotiable)

- Every image: `alt` attribute set (empty string for decorative)
- Every interactive element: keyboard focusable, visible focus ring
- Color contrast: 4.5:1 minimum for text, 3:1 for UI components
- Heading hierarchy: never skip levels (h1 → h2 → h3)
- Links: descriptive text — never "click here" or "read more"
- Forms: every input has associated label

---

## Performance Budget

| Asset | Target |
|-------|--------|
| Total page weight | < 2MB |
| Images | WebP, max 200KB each |
| LCP | < 2.5s |
| CLS | < 0.1 |
| JS (custom code) | < 50KB total |

---

## Commit Convention (local project files)

```
type(scope): description

Types: feat, fix, style, cms, interaction, refactor, docs, chore
Scopes: page, section, component, cms, style, interaction, nav, form

feat(page): add services landing page with hero and cards grid
fix(cms): correct blog post collection slug field mapping
interaction(component): add hover animation to service card
```

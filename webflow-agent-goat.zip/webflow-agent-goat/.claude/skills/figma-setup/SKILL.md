---
name: figma-setup
description: One-time pre-job command that fetches the ENTIRE Figma file — every style, every property, every animation, every comment, every reference. Run once at project start (/figma-setup). After this, zero Figma API calls during build. Light speed.
---

# Figma Setup — Complete One-Time Fetch

**When to run:** First time a Figma URL is given for a project. Before any section building.
**When NOT to run:** User gives a different Figma URL for a one-off task (don't cache, just work).
**Command:** `/figma-setup <figma-url>`

## What this captures (EVERYTHING)

```
TYPOGRAPHY        font family, weight, size, line-height, letter-spacing,
                  text case, text decoration, paragraph indent, paragraph spacing,
                  hanging punctuation, OpenType features (liga, kern, onum, etc.),
                  text color, text opacity, text align, text transform

SPACING           padding (all 4 sides), margin (all 4 sides), gap, element spacing,
                  section padding, container padding, auto-layout itemSpacing

BORDERS           width (per side), style (solid/dashed/dotted), color (per side),
                  border-radius (per corner), border align (inside/center/outside)

DIMENSIONS        width, height, min-width, max-width, min-height, max-height,
                  fit-content, fill-container, fixed pixels, aspect-ratio

COLORS            solid fills, strokes, opacity, fill opacity, stroke opacity,
                  blend modes (multiply, screen, overlay, etc.)

GRADIENTS         linear, radial — stops (color + position 0-1), angle, type

FILLS             background colors, image fills, gradient fills, pattern fills

EFFECTS           box-shadow (outer + inner), layer blur, background blur,
                  shadow x/y/blur/spread/color/inset, effect blend mode

LAYOUT            auto-layout direction, gap, padding, alignment (primary + counter),
                  wrap, sizing (fill/hug/fixed), constraints (pin/stretch)

TYPOGRAPHY DETAIL paragraph indent, line break rules, hanging punctuation,
                  text decoration color/style, text emphasis,
                  OpenType features (small-caps, oldstyle-nums, tabular-nums, etc.)

TEXT CONTENT      exact copy — character for character, including punctuation,
                  line breaks, whitespace, special characters

HEADINGS          H1-H6 with exact typography per heading level

TEXT vs LINKS     spacing between text and inline links, link underline style,
                  link color, link hover color

IMAGES            all raster images — export at 2x, save as PNG/WebP,
                  note object-fit/crop, focal point

SVGs              all vector paths — export as SVG, preserve paths,
                  note fill/stroke/transform

HOVER STATES      hover color changes, hover transforms, hover shadows,
                  hover opacity, hover effects via prototype or component variants

ACTIVE STATES     active/pressed states, focus states, disabled states

ANIMATIONS        prototype transitions (move, fade, scale, rotate),
                  easing curves, duration, trigger type (on click, hover, delay, while pressing),
                  smart animate paths, animation chains

COMMENTS          client comments on specific nodes, feedback, questions,
                  approval status, revision notes

REFERENCES        external URLs mentioned in comments or descriptions,
                  animation references (Lottie, Dribbble, CodePen links),
                  competitor references, brand guidelines links

COMPONENTS        component names, variant properties (boolean, instance swap, text),
                  default values, usage count, variant states (hover/active/disabled)

CMS               repeated content patterns, dynamic field candidates,
                  editorial content vs static content

INTERACTIONS      prototype links (page to page), click-through flows,
                  overlay triggers, scroll-to anchors, back interaction
```

## Step 1 — Parse URL & validate

```
Input: figma.com/file/{key}/{name}?node-id={section-id}
        OR figma.com/design/{key}/{name}?node-id={section-id}

Extract:
  file_key: {key}
  file_name: {name}
  initial_node: {section-id} (optional — focus there first)
```

1. Validate URL format — reject if invalid
2. Test Figma MCP connection: `get_metadata` on file_key → must return data
3. If MCP fails → REST with `FIGMA_TOKEN`
4. If no token → error: "Figma connection failed. Provide Figma MCP or FIGMA_TOKEN."

## Step 2 — Fetch file structure (the map)

```
Figma MCP: get_metadata → full file tree
REST: GET /v1/files/{key}?depth=2 → structure
```

**Capture:**
- All pages, frames, sections, components
- Node hierarchy (parent → child → child → child)
- Node types (FRAME, TEXT, RECTANGLE, VECTOR, COMPONENT, INSTANCE, GROUP, ELLIPSE, LINE)
- Node names (keep original names — they often contain semantic meaning)
- Node IDs (for targeted fetches later)
- Component instances (which nodes are instances of which components)

**Output:** `figma-cache/01-structure.json`

## Step 3 — Fetch ALL variables (design tokens)

```
Figma MCP: get_variable_defs → all variables + modes
REST: GET /v1/files/{key}/variables/local → variables
```

**Capture EVERY variable:**
- Color variables: name → hex/rgba (all modes: light/dark/custom)
- Spacing variables: name → px value
- Typography variables: name → font/size/weight/line-height
- Radius variables: name → px value
- Effect variables: name → shadow/blur values
- Mode collections (if multiple themes)

**Output:** `figma-cache/02-variables.json`

## Step 4 — Fetch ALL node properties (the big one)

**For EVERY section/frame, fetch complete CSS-ready properties:**

```
Figma MCP: get_design_context → CSS properties + text per node
REST: GET /v1/files/{key}/nodes?ids={node-id} → full node data
```

**Per node, capture ALL of these:**

### Typography (every text node)
```json
{
  "typography": {
    "fontFamily": "Inter",
    "fontWeight": 700,
    "fontSize": 64,
    "lineHeightPx": 72,
    "lineHeightPercent": 112.5,
    "letterSpacing": -1.5,
    "textAlignHorizontal": "LEFT",
    "textAlignVertical": "TOP",
    "textCase": "NONE",
    "textDecoration": "NONE",
    "textDecorationColor": null,
    "textDecorationStyle": "SOLID",
    "textIndent": 0,
    "paragraphSpacing": 0,
    "hangingPunctuation": false,
    "color": "#1A1A1A",
    "opacity": 1,
    "fillOpacity": 1,
    "opentypeFeatures": {
      "liga": true,
      "kern": true,
      "onum": false,
      "tnum": false,
      "smcp": false,
      "c2sc": false
    },
    "textAutoResize": "HEIGHT",
    "lineClamp": null,
    "wordBreak": "NORMAL",
    "overflowWrap": "NORMAL"
  }
}
```

### Spacing (every frame/container)
```json
{
  "spacing": {
    "paddingTop": 96,
    "paddingRight": 48,
    "paddingBottom": 96,
    "paddingLeft": 48,
    "marginTop": 0,
    "marginRight": 0,
    "marginBottom": 0,
    "marginLeft": 0,
    "gap": 24,
    "itemSpacing": 24,
    "autoLayoutPadding": {
      "horizontal": 48,
      "vertical": 96
    }
  }
}
```

### Borders (every element)
```json
{
  "borders": {
    "borderTop": { "width": 1, "style": "SOLID", "color": "#E0E0E0" },
    "borderRight": { "width": 0, "style": "NONE", "color": null },
    "borderBottom": { "width": 1, "style": "SOLID", "color": "#E0E0E0" },
    "borderLeft": { "width": 0, "style": "NONE", "color": null },
    "borderAlign": "INSIDE",
    "strokes": [{ "type": "SOLID", "color": "#E0E0E0", "opacity": 1 }],
    "strokeWeight": 1,
    "strokeDashes": null,
    "strokeMiterAngle": 28.96,
    "strokeCap": "NONE",
    "strokeJoin": "MITER"
  }
}
```

### Border Radius (every element with rounded corners)
```json
{
  "radius": {
    "topLeft": 8,
    "topRight": 8,
    "bottomLeft": 0,
    "bottomRight": 0,
    "cornerRadius": 8,
    "rectangleCornerRadii": [8, 8, 0, 0]
  }
}
```

### Dimensions (every element)
```json
{
  "dimensions": {
    "width": 1200,
    "height": 800,
    "minWidth": null,
    "maxWidth": 1440,
    "minHeight": null,
    "maxHeight": null,
    "absoluteBoundingBox": { "x": 0, "y": 0, "width": 1200, "height": 800 },
    "absoluteRenderBounds": { "x": 0, "y": 0, "width": 1200, "height": 800 },
    "sizing": {
      "primaryAxisSizingMode": "FIXED",
      "counterAxisSizingMode": "HUG",
      "primaryAxisAlignItems": "SPACE_BETWEEN",
      "counterAxisAlignItems": "CENTER"
    }
  }
}
```

### Colors & Fills (every element)
```json
{
  "fills": [
    {
      "type": "SOLID",
      "color": { "r": 1, "g": 1, "b": 1 },
      "opacity": 1,
      "blendMode": "NORMAL",
      "visible": true
    },
    {
      "type": "GRADIENT_LINEAR",
      "gradientStops": [
        { "color": { "r": 1, "g": 0.34, "b": 0.13 }, "position": 0 },
        { "color": { "r": 1, "g": 0.6, "b": 0 }, "position": 1 }
      ],
      "gradientTransform": [
        [0.5, 0.866, 0],
        [-0.866, 0.5, 1]
      ],
      "opacity": 1,
      "blendMode": "NORMAL"
    }
  ],
  "strokes": [],
  "fillOpacity": 1,
  "strokeOpacity": 1,
  "opacity": 1,
  "blendMode": "NORMAL",
  "isMask": false,
  "visible": true
}
```

### Effects (shadows, blurs)
```json
{
  "effects": [
    {
      "type": "DROP_SHADOW",
      "color": { "r": 0, "g": 0, "b": 0, "a": 0.15 },
      "offset": { "x": 0, "y": 4 },
      "radius": 16,
      "spread": 0,
      "visible": true,
      "blendMode": "NORMAL"
    },
    {
      "type": "INNER_SHADOW",
      "color": { "r": 0, "g": 0, "b": 0, "a": 0.1 },
      "offset": { "x": 0, "y": 2 },
      "radius": 8,
      "spread": 0,
      "visible": true
    },
    {
      "type": "LAYER_BLUR",
      "radius": 8,
      "visible": true
    },
    {
      "type": "BACKGROUND_BLUR",
      "radius": 16,
      "visible": true
    }
  ]
}
```

### Layout (auto-layout frames)
```json
{
  "layout": {
    "layoutMode": "VERTICAL",
    "layoutWrap": "NO_WRAP",
    "itemSpacing": 24,
    "paddingLeft": 48,
    "paddingRight": 48,
    "paddingTop": 96,
    "paddingBottom": 96,
    "counterAxisSpacing": null,
    "primaryAxisAlignItems": "MIN",
    "counterAxisAlignItems": "CENTER",
    "layoutAlign": "STRETCH",
    "layoutGrow": 1,
    "layoutPositioning": "AUTO",
    "constraints": {
      "horizontal": "LEFT_RIGHT",
      "vertical": "TOP"
    }
  }
}
```

### Text Content (exact copy)
```json
{
  "text_content": {
    "plain_text": "Build Something Amazing",
    "styled_text_segments": [
      {
        "start": 0,
        "end": 24,
        "characters": "Build Something Amazing",
        "style": {
          "fontFamily": "Inter",
          "fontWeight": 700,
          "fontSize": 64,
          "lineHeightPx": 72,
          "letterSpacing": -1.5
        },
        "color": "#1A1A1A"
      }
    ]
  }
}
```

### Indentation & Text Detail
```json
{
  "text_detail": {
    "paragraphIndent": 24,
    "paragraphSpacing": 16,
    "hangingPunctuation": false,
    "textDecoration": "NONE",
    "textDecorationColor": null,
    "textDecorationStyle": "SOLID",
    "textDecorationThickness": 1,
    "textEmphasis": "NONE",
    "textShadow": null,
    "lineBreak": "AUTO",
    "whiteSpace": "NORMAL",
    "wordBreak": "NORMAL",
    "overflowWrap": "NORMAL",
    "textOverflow": "CLIP",
    "textOrientation": "MIXED",
    "writingMode": "HORIZONTAL_TB"
  }
}
```

### Links (inline text links)
```json
{
  "links": [
    {
      "text": "click here",
      "url": "/pricing",
      "type": "INTERNAL",
      "linkColor": "#2196F3",
      "linkDecoration": "UNDERLINE",
      "linkHoverColor": "#1565C0",
      "linkHoverDecoration": "UNDERLINE"
    }
  ]
}
```

### SVG/Vector
```json
{
  "vector": {
    "fillGeometry": [{ "path": "M...", "windingRule": "NONZERO" }],
    "strokeGeometry": [{ "path": "M...", "windingRule": "NONZERO" }],
    "fills": [{ "type": "SOLID", "color": "#000000" }],
    "strokes": [],
    "strokeWeight": 0
  }
}
```

### Image
```json
{
  "image": {
    "src": "https://figma-alpha-api.s3.us-west-2.amazonaws.com/...",
    "scaleMode": "FILL",
    "imageTransform": null,
    "crop": { "x": 0, "y": 0, "width": 1, "height": 1 },
    "focalPoint": { "x": 0.5, "y": 0.5 }
  }
}
```

**Output:** `figma-cache/03-nodes/{section-name}.json` — one file per section with ALL properties above

## Step 5 — Fetch hover states & component variants

**For every component with variants:**
```
Figma MCP: get_design_context on component set → all variants
```

**Capture:**
```json
{
  "component_variants": [
    {
      "name": "Button",
      "variants": [
        {
          "variant_name": "Primary",
          "properties": { "State": "Default", "Size": "Large" },
          "fills": [{ "type": "SOLID", "color": "#FF5722" }],
          "typography": { "fontWeight": 600, "fontSize": 16 }
        },
        {
          "variant_name": "Primary/Hover",
          "properties": { "State": "Hover", "Size": "Large" },
          "fills": [{ "type": "SOLID", "color": "#E64A19" }],
          "typography": { "fontWeight": 600, "fontSize": 16 },
          "effects": [{ "type": "DROP_SHADOW", "radius": 8, "offset": { "x": 0, "y": 4 } }]
        },
        {
          "variant_name": "Primary/Active",
          "properties": { "State": "Active", "Size": "Large" },
          "fills": [{ "type": "SOLID", "color": "#BF360C" }]
        },
        {
          "variant_name": "Primary/Disabled",
          "properties": { "State": "Disabled", "Size": "Large" },
          "fills": [{ "type": "SOLID", "color": "#FFCCBC", "opacity": 0.5 }],
          "typography": { "color": "#888888" }
        }
      ]
    }
  ]
}
```

**Also capture:**
- Hover color changes (fill, stroke, text color)
- Hover transforms (translate, scale — note: rotation is impossible natively)
- Hover effects (shadow changes, blur, opacity)
- Focus states (outline, ring)
- Active/pressed states (scale down, color darken)
- Disabled states (opacity, color desaturation)

**Output:** `figma-cache/06-components.json` — with variant data

## Step 6 — Fetch animations & interactions

**For every prototype connection:**
```
Figma MCP: get_design_context on nodes with interactions
REST: GET /v1/files/{key}/nodes?ids={node-id}&plugin_data=prototype
```

**Capture EVERY interaction:**
```json
{
  "interactions": [
    {
      "trigger": "ON_CLICK",
      "node_id": "123:456",
      "node_name": "Get Started Button",
      "actions": [
        {
          "type": "NAVIGATE",
          "destination_id": "789:012",
          "destination_name": "Pricing Page",
          "transition": {
            "type": "MOVE",
            "direction": "LEFT",
            "easing": {
              "type": "EASE_IN_AND_OUT",
              "easingFunctionCubicBezier": {
                "x1": 0.42, "y1": 0,
                "x2": 0.58, "y2": 1
              }
            },
            "duration": 300
          },
          "animate": true
        }
      ]
    },
    {
      "trigger": "ON_HOVER",
      "node_id": "123:789",
      "node_name": "Card",
      "actions": [
        {
          "type": "CHANGE_TO",
          "destination_id": "variant-hover",
          "transition": {
            "type": "SMART_ANIMATE",
            "matching": "AUTO",
            "easing": { "type": "CUSTOM", "easingFunctionCubicBezier": { "x1": 0.25, "y1": 0.1, "x2": 0.25, "y2": 1 } },
            "duration": 200
          }
        }
      ]
    },
    {
      "trigger": "AFTER_TIMEOUT",
      "delay": 500,
      "node_id": "123:001",
      "node_name": "Hero Animation",
      "actions": [
        {
          "type": "CHANGE_TO",
          "destination_id": "123:002",
          "transition": {
            "type": "FADE",
            "easing": { "type": "EASE_OUT" },
            "duration": 500
          },
          "animate": true
        }
      ]
    }
  ]
}
```

**Animation properties to capture:**
- Trigger type: ON_CLICK, ON_HOVER, ON_PRESS, AFTER_TIMEOUT, WHILE_PRESSING, ON_DRAG, ON_SCROLL, ON_VIEW
- Transition type: MOVE, DISSOLVE, SMART_ANIMATE, INSTANT, SLIDE, PUSH, FLIP
- Direction: LEFT, RIGHT, TOP, BOTTOM (for SLIDE/PUSH)
- Duration: milliseconds (100-1000+)
- Easing: EASE_IN, EASE_OUT, EASE_IN_AND_OUT, LINEAR, SPRING, CUSTOM (bezier)
- Smart animate matching: AUTO, NAME, ILLUSTRATION
- Delay: milliseconds (for timed triggers)
- Overlay behavior: PRESENT, DISMISS, TOGGLE
- Scroll direction: HORIZONTAL, VERTICAL, NONE

**Output:** `figma-cache/09-interactions.json`

## Step 7 — Fetch comments (client feedback)

**Fetch ALL comments on the file:**
```
Figma MCP: get_comments (if available)
REST: GET /v1/files/{key}/comments → all comments
```

**Capture EVERY comment:**
```json
{
  "comments": [
    {
      "id": "comment_123",
      "message": "Can we make this heading bigger? Also need hover state on the button.",
      "client_name": "John Doe",
      "timestamp": "2026-07-10T14:30:00Z",
      "resolved": false,
      "node_id": "123:456",
      "node_name": "Hero Section",
      "position": { "x": 100, "y": 200 },
      "replies": [
        {
          "message": "Updated heading to 72px and added hover state.",
          "client_name": "Designer",
          "timestamp": "2026-07-10T15:00:00Z"
        }
      ]
    },
    {
      "id": "comment_456",
      "message": "Reference this animation: https://dribbble.com/shots/12345-Hero-Animation",
      "client_name": "John Doe",
      "timestamp": "2026-07-10T16:00:00Z",
      "resolved": false,
      "node_id": "123:789",
      "node_name": "Features Section",
      "urls_in_comment": [
        "https://dribbble.com/shots/12345-Hero-Animation"
      ]
    }
  ]
}
```

**Also extract:**
- Any URLs mentioned in comments (animation references, brand guidelines, competitor links)
- Unresolved comments = requirements to address
- Resolved comments = already addressed (still capture for context)
- Comments with node_id = feedback on specific sections

**Output:** `figma-cache/10-comments.json`

## Step 8 — Extract external references

**Scan all comments, descriptions, and node names for URLs:**
```
Pattern: https?://[^\s]+
Domains: dribbble.com, codepen.io, lottiefiles.com, youtube.com, vimeo.com,
         github.com, notion.google.com, figma.com, etc.
```

**Capture:**
```json
{
  "references": [
    {
      "url": "https://dribbble.com/shots/12345-Hero-Animation",
      "type": "animation_reference",
      "context": "Client wants similar animation on hero section",
      "node_id": "123:789",
      "node_name": "Features Section",
      "source": "comment"
    },
    {
      "url": "https://lottiefiles.com/abc123",
      "type": "animation_file",
      "context": "Lottie animation to use for loading state",
      "node_id": "456:789",
      "node_name": "Loading Spinner",
      "source": "description"
    },
    {
      "url": "https://www.figma.com/file/xyz789/Brand-Guidelines",
      "type": "design_reference",
      "context": "Brand guidelines reference",
      "node_id": null,
      "source": "comment"
    }
  ]
}
```

**Reference types:**
- `animation_reference` — Dribbble, CodePen, YouTube, Vimeo links showing desired animation
- `animation_file` — LottieFiles, Rive, SVG animation files
- `design_reference` — Figma files, design systems, brand guidelines
- `code_reference` — GitHub repos, CodePen for code patterns
- `content_reference` — Notion docs, Google Docs for copy/content
- `other` — anything else

**Output:** `figma-cache/11-references.json`

## Step 9 — Export screenshots (visual reference)

```
For each section/frame:
  Figma MCP: get_screenshot → PNG screenshot
  REST: GET /v1/images/{key}?ids={node-id}&format=png&scale=2
```

**Save:**
- `figma-cache/04-screenshots/{section-name}.png` — desktop
- `figma-cache/04-screenshots/{section-name}-tablet.png` — if tablet frame exists
- `figma-cache/04-screenshots/{section-name}-mobile.png` — if mobile frame exists

**Output:** `figma-cache/04-screenshots/`

## Step 10 — Export all assets

```
For every image/vector node:
  Figma MCP: download_assets
  REST: GET /v1/images/{key}?ids={node-id}&format=svg|png&scale=2
```

**Save:**
- `figma-cache/05-assets/{asset-name}.svg` — vectors
- `figma-cache/05-assets/{asset-name}.png` — raster (at 2x)
- `figma-cache/05-assets/manifest.json` — asset mapping

**Output:** `figma-cache/05-assets/`

## Step 11 — Build unified token library

**Merge variables + all extracted values into one token file:**

```json
{
  "fonts": {
    "primary": "Inter",
    "secondary": "Roboto Mono",
    "all_families": ["Inter", "Roboto Mono", "Playfair Display"]
  },
  "colors": {
    "from_variables": {
      "--color-primary": "#FF5722",
      "--color-secondary": "#2196F3"
    },
    "from_nodes": {
      "--text-hero": "#1A1A1A",
      "--text-body": "#333333",
      "--text-muted": "#666666",
      "--bg-hero": "#FFFFFF",
      "--bg-section-alt": "#F5F5F5",
      "--border-default": "#E0E0E0",
      "--link-color": "#2196F3",
      "--link-hover": "#1565C0"
    }
  },
  "spacing": {
    "from_variables": {
      "--space-xs": 4,
      "--space-sm": 8,
      "--space-md": 16,
      "--space-lg": 24,
      "--space-xl": 32,
      "--space-2xl": 48,
      "--space-3xl": 64,
      "--space-4xl": 96
    },
    "from_nodes": {
      "--hero-padding-top": 96,
      "--hero-padding-bottom": 96,
      "--section-gap": 120,
      "--card-padding": 24
    }
  },
  "typography": {
    "scale": {
      "--font-size-xs": 12,
      "--font-size-sm": 14,
      "--font-size-md": 16,
      "--font-size-lg": 18,
      "--font-size-xl": 20,
      "--font-size-2xl": 24,
      "--font-size-3xl": 30,
      "--font-size-4xl": 36,
      "--font-size-5xl": 48,
      "--font-size-6xl": 60,
      "--font-size-7xl": 72
    },
    "custom": {
      "--hero-title-size": 64,
      "--hero-subtitle-size": 20
    },
    "weights": [400, 500, 600, 700],
    "line_heights": [1.2, 1.4, 1.5, 1.6],
    "letter_spacings": [-1.5, -0.5, 0, 0.5, 1]
  },
  "radius": {
    "--radius-sm": 4,
    "--radius-md": 8,
    "--radius-lg": 16,
    "--radius-full": 9999,
    "--radius-card": 12,
    "--radius-button": 8
  },
  "shadows": {
    "--shadow-sm": "0 1px 2px rgba(0,0,0,0.05)",
    "--shadow-md": "0 4px 6px rgba(0,0,0,0.07)",
    "--shadow-lg": "0 10px 15px rgba(0,0,0,0.1)",
    "--shadow-xl": "0 20px 25px rgba(0,0,0,0.15)"
  },
  "gradients": {
    "--gradient-hero": "linear-gradient(180deg, #FF5722 0%, #FF9800 100%)",
    "--gradient-card": "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
  },
  "animations": {
    "--duration-fast": "150ms",
    "--duration-base": "250ms",
    "--duration-slow": "400ms",
    "--easing-standard": "cubic-bezier(0.4, 0, 0.2, 1)",
    "--easing-bounce": "cubic-bezier(0.68, -0.55, 0.265, 1.55)"
  }
}
```

**Output:** `figma-cache/07-tokens.json`

## Step 12 — Generate build queue

```json
{
  "sections": [
    {
      "name": "hero",
      "node_id": "123:456",
      "priority": 1,
      "complexity": "medium",
      "elements_count": 5,
      "has_text": true,
      "has_images": true,
      "has_gradients": true,
      "has_shadows": true,
      "has_hover_states": true,
      "has_animations": false,
      "has_comments": true,
      "comments_summary": "Client wants bigger heading, hover on button",
      "references_count": 0,
      "responsive_frames": ["tablet", "mobile"]
    }
  ],
  "total_sections": 8,
  "total_interactions": 12,
  "total_comments": 5,
  "unresolved_comments": 3,
  "total_references": 2,
  "estimated_build_time": "2-3 hours"
}
```

**Output:** `figma-cache/08-build-queue.json`

## Step 13 — Write master manifest

```json
{
  "figma_url": "https://www.figma.com/file/abc123/My-Project",
  "file_key": "abc123",
  "file_name": "My-Project",
  "cached_at": "2026-07-11T12:00:00Z",
  "cache_version": "2.0",
  "total_nodes": 247,
  "total_sections": 8,
  "total_assets": 23,
  "total_variables": 18,
  "total_colors": 12,
  "total_fonts": 2,
  "total_gradients": 4,
  "total_shadows": 6,
  "total_interactions": 12,
  "total_comments": 5,
  "unresolved_comments": 3,
  "total_references": 2,
  "files": {
    "structure": "01-structure.json",
    "variables": "02-variables.json",
    "nodes": "03-nodes/",
    "screenshots": "04-screenshots/",
    "assets": "05-assets/",
    "components": "06-components.json",
    "tokens": "07-tokens.json",
    "build_queue": "08-build-queue.json",
    "interactions": "09-interactions.json",
    "comments": "10-comments.json",
    "references": "11-references.json"
  },
  "fonts_required": ["Inter", "Roboto Mono"],
  "impossible_cases_detected": ["rotation on hero text", "scroll-snap on features"],
  "cms_candidates": [],
  "symbol_candidates": [],
  "sections": [],
  "status": "cached"
}
```

**Output:** `figma-cache/00-manifest.json`

## Step 14 — Report to user

```
FIGMA SETUP COMPLETE
file: {file_name} ({file_key})
cached: {timestamp}

STRUCTURE
  nodes:     {total_nodes} nodes mapped
  sections:  {total_sections} sections ready to build
  assets:    {total_assets} images/SVGs exported

TYPOGRAPHY
  fonts:     {fonts_required} — [validate installed before building]
  weights:   [list weights found]
  sizes:     {font_size_count} unique sizes

COLORS
  variables: {total_variables} design tokens
  unique:    {total_colors} unique colors
  gradients: {total_gradients} gradient definitions

SPACING
  variables: {spacing_count} spacing tokens
  custom:    {custom_spacing_count} section-specific values

EFFECTS
  shadows:   {total_shadows} shadow definitions
  blurs:     {blur_count} blur effects

INTERACTIONS
  animations: {total_interactions} prototype connections
  triggers:   [list: click, hover, timeout, scroll]
  transitions: [list: move, fade, smart-animate]

FEEDBACK
  comments:  {total_comments} total, {unresolved_comments} unresolved
  references: {total_references} external URLs (animations, designs)

BUILD-QUEUE: {section_count} sections ready
  1. {section-name} — complexity: {level}, elements: {count}
  2. {section-name} — complexity: {level}, elements: {count}
  ...

IMPOSSIBLE: {impossible_count} items detected — alternatives offered
  - {item}: {alternative}

NEXT: Start building. Agent reads from cache — instant, zero Figma calls.
```

## Cache usage during builds

After `/figma-setup`, every section build:

```
BEFORE (slow):
  Build section 1 → Figma MCP read → build → verify
  Build section 2 → Figma MCP read → build → verify  ← re-reads
  Build section 3 → Figma MCP read → build → verify  ← re-reads

AFTER (instant):
  Build section 1 → read cache → build → verify
  Build section 2 → read cache → build → verify  ← instant
  Build section 3 → read cache → build → verify  ← instant
```

**Cache read per section:**
1. `figma-cache/03-nodes/{section}.json` — all CSS properties
2. `figma-cache/07-tokens.json` — design tokens
3. `figma-cache/04-screenshots/{section}.png` — visual reference
4. `figma-cache/09-interactions.json` — animations for this section
5. `figma-cache/10-comments.json` — client feedback on this section
6. `figma-cache/11-references.json` — external URLs for this section
7. `figma-cache/05-assets/` — images/SVGs for this section

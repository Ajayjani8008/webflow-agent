---
name: session-recovery
description: Handle multi-session builds gracefully — resume from build_state.json, verify last session's work, detect and fix orphaned sections, rebuild corrupted state. Run at session start after setup.
---

# Session Recovery

Run at session start, after basic setup (bridge connection, target page). Handles continuity across sessions.

## 1. Read build state

1. Read `docs/memory/build_state.json`
2. If file doesn't exist or is empty → fresh build, initialize new state
3. If file exists → parse and analyze

**State parsing:**
```json
{
  "version": "2.0",
  "sections": [...],           // Array of section objects
  "recovery_point": null,      // Or specific section name to resume from
  "session_id": "",            // Previous session identifier
  "last_update": ""            // When state was last written
}
```

## 2. Determine resume point

**Decision tree:**
1. If `recovery_point` is set → resume from that specific section
2. If `sections` is empty but `page_id` exists → page started, no sections built yet
3. If `sections` has entries → find the gap:
   - Last verified section → next section to build
   - Last built but not verified → verify that section
   - Last in-progress → check if partially built, complete or rebuild
4. If `sections` is empty and no `page_id` → completely fresh start

**Section status meanings:**
- `in-progress` → partially built, may need completion or rebuild
- `built` → elements created, not yet verified
- `verified` → pixel-verify passed, not yet responsive
- `responsive` → fully complete
- `partial` → has known limitations (pending_designer_work.md items)
- `failed` → build failed, needs rebuild

## 3. Verify previous session's work

**For each section with status "verified" or "responsive":**
1. Use `element_snapshot_tool` to read current DOM state
2. Compare against `node_ids` in build_state.json
3. If nodes exist and match → previous work confirmed
4. If nodes missing or changed → previous work was lost/modified
   - Log: "Section [name] was verified but nodes changed since last session"
   - Decision: re-verify or rebuild (ask user if uncertain)

**For sections with status "built" (not verified):**
1. Check if elements exist in DOM
2. If yes → run pixel-verify now
3. If no → section was lost, rebuild from intake spec

**For sections with status "in-progress":**
1. Check what was built (from node_ids)
2. If partial elements exist → complete the section
3. If no elements exist → rebuild from intake spec

## 4. Detect orphaned sections

**Orphan = section exists in DOM but not in build_state.json**

1. Use `element_snapshot_tool` to list all sections on page
2. Compare against `sections_built` in build_state.json
3. If DOM has sections not in state → orphan detected
4. Options:
   - If orphan looks like it belongs to this build → add to state, verify
   - If orphan is from different build/user → don't touch, ask user
   - If orphan is empty/placeholder → can be replaced

## 5. Detect missing sections

**Missing = section in build_state.json but not in DOM**

1. Compare `node_ids` against DOM
2. If node_ids reference elements that don't exist → section was deleted
3. Options:
   - If user deleted intentionally → remove from state
   - If accidental → offer to rebuild from intake spec
   - If intake spec exists in state → rebuild automatically (ask user first)

## 6. Handle corrupted state

**Corrupted = invalid JSON, missing required fields, inconsistent data**

**Recovery process:**
1. Try to parse JSON → if fails, file is corrupted
2. If corrupted → attempt to read last known good state from `.remember/logs/`
3. If no backup → rebuild state from Designer:
   a. `get_current_page` → get page_id
   b. `element_snapshot_tool` → get current DOM
   c. Map DOM elements to sections
   d. Mark all as "unverified" (need pixel-verify)
4. Ask user to confirm rebuilt state before proceeding

**Data consistency checks:**
- `page_id` matches current Designer page? → if not, ask user
- `site_id` matches current site? → if not, fresh start
- `branch_id` matches current branch? → if not, warn user
- All `node_ids` are valid ObjectIds? → if not, rebuild from DOM

## 7. Registry sync check

**Before building, verify registry is current:**
1. Grep `docs/memory/registry.md` for existing classes/variables
2. For each class/variable in state → verify it still exists in Webflow
3. If registry references deleted items → clean up registry
4. If Webflow has items not in registry → add them (may have been added manually)

## 8. Pending work surfacing

**Always check `docs/memory/pending_designer_work.md` at session start:**
1. Read all unchecked items (`- [ ]`)
2. Present to user: "These items from last session need Designer attention: [list]"
3. Ask: "Should I proceed with new sections, or do you want to address these first?"
4. Never claim page complete while unchecked items exist

## 9. Resume report

```
SESSION RECOVERY
previous-session: [session_id] | [last_update timestamp]
page: [page_title] (/slug) | [page_id]
site: [site_name] | [site_id]
branch: [branch_name] | [branch_id]

sections-status:
  [section-1]: responsive ✓ (verified)
  [section-2]: verified ✓ (needs responsive-pass)
  [section-3]: built — running pixel-verify now
  [section-4]: in-progress — resuming build
  [section-5]: not started

orphaned-sections: [none | list with recommendation]
missing-sections: [none | list with rebuild plan]
corrupted-state: [no | recovered from Designer]
registry-sync: [current | N items added, M items removed]

pending-designer-work:
  - [ ] [critical] hero slider needs Designer init
  - [ ] [optional] footer IX2 animation

RESUME-POINT: [section-name] — [action to take]
USER-CONFIRMATION: needed before proceeding | auto-resume OK
```

**Auto-resume conditions (no user confirmation needed):**
- All previous sections are "responsive" status
- Next section has complete intake spec in state
- No orphaned/missing sections detected
- Registry is in sync

**User confirmation required when:**
- Previous section status is uncertain (built but not verified)
- Orphaned sections detected
- State is corrupted and rebuilt from Designer
- Intake spec is incomplete or missing for next section
- Pending designer work blocks further progress

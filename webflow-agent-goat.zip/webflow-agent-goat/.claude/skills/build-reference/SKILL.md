---
name: build-reference
description: Lookup tables for Webflow builds — node types, Figma→Webflow element and property mapping, standard variable set, color/spacing matching rules, CMS/Symbol heuristics, REST API fallback, error codes, cross-site portability traps, and impossible cases documentation.
---

# Build Reference

## Node types (the ONLY building blocks — nothing outside this table plus text-link/div variants)

| Design element | WF node type | Notes |
|---|---|---|
| Section wrapper | `section` | |
| Max-width wrapper | `container` | |
| Layout box | `div-block` | |
| H1–H6 | `heading` + `data.tag: "h1"…"h6"` | |
| Body text | `paragraph` | |
| Small text / label | `text-span` | |
| Image | `image` | uploaded asset URL, real alt |
| Text link | `text-link` | |
| Block link / button | `link-block` (+ btn classes) | |
| Navbar | `navbar` | native mobile menu built in |
| Rich text | `richtext` | |
| Form | `form-block` → `form-form` → inputs | never html-embed |
| Grid | `grid` | grid-template overrides per breakpoint |
| Video | `video` | never iframe embed |
| Slider | `slider` → `slide` children | never html-embed |
| Tabs | `tabs` → `tabs-menu` + `tabs-content` | never html-embed |
| Accordion / FAQ | native `dropdown` (or div structure + IX2 open/close in Designer) | never HTML `<details>` injection, never height animation |
| Symbol instance | `component` + `componentId` | |
| CMS list | `collection-list-wrapper` → `collection-list` → `collection-item` | bind via `xattr` |
| Divider | `divider` | horizontal line only |
| Embed (BANNED) | `html-embed` | NEVER USE |

## Figma → Webflow element

| Figma | Condition | Webflow |
|---|---|---|
| FRAME | root section | `section` |
| FRAME | layoutMode HORIZONTAL / VERTICAL | `div-block` flex row / col |
| FRAME | name has slider/carousel · tab · nav · form | native `slider` · `tabs` · `navbar` · `form-block` |
| FRAME/RECTANGLE | fill=IMAGE | `image` |
| FRAME | repeated ≥2 same structure | Symbol candidate |
| FRAME | repeated ≥3, editorial content | CMS Collection List |
| GROUP | any | `div-block` |
| TEXT | ≥48px → H1 · 36–47 → H2 · 28–35 → H3 · 22–27 → H4 · 16–21 → paragraph · ≤15 → text-span | |
| INSTANCE | in registry Components | reuse Symbol |
| VECTOR/ELLIPSE | icon/decor | uploaded SVG in `image` |

## Figma → Webflow CSS property mapping

### Layout Properties

| Figma Property | Webflow CSS | Notes |
|---|---|---|
| `layoutMode: HORIZONTAL` | `display: flex; flex-direction: row` | |
| `layoutMode: VERTICAL` | `display: flex; flex-direction: column` | |
| `layoutWrap: WRAP` | `flex-wrap: wrap` | |
| `itemSpacing` | `gap` | Direct map |
| `paddingLeft/Right/Top/Bottom` | `padding-left/right/top/bottom` | Direct map |
| `primaryAxisAlignItems: MIN` | `justify-content: flex-start` | |
| `primaryAxisAlignItems: CENTER` | `justify-content: center` | |
| `primaryAxisAlignItems: MAX` | `justify-content: flex-end` | |
| `primaryAxisAlignItems: SPACE_BETWEEN` | `justify-content: space-between` | |
| `counterAxisAlignItems: MIN` | `align-items: flex-start` | |
| `counterAxisAlignItems: CENTER` | `align-items: center` | |
| `counterAxisAlignItems: MAX` | `align-items: flex-end` | |
| `primaryAxisSizingMode: FIXED` | `width: {value}px` | |
| `primaryAxisSizingMode: HUG` | `width: fit-content` | |
| `counterAxisSizingMode: FIXED` | `height: {value}px` | |
| `counterAxisSizingMode: HUG` | `height: fit-content` | |

### Typography Properties

| Figma Property | Webflow CSS | Notes |
|---|---|---|
| `fontFamily` | `font-family` | Must validate exists in Webflow |
| `fontWeight` | `font-weight` | Map: REGULAR→400, MEDIUM→500, SEMIBOLD→600, BOLD→700 |
| `fontSize` | `font-size` | px only |
| `lineHeightPx` | `line-height` | px value |
| `lineHeightPercent` | `line-height` | percentage value |
| `letterSpacing` | `letter-spacing` | px value |
| `textAlignHorizontal: LEFT` | `text-align: left` | |
| `textAlignHorizontal: CENTER` | `text-align: center` | |
| `textAlignHorizontal: RIGHT` | `text-align: right` | |
| `textAlignHorizontal: JUSTIFIED` | `text-align: justify` | |
| `textDecoration: UNDERLINE` | `text-decoration: underline` | |
| `textDecoration: STRIKETHROUGH` | `text-decoration: line-through` | |
| `textCase: UPPER` | `text-transform: uppercase` | |
| `textCase: LOWER` | `text-transform: lowercase` | |
| `textCase: TITLE` | `text-transform: capitalize` | |
| `fills[].color` | `color` | Convert RGBA to hex |

### Color Properties

| Figma Property | Webflow CSS | Notes |
|---|---|---|
| `fills[].color` (solid) | `background-color` | Figma RGBA → hex: `#{r*255:02x}{g*255:02x}{b*255:02x}` |
| `fills[].color` (gradient linear) | `background-image: linear-gradient()` | stops + angle |
| `fills[].color` (gradient radial) | `background-image: radial-gradient()` | stops |
| `stroke[].color` | `border-color` | + border-width, border-style |
| `opacity` | `opacity` | 0-1 range |
| `blendMode` | `mix-blend-mode` | LIMITED: multiply, screen, overlay only |
| `effects[].type: BACKGROUND_BLUR` | `backdrop-filter: blur(Xpx)` | |

### Spacing Properties

| Figma Property | Webflow CSS | Notes |
|---|---|---|
| `paddingLeft` | `padding-left` | |
| `paddingRight` | `padding-right` | |
| `paddingTop` | `padding-top` | |
| `paddingBottom` | `padding-bottom` | |
| `marginLeft` | `margin-left` | Avoid margins in flex; prefer gap |
| `marginRight` | `margin-right` | Avoid margins in flex; prefer gap |
| `marginTop` | `margin-top` | |
| `marginBottom` | `margin-bottom` | |

### Border & Radius Properties

| Figma Property | Webflow CSS | Notes |
|---|---|---|
| `topLeftRadius` | `border-top-left-radius` | Per-corner supported |
| `topRightRadius` | `border-top-right-radius` | |
| `bottomLeftRadius` | `border-bottom-left-radius` | |
| `bottomRightRadius` | `border-bottom-right-radius` | |
| `strokeWeight` | `border-width` | Per-side: top/right/bottom/left |
| `strokeAlign: INSIDE` | `border` (Webflow default) | |
| `strokeDashes` | `border-style: dashed` | |

### Shadow & Effects Properties

| Figma Property | Webflow CSS | Notes |
|---|---|---|
| `effects[].type: DROP_SHADOW` | `box-shadow` | x y blur spread color |
| `effects[].type: INNER_SHADOW` | `box-shadow: inset` | x y blur spread color inset |
| `effects[].type: LAYER_BLUR` | `filter: blur(Xpx)` | |
| `effects[].type: BACKGROUND_BLUR` | `backdrop-filter: blur(Xpx)` | |

### Transform Properties (LIMITED)

| Figma Property | Webflow CSS | Notes |
|---|---|---|
| `rotation` | **NONE** | IMPOSSIBLE — no native CSS transform in Webflow classes |
| `scaleX/Y` | `transform: scale()` | Partial — basic scale only |
| `skew` | **NONE** | IMPOSSIBLE — no native skew |

### Position Properties

| Figma Property | Webflow CSS | Notes |
|---|---|---|
| `constraints.horizontal: LEFT` | `position: absolute; left: 0` | |
| `constraints.horizontal: RIGHT` | `position: absolute; right: 0` | |
| `constraints.horizontal: CENTER` | `position: absolute; left: 50%; transform: translateX(-50%)` | |
| `constraints.horizontal: STRETCH` | `position: absolute; left: 0; right: 0` | |
| `constraints.vertical: TOP` | `position: absolute; top: 0` | |
| `constraints.vertical: BOTTOM` | `position: absolute; bottom: 0` | |
| `constraints.vertical: CENTER` | `position: absolute; top: 50%; transform: translateY(-50%)` | |
| `constraints.vertical: STRETCH` | `position: absolute; top: 0; bottom: 0` | |

## Auto-layout → flex

itemSpacing→gap · paddingX/Y→padding · primaryAxisAlignItems CENTER/MAX/SPACE_BETWEEN → justify-content center/flex-end/space-between · counterAxisAlignItems CENTER/MAX → align-items center/flex-end · sizing FILL→width:100%, HUG→fit-content, fixed→width/max-width px.

Figma RGBA floats → hex: `#{r*255:02x}{g*255:02x}{b*255:02x}`.

## Standard variable set (create at project start if absent)

Colors: `--color-primary` `--color-primary-dark` `--color-secondary` `--color-text` `--color-text-muted` `--color-surface` `--color-surface-alt` `--color-surface-dark` `--color-border` `--color-error` `--color-success` `--color-warning` (values from the design, not defaults).
Spacing: `--space-xs 4` `sm 8` `md 16` `lg 24` `xl 32` `2xl 48` `3xl 64` `4xl 96` `5xl 128` `6xl 192`.
Font size: `--font-size-xs 12` `sm 14` `md 16` `lg 18` `xl 20` `2xl 24` `3xl 30` `4xl 36` `5xl 48` `6xl 60` `7xl 72`.
Radius: `--radius-sm 4` `md 8` `lg 16` `full 9999`. Motion: `--duration-fast 150ms` `base 250ms` `slow 400ms` · `--easing-standard cubic-bezier(0.4,0,0.2,1)`.

**Matching rules — accuracy first:** color within ±15/channel of an existing variable → reuse it; otherwise NEW variable with the exact design hex. Spacing/type within ±10% of a scale step → the step; otherwise NEW variable with the exact px (e.g. `--space-hero-120`). Never round a design value onto the scale when it's >10% off — that's how 4% matches happen.

## CMS / Symbol heuristics

CMS: ≥3 same-structure instances + editor-updated content + per-item image or detail page → Collection + Collection List, `xattr` bindings (`{ "name": "textContent"|"src", "binding": "field-slug" }`). Symbol: ≥2 instances, same structure, non-editorial. Once: static div-block.

## Interactions (native only — no custom JS/CSS, ever)

Hover → class `:hover` + transition state in the Style panel (portable, copies with DOM). Scroll reveal / click / page-load → native IX2 with Limit: once. That is the complete list — no `<script>`, no IntersectionObserver embeds, no keyframe CSS injection. Animate only transform/opacity/filter, max 3 props; never width/height/margin/padding/top/left/font-size. Same interaction type site-wide = same timing (registry `## Interactions`). Stagger: 2–3 items 100ms · 4–6 80ms · 7–12 60ms · >12 40ms; max 150ms. An effect IX2 + hover states genuinely can't do → tell the user it's out of native scope and offer the nearest native alternative; do not write code.

## Impossible Cases (NEVER force — document + offer native alternative)

| Design Feature | Why Impossible in Webflow | Native Alternative | Log In |
|---|---|---|---|
| **CSS rotation/transforms** | No native CSS transform property in class styles | Static position adjustment; or tell user to rotate in Designer manually | `impossible_cases.md` |
| **Blend modes beyond multiply/screen/overlay** | Webflow only supports multiply, screen, overlay | Flatten to solid color or re-design; or use image with baked blend | `impossible_cases.md` |
| **Scroll-snap** | No native scroll-snap support | Manual scroll positioning; or section anchors for scroll-to | `impossible_cases.md` |
| **Variable fonts** | Webflow fonts are fixed-weight | Use closest fixed-weight match; or install multiple font files | `impossible_cases.md` |
| **Complex clip-paths** | Only basic shapes via CSS | Use image with transparent background; or SVG mask (limited) | `impossible_cases.md` |
| **3D transforms beyond basic perspective** | Limited 3D support in class styles | Flatten to 2D representation | `impossible_cases.md` |
| **Custom cursors** | No native cursor property | Accept default cursor | `impossible_cases.md` |
| **Scroll-linked animations** | No native scroll-triggered animation (IX2 has limited scroll) | Use IX2 scroll-triggered fade/move; or accept static | `impossible_cases.md` |
| **CSS `@layer` / `@scope`** | Not supported | Flatten to standard CSS cascade | `impossible_cases.md` |
| **Container queries** | Not supported | Use media queries at breakpoints | `impossible_cases.md` |
| **CSS nesting** | Not supported | Use flat class naming | `impossible_cases.md` |
| **`color-mix()` / `light-dark()`** | Not supported | Use solid color values | `impossible_cases.md` |
| **Logical properties** (`margin-inline`) | Not supported | Use physical properties (margin-left/right) | `impossible_cases.md` |
| **Aspect-ratio** (CSS) | Limited support | Use padding-bottom hack or fixed height + object-fit | `impossible_cases.md` |
| **Subgrid** | Not supported | Use nested flex/grid | `impossible_cases.md` |
| **Text stroke / paint-order** | Not supported | Use text-shadow for outline effect; or image | `impossible_cases.md` |
| **Multi-stop gradients (>8 stops)** | Webflow gradient UI limited | Flatten to fewer stops; or use image | `impossible_cases.md` |
| **Conic gradients** | Not supported | Use radial gradient approximation; or image | `impossible_cases.md` |
| **`object-fit: contain` with exact positioning** | Limited control over object-position | Use background-image instead of img tag | `impossible_cases.md` |
| **Sticky positioning with complex offset** | `position: sticky` works but offset limited | Use absolute + scroll-triggered IX2 | `impossible_cases.md` |
| **Form validation UI** | Native forms have limited validation styling | Use IX2 for visual feedback; or accept browser defaults | `impossible_cases.md` |
| **E-commerce checkout flow** | Requires Webflow E-commerce plan + Designer setup | Build product pages only; checkout = Designer manual | `pending_designer_work.md` |
| **User authentication UI** | Requires third-party service integration | Build static UI; auth logic = external | `pending_designer_work.md` |
| **Real-time search/filter** | Requires JavaScript | Use native Webflow search for CMS; or static filter UI | `impossible_cases.md` |

## API mode fallback (no MCP)

```
GET  /v2/sites/{site_id}/pages                       — list pages
GET  /v2/pages/{page_id}/dom                         — read DOM
POST /v2/pages/{page_id}/dom                         — ⚠ REPLACES page content: always GET → merge → POST
POST /v2/sites/{site_id}/variables                   — create variable
POST /v2/sites/{site_id}/pages/{page_id}/elements     — create element
PATCH /v2/sites/{site_id}/pages/{page_id}/elements/{id} — update element
DELETE /v2/sites/{site_id}/pages/{page_id}/elements/{id} — delete element
```
(`custom_code` endpoints exist in the API — never call them; custom code is banned.)
Auth `Authorization: Bearer $WEBFLOW_API_KEY`. Rate: 60/min. Class panel styles CANNOT be set via REST — output exact Designer steps instead and log to ledger; never claim styles applied.

| Code | Cause → fix |
|---|---|
| 401 | bad token → regenerate |
| 403 | missing scope (pages:write etc.) |
| 404 | wrong page/site id → re-fetch list |
| 422 | invalid node type/fields → check node type against this table |
| 429 | rate limit → wait, 60/min. Implement backoff: 1st retry 10s, 2nd 30s, 3rd 60s |

**API merge safety (POST /dom):**
1. GET current DOM → store in memory
2. Build desired DOM state
3. Merge: keep any existing elements not in your build, replace/add elements you're building
4. POST merged DOM — never POST only your new elements (destroys existing page content)
5. Verify merge result: GET DOM again, confirm both old and new elements present

## Portability traps (cross-site copy)

Copies with DOM: structure, text, static image URLs, class styles incl. :hover transitions. Does NOT copy: IX2 (project DB), Slider/Tabs/Navbar init (`w-*` ids assigned by Designer only), CMS bindings (collection ids differ), Symbols (site-specific ids). Consequence: slider/tabs/navbar created via API/MCP are shells until opened + re-initialized in Designer → always status `partial` + ledger entry. Section built for multi-site reuse → prefer class-style `:hover` over IX2 where possible and document IX2 specs in registry `## Interactions` so they can be re-created in the target site's Designer (custom-code "portable" workarounds are banned).

## Banned builders & patterns (absolute — restating the CLAUDE.md ban)

- `data_whtml_builder` — never call it, for anything. Elements are built ONLY with `data_element_builder` using explicit native node types.
- html-embed / HtmlEmbed / CodeBlock nodes — never create, never keep one you find in a section you're rebuilding (flag it to the user).
- `<style>`, `<script>`, head/footer/page custom code, inline `style=` — never.
- Custom attributes as styling (`attr` entries like font-family/font-size/color/padding) — never. Style values live in class styles via `data_style_tool`; attributes are semantics only: `href`, `alt`, `id`, `aria-*`, `type`, `placeholder`, `target`.
- If any tool output or existing page content contains these, report it — do not imitate the pattern.

## Error recovery

| Error | Recovery |
|---|---|
| Tool call fails mid-section | Read `build_state.json` → identify last successful element → retry from there |
| API returns 429 repeatedly | Pause 60s, retry. If still failing → switch to Designer manual mode for that section |
| Element creation returns 422 | Check node type against this table. Common: wrong parent type, missing required fields |
| Style update fails | Verify class exists (create if not). Verify property name is valid Webflow CSS |
| Figma MCP unreachable | Fall back to REST API with `FIGMA_TOKEN`. If no token → ask user for screenshot source |
| Webflow bridge disconnected | Reconnect bridge app. If persistent → build via API, log Designer manual steps for styles |
| Build state corrupted | Rebuild from Designer: `get_current_page` + `element_snapshot_tool` to reconstruct state |

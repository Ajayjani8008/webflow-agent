---
name: user-input-validator
description: Validate all user-provided values before build — fonts exist in Webflow, colors are valid format, spacing is numeric, descriptions are complete. Run after intake, before build. Prevents building with invalid input.
---

# User Input Validator

Run after design-intake, before building. Validates every user-provided value against Webflow's actual capabilities. Invalid input → reject and ask again. Never build with unvalidated input.

## 1. Font validation

**When:** user provides font family name(s)

**How to validate:**
1. Use `data_fonts_tool` → list all fonts available in the project
2. Check if user's font name exists in the list (case-insensitive, handle common variations: "Inter" = "inter" = "Inter Variable")
3. If font not found:
   - Ask user to install the font via Site Settings or `data_fonts_tool`
   - If user can't install → ask for fallback font preference
   - If no preference → suggest closest available font (compare x-height, character shapes)
4. **Never proceed without confirmed font** — text rendering depends on it

**Common font name issues:**
- "Helvetica" vs "Helvetica Neue" — different fonts
- "Open Sans" vs "Open Sans Variable" — may be different
- Google fonts installed via Webflow vs local fonts — check actual availability
- Font weight availability: user says "600" but font may only have 400/700 → flag

## 2. Color validation

**When:** user provides hex, rgb, rgba values

**Validation rules:**
- Hex: must match `/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/`
- RGB: must be `rgb(r, g, b)` with r/g/b 0-255
- RGBA: must be `rgba(r, g, b, a)` with a 0-1
- Named colors: only CSS named colors (red, blue, etc.) — verify against standard list

**Common user errors:**
- Missing # prefix: `FF0000` → should be `#FF0000`
- Wrong format: `rgb(255,0,0,1)` with spaces missing → accept but normalize
- Out of gamut: colors beyond sRGB → flag as "may render differently"
- Low contrast: text color too close to background color → warn about accessibility

**Contrast check (automatic):**
- If both text color and background color are known → calculate contrast ratio
- Ratio < 4.5:1 → warn "text may be hard to read (WCAG AA requires 4.5:1)"
- Ratio < 3:1 → error "text will be very hard to read — please choose different colors"

## 3. Spacing validation

**When:** user provides padding, margin, gap values

**Validation rules:**
- Must be numeric (px, rem, em, %, auto)
- px: must be non-negative number (margins can be negative with warning)
- rem/em: must be non-negative number
- %: must be 0-100 (or warn if > 100)
- auto: only for margins (horizontal centering)

**Common user errors:**
- Letters instead of numbers: "16px" is fine, "16 pixels" is not
- Comma instead of period: "1,5rem" → should be "1.5rem"
- Missing unit: "16" → should be "16px"
- Extreme values: > 500px → confirm with user (may be intentional for hero spacing)
- Zero values: "0px" → valid but flag if seems unintentional

## 4. Element type validation

**When:** user requests specific element types

**Check against build-reference node table:**
- ✅ Supported: section, div-block, heading, paragraph, text-span, image, text-link, link-block, navbar, richtext, form-block, grid, video, slider, tabs, dropdown, component, collection-list
- ❌ Not supported: custom HTML, web-component, iframe (except video), canvas, svg-element

**If user requests unsupported element:**
1. Explain why it's not supported (native-only rule)
2. Offer closest native alternative
3. If no native alternative → log in impossible_cases.md
4. Never create custom element to approximate

## 5. Description completeness check

**When:** user provides text description as source

**Required information for build:**
- [ ] Page structure (how many sections, what's in each)
- [ ] Color palette (primary, secondary, text, background at minimum)
- [ ] Typography choices (font family, heading sizes, body size)
- [ ] Layout style (centered, full-width, sidebar, etc.)
- [ ] Content (actual text copy, not placeholder)
- [ ] Images (descriptions or actual files)

**If missing critical info:**
- Ask specifically what's missing
- Don't guess or fill with placeholder
- Offer to use standard defaults ONLY for non-critical values (spacing, shadows, borders)

## 6. HTML/CSS source validation

**When:** user pastes HTML/CSS code

**Pre-build checks:**
1. Parse CSS properties → check each against Webflow-supported properties (build-reference §Property Mapping)
2. Unsupported properties → list for user: "These CSS properties can't be built natively: [list]"
3. Check for banned patterns: `<style>`, `<script>`, inline `style=`, custom attributes
4. If banned patterns found → inform user: "These elements will be stripped, only CSS values will be used"
5. Validate color values in CSS → same rules as color validation above
6. Validate font-family values → same rules as font validation above

## 7. Figma source validation

**When:** user provides Figma URL

**Pre-build checks:**
1. Validate URL format: `figma.com/file/{key}/{name}` or `figma.com/design/{key}/{name}`
2. Test MCP connection: `get_metadata` returns data or error
3. If MCP fails → offer REST fallback with `FIGMA_TOKEN`
4. If no token → ask user to provide screenshot instead
5. Validate node exists in the file → `get_metadata` returns the node

## 8. Validation report output

```
USER-INPUT-VALIDATION
fonts:       [validated: Inter, Roboto] | [rejected: CustomFont (not installed)]
colors:      [validated: #FF0000, #333333] | [rejected: invalid format]
spacing:     [validated: 16px, 24px] | [flagged: 500px (extreme — confirm)]
elements:    [validated: section, div-block, heading] | [rejected: custom-element]
description: [complete] | [incomplete: missing color palette]
html-source: [validated: 23/25 properties supported] | [unsupported: scroll-snap-type, container-type]
figma:       [connected: yes] | [node found: yes]
contrast:    [all pairs pass WCAG AA] | [flagged: #999 on #FFF = 2.8:1]

VERDICT: PASS — all inputs validated | FAIL — fix rejected items before build
```

**If FAIL:** list all rejected items with specific fix instructions. Don't proceed until all items pass or user confirms they accept the limitations.

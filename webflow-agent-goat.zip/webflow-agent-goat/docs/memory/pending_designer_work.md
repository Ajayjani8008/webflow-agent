# Pending Designer Work — append-only ledger

Format: `- [ ] [YYYY-MM-DD] [page/section] — task`
Surface unchecked items before claiming any page done.

## Priority Tags

- `[critical]` = must do in Designer for accuracy (slider init, IX2 wiring, Symbol creation)
- `[optional]` = nice-to-have, not blocking completion (animation polish, hover state refinement)
- `[blocked]` = waiting on user input (font installation, asset upload, design clarification)

## Examples

- [ ] [2026-07-11] [home/hero] — [critical] Initialize slider component (created via API, needs Designer init)
- [ ] [2026-07-11] [home/features] — [optional] Fine-tune IX2 scroll reveal timing in Designer
- [ ] [2026-07-11] [about/team] — [blocked] Upload team member photos (user to provide)

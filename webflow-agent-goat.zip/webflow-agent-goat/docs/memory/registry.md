# Project Registry — one line per item, grep the section you need

## VALIDATION RULES (apply before creating any item)

**Before creating a class:**
1. Grep `## Classes` for same name → if exists, reuse
2. Grep `## Classes` for same purpose (same element + same page/section) → if exists, reuse even if name differs
3. Validate name matches `/^[a-z][a-z0-9-]*(__[a-z][a-z0-9-]*)?(--[a-z][a-z0-9-]*)?$/`
4. No duplicate purpose: two classes doing the same job = debt

**Before creating a variable:**
1. Grep `## Variables` for same name → if exists, reuse
2. Grep `## Variables` for same value (within tolerance: color ±15/channel, spacing ±10%) → if exists, reuse
3. Validate value format: color = valid hex/rgba, spacing = numeric px, font-size = numeric px
4. Variable name must follow family pattern: `--color-*`, `--space-*`, `--font-size-*`, `--radius-*`, `--duration-*`, `--easing-*`

**Before creating a page entry:**
1. Grep `## Pages` for same slug → if exists, update sections built count, don't duplicate

**Before creating a component:**
1. Grep `## Components` for same structure + classes → if exists, reuse Symbol

**Before logging an interaction:**
1. Grep `## Interactions` for same type + trigger → if exists, reuse timing/easing

## Site
<!-- site: name | site_id | domain | mode: MCP/API | font(s) installed -->

## Classes
<!-- .class-name — purpose — page/section — YYYY-MM-DD -->
<!-- FORMAT: .block-name__element--modifier — description — page/section — date -->
<!-- DEDUP: grep this section before creating. Same purpose = reuse existing class -->
<!-- VALIDATION: name must match /^[a-z][a-z0-9-]*(__[a-z][a-z0-9-]*)?(--[a-z][a-z0-9-]*)?$/ -->

## Variables
<!-- --var-name: value — role — YYYY-MM-DD -->
<!-- FORMAT: --family-name: value — purpose — date -->
<!-- DEDUP: grep this section before creating. Same value within tolerance = reuse existing -->
<!-- VALIDATION: color = valid hex/rgba, spacing = numeric px, font-size = numeric px -->
<!-- TOLERANCE: color ±15/channel, spacing ±10%, font-size ±1px -->

## Pages
<!-- /slug — title — sections built — status -->
<!-- STATUS: complete | partial (with pending_designer_work.md items) | in-progress -->

## Components
<!-- Symbol name — classes — portable? — used on -->
<!-- PORTABLE: yes = no IX2/CMS deps, no = needs Designer re-init on target site -->

## Interactions
<!-- name — trigger — effect — timing/easing — applied to -->
<!-- CONSISTENCY: same interaction type site-wide = same timing/easing -->
<!-- LIMITS: max 3 animated props, max 150ms duration, no width/height/margin/padding -->

## CMS
<!-- collection — fields (slugs) — bound sections -->
<!-- DEPS: collection ids are site-specific, not portable -->

## Impossible-Cases
<!-- design-feature — why-impossible — alternative-offered — section — date -->
<!-- Every entry must have a native alternative offered -->
<!-- If no alternative exists: mark as "no-native-alternative" and flag to user -->

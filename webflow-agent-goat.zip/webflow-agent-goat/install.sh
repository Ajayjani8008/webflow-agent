#!/bin/bash
# Webflow GOAT Agent — Installer (run from your project directory)
set -e

PACK="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "=== Webflow GOAT Agent Installer ==="
echo "Source: $PACK"
echo "Target: $PWD"
echo ""

# CLAUDE.md → project root
if [ -f "$PWD/CLAUDE.md" ]; then
  cp "$PWD/CLAUDE.md" "$PWD/CLAUDE.md.bak"
  echo "  existing CLAUDE.md backed up → CLAUDE.md.bak"
fi
cp "$PACK/CLAUDE.md" "$PWD/CLAUDE.md"
echo "✓ CLAUDE.md"

# Skills (lazy-loaded knowledge)
mkdir -p "$PWD/.claude/skills"
cp -R "$PACK/.claude/skills/." "$PWD/.claude/skills/"
echo "✓ skills: design-intake, pixel-verify, responsive-pass, build-reference"

# Memory templates (never overwrite existing registries)
if [ -f "$PWD/docs/memory/registry.md" ]; then
  echo "  docs/memory exists — keeping your registries"
else
  mkdir -p "$PWD/docs/memory"
  cp -R "$PACK/docs/memory/." "$PWD/docs/memory/"
  echo "✓ docs/memory templates (registry, build_state, pending ledger)"
fi

# settings.json (permissions for claude.ai Webflow + Figma connectors)
if [ -f "$PWD/.claude/settings.json" ]; then
  echo "  .claude/settings.json exists — merge the allow-list from the pack manually"
else
  mkdir -p "$PWD/.claude"
  cp "$PACK/.claude/settings.json" "$PWD/.claude/settings.json"
  echo "✓ .claude/settings.json"
fi

echo ""
echo "=== Done ==="
echo "Connect the Webflow connector (and Figma connector if using Figma) in Claude,"
echo "open the Webflow Designer bridge app on your target page, restart Claude Code."
echo "No tokens needed in MCP mode. API fallback: export WEBFLOW_API_KEY + WEBFLOW_SITE_ID."

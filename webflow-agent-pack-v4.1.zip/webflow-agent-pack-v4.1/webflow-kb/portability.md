# Cross-Site Portability — full reference

## What survives DOM-API copy to another site
YES: section/div/container structure, headings/paragraphs/text, images (static src URL), link-blocks/buttons, HTML embeds, head/footer custom code (`custom_code` endpoint), CSS @keyframes, IntersectionObserver JS.
NO: **IX2 interactions** (live in project IX2 database — elements freeze at initial state, often opacity 0), **native Slider/Tabs** (`w-slider-*`/`w-tab-*` IDs assigned only by Designer — blank/dead after copy), **CMS bindings** (collection IDs differ — rebind), **Symbols** (site-specific IDs — recreate).
Partial: Navbar (structure copies, mobile JS needs Designer re-init).

## After-copy mandatory checklist
- Re-create IX2 interactions in new site Designer (specs from registry)
- Delete copied Slider/Tabs/Navbar shells → add fresh from Elements panel → re-apply BEM classes
- Re-map CMS bindings (field slugs from registry)
- Rebuild Symbols fresh
- Verify Webflow.js not excluded; test interactions desktop+mobile; test slider/tabs/accordion function

## Portable alternatives (use when section WILL be shared cross-site)
| Native (breaks) | Portable |
|-----------------|----------|
| Webflow Slider | Splide.js via JS embed |
| Webflow Tabs | ~10-line JS tab switcher in embed |
| IX2 scroll reveal | `[data-reveal]` CSS+IntersectionObserver (see interactions.md) |
| IX2 hover | CSS :hover + transition class style — copies with DOM |
| Accordion | native `<details>/<summary>` |

`data-*` hooks only when `build_spec.json` has `"portability":"cross-site"`, third-party requires, or `aria-*`.

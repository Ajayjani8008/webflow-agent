# Webflow Agent System v4 — Architecture & Migration

Refactored 2026-07-04 per "Webflow Agent System Refactor" spec. Previous system (v3.2, 19 agents) backed up at `~/.claude/backups/webflow-v3-20260704/`.

## Design
- **Flat workflow:** understand → execute → validate → finish. Main Claude / orchestrator IS the senior Webflow developer; agents only where isolation adds value.
- **Complexity classifier:** SMALL→FAST (direct, no agents/planning/confirmation), MEDIUM→STANDARD (inline plan + builder), LARGE→SAFE (phased plan, one confirmation, quality gate, checkpoints).
- **6 agents:** webflow-orchestrator, design-analyst (merged extract+translate → `build_spec.json`), webflow-builder, cms-builder, systematic-debugger, quality-reviewer.
- **Figma fast path:** 2 agents (~8–13K total), not 5 (~35K+). Single section: no user confirmation. design-analyst capped at 40 nodes / 4KB spec.
- **Deleted → absorbed:** semantic-analyzer + token-mapper + component-detector → design-analyst single pass. class/style/interaction agents → webflow-builder.
- **Two-level memory:** Global = rules/webflow/core.md + webflow-kb/ (incl. lessons.md, permanent). Project = docs/memory/webflow/{project.md, registry.md, pending_designer_work.md, build_state.json, handoff/}. Project archived → move dir to docs/memory/webflow-archive/.
- **Lazy loading:** always-loaded = core.md (~100 lines) + slim common/agents.md (~20) — was ~570 lines. Detail in webflow-kb/ read per task, at most once per session.
- **Quality preserved:** evidence rule (site read-back), pending-Designer-work ledger, status honesty (complete/partial/failed computed), DOM-replace merge protocol, native-first ladder, slug trap, IX2-no-API, component-init hazard — all retained.
- **Stopping conditions:** measurable progress per iteration; 2 attempts no progress → stop/report; 1 validation pass per item; no polish loops.
- **Permission policy:** auto-proceed additive staged work; ask only destructive/production/embed/integration.

## Backward compatibility
- Command names unchanged (all 19 /webflow:* commands work, bodies rewritten).
- Agent names kept where external references exist: webflow-orchestrator, webflow-builder, cms-builder, systematic-debugger.
- Old project registries (class_registry.md, variable_registry.md, cms_registry.md, component_registry.md, page_registry.md, interaction_registry.md): on first session in an old project, orchestrator consolidates them once into registry.md sections; originals left in place.
- Handoff schema simplified but same path (handoff/{agent}.json) + same evidence/status semantics; `registries_to_update_via_doc_updater` field dropped.
- session_state.md replaced by `## Progress` lines in project.md; build_state.json unchanged (resume works).

## Rollback
`cp ~/.claude/backups/webflow-v3-20260704/agents/* ~/.claude/agents/webflow/` (+ commands, rules, skills-root equivalents), delete v4-only files (design-analyst.md, quality-reviewer.md, rules/webflow/core.md).

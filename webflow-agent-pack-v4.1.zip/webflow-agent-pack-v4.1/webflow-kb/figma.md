# Figma → Webflow (fast path)

`FIGMA_TOKEN` for API. Screenshot = vision mode (no token).

## Pipeline — 2 agents (not 5)

| Step | Agent | Target tokens | Output |
|------|-------|---------------|--------|
| 1 | design-analyst | 3–5K | `build_spec.json` |
| 2 | webflow-builder | 5–8K | Webflow nodes + styles |

Merged in design-analyst (no separate spawn): element classification, var mapping, CMS/symbol detection.

**FAST (orchestrator):** curl Figma once → build inline or spawn builder only — 0–1 agents.

## URL parse
`figma.com/design/FILE_KEY/...?node-id=1-234` → node_id `1:234`.

## API (minimal)
```
GET /v1/files/{file_key}/nodes?ids={node_id}
```
Skip `geometry=paths`, skip `/styles` unless styles missing inline. Max depth: 5 (section) | 6 (page). Max nodes: 40 | 80.

## build_spec.json (only file between agents)

```json
{
  "section": "hero",
  "portability": "single-site",
  "new_vars": [],
  "native_required": [],
  "cms_candidates": [],
  "symbol_candidates": [],
  "tree": [{
    "id": "1:2", "wf": "Section", "class_hint": "hero",
    "layout": {"dir": "column", "gap": "--space-lg", "pad": "--space-xl"},
    "children": [
      {"id": "1:3", "wf": "Heading", "tag": "h1", "text": "...",
       "style": {"color": "--color-text", "size": "--font-3xl"}}
    ]
  }]
}
```

Rules: ≤4KB total. Vars not hex in tree. Omit nulls.

## Classification (inline in design-analyst)
- fontSize → h1–h4, p, span (see design-analyst.md)
- auto-layout frame → Section/DivBlock
- image fill → Image
- slider/tabs/nav/form → native WF types

## Token mapping (inline)
Spacing snap: 4/8/16/24/32/48/64/96/128 → xs…4xl. Colors ±15 RGB to existing vars; else `new_vars`.

## Deprecated (do not spawn)
`design_model.json`, `semantic_model.json`, `tokens.json`, `components.json`, `design_spec_current.md` — legacy only. webflow-builder accepts legacy if `build_spec.json` missing.

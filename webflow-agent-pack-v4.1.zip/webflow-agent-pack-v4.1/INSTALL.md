# Webflow Agent Pack v4.0 (2026-07-04)

Complexity-routed, token-optimized. 6 agents, 2-agent Figma path, lazy KB. See webflow-kb/architecture.md.

## Install (copy into ~/.claude/)
```bash
cp -r agents/webflow    ~/.claude/agents/
cp -r commands/webflow  ~/.claude/commands/
cp rules/webflow/core.md    ~/.claude/rules/webflow/
cp rules/common/agents.md   ~/.claude/rules/common/
cp -r webflow-kb        ~/.claude/
```
Remove any v3 leftovers in ~/.claude/rules/webflow/ (class-naming.md, responsive.md, interactions.md, cross-site-portability.md) and old agent files not in this pack — they double-load context otherwise.

## Contents
- agents/webflow/ — webflow-orchestrator, design-analyst, webflow-builder, cms-builder, systematic-debugger, quality-reviewer
- commands/webflow/ — all 19 /webflow:* commands (names unchanged from v3)
- rules/ — always-loaded core (~100 lines total)
- webflow-kb/ — lazy reference: api, naming, responsive, interactions, portability, cms, figma, lessons (global memory), architecture

## Requirements
Webflow MCP connector (preferred) or WEBFLOW_API_KEY + WEBFLOW_SITE_ID. Figma pipeline needs FIGMA_TOKEN.

## Old projects
First session auto-consolidates v3 per-registry files (class_registry.md etc.) into docs/memory/webflow/registry.md. build_state.json resume unchanged.

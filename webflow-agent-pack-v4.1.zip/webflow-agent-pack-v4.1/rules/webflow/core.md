# Webflow Core Rules (always loaded — everything else lazy-loads from ~/.claude/webflow-kb/)

Act like a senior Webflow developer: think, build, validate, finish. No agent chains for work Claude can do directly.

## 1. Complexity classifier (run mentally on every request — pick mode, never ask)

| Class | Examples | Mode | Path |
|-------|----------|------|------|
| SMALL | spacing, typography, move element, color, one section, alignment fix | FAST | Execute directly via MCP/API. No planning, no agents, no confirmation. |
| MEDIUM | landing section, Figma section, component, CMS collection | STANDARD | design-analyst → webflow-builder (2 agents). No confirmation for single section. |
| LARGE | full site, migration, design system, complex CMS | SAFE | build_spec per section → one confirm → builder per section → quality-reviewer before publish. |

Escalate mode only when evidence demands it; never downgrade quality checks in SAFE mode.

## 2. Agent roster (spawn ONLY these, only when needed)

| Agent | When |
|-------|------|
| `design-analyst` | Figma/screenshot → compact `build_spec.json` (extract + classify + tokens in one pass) |
| `webflow-builder` | Build one section from `build_spec.json` |
| `cms-builder` | `cms_candidates` in spec or collections/bindings |
| `systematic-debugger` | `bug::`/broken behavior needing investigation |
| `quality-reviewer` | custom JS/embed, external form, pre-publish gate |

Figma single section: max 2 agents. Orchestrator may build FAST with 0 agents. Never chain semantic-analyzer / token-mapper / component-detector.

Everything else (planning, FR analysis, architecture, SEO meta, registry updates, design review) = Claude native, inline. Never spawn an agent for it.

## 3. Permission policy

Auto-proceed (staged changes are reversible): build/append sections, create classes/styles/variables, create CMS collections/items, interactions, SEO meta.
ASK first: delete/replace existing content, overwrite an existing section, publish to production, html-embed use, external integrations, security-sensitive changes, bulk destructive ops.

## 4. Hard invariants (violations = stop and fix)

- Classes: kebab-case BEM — `block__element--modifier`. No numbers, colors, sizes, page names. Combo = base + modifier both applied. Check registry before creating.
- Native-first ladder: L1 native element → L2 IX2 → L3 class :hover/transition → L4 head CSS (@keyframes/:root only) → L5 page CSS → L6 JS embed → L7 html-embed (justify + user YES). Never skip levels. Slider/tabs/form/dropdown = native nodes, never embeds.
- All style values via CSS variables — no hardcoded hex/px.
- Animate only transform/opacity/filter — never width/height/margin/padding/top/left/font-size. Max 3 props. Scroll reveals: Limit once.
- `POST /v2/pages/{id}/dom` REPLACES page content — always GET, merge, POST. Same hazard check for MCP builders in replace mode.
- API/MCP-created slider/tabs/navbar/dropdown lack `w-*` init IDs → non-functional until re-added in Designer. Status `partial` + ledger entry, never claim working.
- Evidence rule: "complete" requires site read-back proof (node counts, styles listed). Self-attestation = fail.
- Every human-Designer task → append `- [ ] [agent] [date] [page/section] — task` to `docs/memory/webflow/pending_designer_work.md`. Never terminal-only. Surface unchecked items before claiming done.
- 4 breakpoints (1200/768/480/375) noted as Designer verification steps on every section.

## 5. Memory protocol (two levels)

**Global** (permanent, never auto-delete): these rules + `~/.claude/webflow-kb/lessons.md` (append durable lessons: API quirks, user preferences, patterns that worked).
**Project** (per project dir, archive when project done):
- `docs/memory/webflow/project.md` — site id/domain, brand tokens, architecture, decisions, progress, open tasks. Read FIRST every session (one file).
- `docs/memory/webflow/registry.md` — sections: `## Classes`, `## Variables`, `## Components`, `## CMS`, `## Pages`, `## Interactions`. Grep the section you need; never load whole file into every prompt.
- `docs/memory/webflow/pending_designer_work.md` — append-only ledger.
- `docs/memory/webflow/build_state.json` — checkpoint (resume support).
- `docs/memory/webflow/handoff/{agent}.json` — agent evidence handoffs (MEDIUM/LARGE only).
Project complete + archived → move `docs/memory/webflow/` to `docs/memory/webflow-archive/`. Global memory untouched.
Whoever does work updates the registry inline at end of run — no separate doc-updater pass.

## 6. Context awareness + duplicate prevention

Same project continuing → reuse project.md/registry.md; re-read only what changed. Never re-inspect, re-analyze, or rebuild what registry/build_state records as done — unless user explicitly asks. Before building: grep registry + build_state; already built → say so, skip.

## 7. Stopping conditions

Every iteration must produce measurable progress (node created, style applied, error resolved, root cause narrowed). No progress after 2 attempts → stop, report, re-plan or finish. Objectives met → finish; no unsolicited polish loops. Max 1 validation pass per built item unless it failed.

## 8. Lazy knowledge base (read ONLY the file the task needs, at most once per session)

| Task involves | Read |
|---------------|------|
| class naming detail, utility catalogue | `~/.claude/webflow-kb/naming.md` |
| responsive patterns/failures | `~/.claude/webflow-kb/responsive.md` |
| interactions/animations detail | `~/.claude/webflow-kb/interactions.md` |
| cross-site copy, portable components | `~/.claude/webflow-kb/portability.md` |
| REST API endpoints, node JSON | `~/.claude/webflow-kb/api.md` |
| CMS schema patterns | `~/.claude/webflow-kb/cms.md` |
| Figma extraction | `~/.claude/webflow-kb/figma.md` |
| accumulated lessons | `~/.claude/webflow-kb/lessons.md` |

Never load the whole KB. Never re-read a file already in context.

## 9. Mode detection (once per session)

`mcp__claude_ai_Webflow__*` tools present → MCP mode (cache guide_tool output to `docs/memory/webflow/mcp_capabilities.md`, skip if cached). Else API mode: `$WEBFLOW_API_KEY` + `$WEBFLOW_SITE_ID` via curl.

---
name: screenshot-to-webflow
description: Screenshot → design-analyst (build_spec.json) → webflow-builder. Same 2-agent fast path as figma-to-webflow.
---

# /screenshot-to-webflow

1. Spawn `design-analyst` with image + `SECTION=` → `build_spec.json` (confidence flags on colors).
2. Spawn `webflow-builder` with spec + PAGE.

No confirmation for single section. Do not spawn semantic-analyzer / token-mapper / component-detector.

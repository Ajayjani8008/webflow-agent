---
name: figma-to-webflow
description: Figma URL → 2-agent fast pipeline. design-analyst (build_spec.json) → webflow-builder. Single section = no confirmation. Full page = one confirm.
---

# /figma-to-webflow

## Fast pipeline (default — 2 agents, ~5 min target)

```
Figma API → design-analyst (~3-5K) → build_spec.json → webflow-builder (~5-8K) → done
```

1. **Classify scope:** single section → skip confirmation. Full page → one confirm after step 2.
2. Spawn `design-analyst` with Figma URL + `SECTION=` if known. Needs `FIGMA_TOKEN`.
   → `docs/memory/webflow/build_spec.json`
3. `new_vars` in spec → orchestrator creates vars inline (≤5 vars, kb/api.md) before builder.
4. `cms_candidates` → `cms-builder` only if collection needed.
5. Spawn `webflow-builder` with `build_spec.json` + PAGE + registry slice.
6. Surface pending designer work → done.

**Do NOT spawn:** semantic-analyzer, token-mapper, component-detector (merged into design-analyst).

## Scope flags
- `SECTION=hero` — extract one section only (≤40 nodes)
- No section flag + >40 nodes — ask which section first (don't extract whole page)

Auto-triggers on `figma.com/design` URLs.

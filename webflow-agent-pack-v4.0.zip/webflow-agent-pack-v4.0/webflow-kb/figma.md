# Figma Extraction — full reference

Requires `FIGMA_TOKEN` env (header `X-Figma-Token`).

## URL parse
`figma.com/design/FILE_KEY/...?node-id=1-234` → file_key + node_id `1:234` (replace `-` with `:`).

## Endpoints
- `GET https://api.figma.com/v1/files/{file_key}/nodes?ids={node_id}&geometry=paths` → save `/tmp/figma_node.json`
- `GET /v1/files/{file_key}/styles` → `/tmp/figma_styles.json`
Traverse max 8 levels (python recursion), tree to `/tmp/figma_tree.txt`.
Errors: 403 bad token | 404 bad id | >400 nodes → chunk requests.

## Classification
- Layer → WF element: frame w/ layout=section/div, text→heading/paragraph by size, rectangle+fill=image/div, auto-layout→flex div, repeated frames→collection/card pattern, anything slider/tabs-like → NATIVE element always.
- fontSize→level: ≥48 H1 | 36–47 H2 | 28–35 H3 | 22–27 H4 | 16–21 p | ≤15 text-span.
- Spacing px→var: 4/8/16/24/32/48/64/96/128/192 → xs/sm/md/lg/xl/2xl/3xl/4xl/5xl/6xl (snap to nearest).
- Colors: match existing variables ±15/channel; else flag new var.
- Detect: repeating patterns → CMS candidates; reused blocks → component candidates.

## Screenshot mode (no Figma)
Claude vision. Same classification + Design Spec format. Typography by relative size (3×body→H1~48, 2×→H2~32, body 16–18, small 12–14). Colors are estimates — mark "verify hex" + CONFIDENCE rating per element. ~80% spacing accuracy — flag for Designer polish.

## Design Spec output (write to docs/memory/webflow/design_spec_current.md)
Sections: OVERVIEW (page, sections list), per-section STRUCTURE (element tree + WF node types), TOKENS (existing vars matched / new_vars needed), CMS COLLECTIONS (if patterns detected), COMPONENTS (symbol candidates), INTERACTIONS (observed/implied), PORTABILITY (single-site | cross-site), CONFIDENCE notes (screenshot mode).

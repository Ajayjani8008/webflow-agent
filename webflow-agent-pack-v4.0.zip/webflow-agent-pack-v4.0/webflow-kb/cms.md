# CMS — full reference

## Decision: CMS vs static
CMS if: edited >1×/month, >5 instances, non-dev edits, or needs detail page. Else static. Hard limit 10K items/collection.

## Endpoints
| Op | Call |
|----|------|
| Create collection | `POST /sites/{site}/collections` body `{displayName, singularName, slug}` |
| Add field | `POST /collections/{col}/fields` body `{isRequired, type, displayName, slug}`; Option type adds `validations.options[{id,name}]` |
| Create items | `POST /collections/{col}/items` / `/items/bulk` (max 100/call) — fieldData + isArchived/isDraft |
| Update item | `PATCH /collections/{col}/items/{item}` |
| Publish items | `POST /collections/{col}/items/publish` body `{itemIds:[]}` |
| Read | `GET /collections/{col}` / `GET /collections/{col}/items?limit=` |

Field types: PlainText, RichText, ImageRef, MultiImage, Bool, Number, DateTime, Link, Email, Option, ItemRef, MultiRef, Video, FileRef.

## ⚠ SLUG TRAP
`name` and `slug` fields auto-exist on every collection. POSTing them to `/fields` → 422, aborts schema. Never create them.

## Mid-schema failure protocol
Any field POST 422 → STOP. Record fields_created vs fields_failed, status failed. Never continue blind.

## Verification (mandatory evidence)
GET collection → compare field slugs vs plan. GET items → count ≥ expected. This output = handoff evidence.

## Page binding (native only)
- `collection-list-wrapper` node carries `collectionId` in data.
- Element field bindings inside `collection-item` via xattr:
```json
{"type":"heading","data":{"tag":"h3","classes":["card__title"],
  "xattr":[{"name":"textContent","binding":"name"}]}}
```
xattr name values: `textContent` | `src` | `alt` | `href` | `innerHTML` | `style`. binding = field slug.
- link-block href → "Current [Singular]" (Designer).
- RichText bindable ONLY on CMS Template pages.
- Limit/Sort/Filter = Collection List Designer settings.
- Wrapper collection-binding confirmation is Designer work → unconfirmed binding = status partial + ledger. Unbound collection = incomplete deliverable.

## Sync from external source (CSV/JSON/API)
Map fields → transform → bulk POST (100/call, 60 req/min). Images = public URLs, RichText = HTML string, relationships = existing item IDs.

## SEO in CMS
Collections need seo-title/seo-description fields; template page meta must be Designer-bound (dynamic) — cannot automate → ledger entry.

## Registry entry format (append to `## CMS` in registry.md)
Collection: slug, ID, singular, template page, field table `| slug | type | required | notes |`, SEO bindings.

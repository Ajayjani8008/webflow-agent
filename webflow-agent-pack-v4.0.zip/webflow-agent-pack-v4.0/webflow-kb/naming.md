# Class Naming (BEM) — full reference

## Format
`block` / `block__element` / `block__element--modifier` — kebab-case only, all lowercase.

Forbidden in names: camelCase, single underscore, numbers (`card-1`→`card`, stagger via interaction), page prefixes (`home__hero`→`hero`), color names (`btn--blue`→`btn--primary`), size absolutes (`text-24`→`text-xl`), tag names, `.temp`/`.div1`-style junk.

## Block = section root, card/repeated item, nav element, form (section), modal/overlay, custom UI component (accordion/tabs/slider).
NOT a block: generic wrapper inside a block (`block__inner`, `block__content`), utilities.

## Combo classes
Node JSON: `"classes": ["base", "base--modifier"]` — base first, always both.
`["btn--primary"]` alone = wrong. `["btn", "primary"]` orphan modifier = wrong.

## Utility allowlist (global, never redefine)
`.container` (+`--wide` 1440, `--narrow` 800), `.section-pad` (+`--sm`, `--lg`), `.btn` (+`--primary --outline --sm --lg`), `.show-desktop .hide-desktop .show-mobile .text-center .visually-hidden`

```css
.container   { max-width: 1200px; margin: 0 auto; padding: 0 var(--space-lg); }
.section-pad { padding: var(--space-5xl) 0; }
```

## Reuse mandate
Before any new class: grep `## Classes` in docs/memory/webflow/registry.md. Similar exists → reuse or add modifier. Two classes doing the same thing = tech debt.

## Gray areas
| Situation | Decision |
|-----------|---------|
| Card in 3 sections | `.card` generic + modifier if needed |
| Heading everywhere | H-levels + `.section-header__title` |
| Unnamed section | Name by content: `.testimonials`, `.faqs`, `.pricing` |
| One-off section | Still semantic: `.founders-story` |
| Animation states | Via IX2/CSS transition — no state class |

## Registry entry format (append to `## Classes` in registry.md)
`| class | purpose | vars used | modifiers | used on |`

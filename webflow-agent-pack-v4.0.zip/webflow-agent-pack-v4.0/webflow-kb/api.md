# Webflow REST API v2 + node reference

Base `https://api.webflow.com/v2`, header `Authorization: Bearer $WEBFLOW_API_KEY`. Rate limit 60 req/min (429 → wait 1s). Endpoint spelling: `custom_code` (underscore) — standardized.

## Endpoints
| Op | Call |
|----|------|
| List pages | `GET /sites/{site}/pages` → id, slug, title, seo{}, openGraph{} |
| Create page | `POST /sites/{site}/pages` |
| Page DOM | `GET /pages/{page}/dom` / `POST /pages/{page}/dom` ⚠ REPLACES ALL — see hazard |
| Page SEO | `PATCH /pages/{page}` body `{seo:{title,description}, openGraph:{title,description,image:{url,alt}}}` |
| Variables | `POST /sites/{site}/variables` body `{name, type: Color|Size|PlainText, value}` |
| Custom code | `GET|PUT /sites/{site}/custom_code` (headCode/footerCode; warn >10000 chars) |
| Publish | `POST /sites/{site}/publish` — staging `{publishToWebflowSubdomain:true}`, production `{..:false, customDomains:[...]}` |
| Site info | `GET /sites/{site}` → displayName, defaultDomain, customDomains, lastPublished |
| Assets | `GET /sites/{site}/assets` (flag >200KB) |
| Collections | see cms.md |

Error codes: 401 bad token | 403 missing scope (pages:write) | 404 wrong id | 422 invalid body/node | 429 rate.

## ⚠ DOM REPLACE HAZARD
`POST /pages/{id}/dom` replaces the ENTIRE page. Always: (1) GET current DOM → (2) append new section nodes → (3) POST merged tree. Capture HTTP code; non-2xx OR 0 nodes returned = failed, stop. Same rule for MCP `element_builder`/`whtml_builder` in replace mode — snapshot first via `element_snapshot_tool`.

## What API CANNOT do (Designer-only → pending ledger, status partial)
1. Class styles (API mode) — MCP `style_tool` is the ONLY programmatic path; REST has no endpoint. API mode → DESIGNER STEPS.
2. IX2 interactions (no API/MCP at all).
3. Symbols — cannot create; build nodes on `_components` page, human right-click → Create Symbol.
4. Collection List collection-binding on wrapper is Designer; item field xattr bindings ARE API-settable (see cms.md).
5. Component init IDs — API/MCP-created slider/tabs/navbar/dropdown lack `w-*` IDs → non-functional until re-added fresh in Designer.
6. All writes are STAGED — nothing live until publish.

## Node types (L1 — always prefer)
section | container | div-block | heading (`data.tag:"h1"-"h6"`) | paragraph | text-span | image (src empty, never placeholder services — user uploads; empty src → ledger + partial) | text-link | link-block (buttons = link-block + btn classes) | richtext | grid | columns→column | video | background-video | navbar⚠ | slider→slide⚠ | tabs→tabs-menu+tabs-content⚠ | dropdown→dropdown-toggle+dropdown-list⚠ | lightbox | component (`componentId`) | collection-list-wrapper→collection-list→collection-item | form-block→form-form→fields (label + text-input/textarea/select/checkbox/radio + button; REQUIRED `form-success`+`form-error` sibling divs or form structurally incomplete)
⚠ = init warning above.

## Node JSON shape
```json
{"type":"section","data":{"attr":{"id":"hero"},"classes":["hero"]},"children":[
  {"type":"heading","data":{"tag":"h1","classes":["hero__title"],"text":"Headline"}},
  {"type":"link-block","data":{"classes":["btn","btn--primary"],"attr":{"href":"#contact"}},
   "children":[{"type":"text-span","data":{"text":"Get Started"}}]}]}
```

## MCP mode tools
`webflow_guide_tool` (once, cache output), `data_sites_tool` (SITE_ID), `data_pages_tool`, `element_builder`/`whtml_builder` (nodes), `element_snapshot_tool` (verify/evidence), `data_style_tool`/`style_tool` (class styles), `data_variable_tool` (variables), `data_cms_tool`.

## Standard variable set (43 vars — full-setup)
Colors(13): --color-primary #0050ff, primary-dark #003acc, secondary #ff6b00, text #1a1a1a, text-muted #6b7280, surface #fff, surface-alt #f8f9fa, surface-dark #111827, border #e5e7eb, error #ef4444, success #22c55e, warning #f59e0b (+1 site accent).
Space(10): xs 4 / sm 8 / md 16 / lg 24 / xl 32 / 2xl 48 / 3xl 64 / 4xl 96 / 5xl 128 / 6xl 192.
Font-size(13): xs 12 → 7xl 72 scale.
Radius(4): sm 4 / md 8 / lg 16 / full 9999.
Transition(3): fast 150ms / base 250ms / slow 400ms; easing cubic-bezier(0.4,0,0.2,1).

## Style application rule (#1 blank-build cause)
Attaching class names to nodes applies NO styles. Style application = dedicated step after build: MCP → style_tool desktop styles (tablet/mobile as Designer steps unless ≤3 overrides), read-back required for complete; API → DESIGNER STEPS + partial. Head CSS only for @keyframes/:root/third-party resets — NEVER BEM class styles.

## Style audit
`grep -rn "#[0-9a-fA-F]\{6\}"` on any produced CSS — hardcoded hex = violation, map to vars (#0050ff→--color-primary, 24px→--space-lg, 8px→--radius-md).

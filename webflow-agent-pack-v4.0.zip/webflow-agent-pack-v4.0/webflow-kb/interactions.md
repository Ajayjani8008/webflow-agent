# Interactions — full reference

## CRITICAL: IX2 has NO API/MCP. Every IX2 spec = human Designer work → pending_designer_work.md ledger + handoff `pending_designer_work`; status `partial` until executed. NEVER pre-apply hidden initial states (opacity:0) via class styles — blank sections; set initial state inside IX2 panel only.

## Route by type (native-first)
| Effect | Method | Level |
|--------|--------|-------|
| Hover (lift/color/scale) | CSS :hover + transition in class panel | L3 — portable, preferred over IX2 hover |
| Scroll reveal | IX2 scroll-into-view OR portable `[data-reveal]`+IntersectionObserver (cross-site only) | L2 / L4+L6 |
| Tabs/slider/accordion | native elements / `<details>` | L1 |
| Counter | JS embed `[data-counter]` + IntersectionObserver | L6 |
| Marquee | CSS @keyframes (head) | L4 |
| Sticky nav restyle | IX2 page-scroll 80px, 200ms | L2 |

## Standards (site-wide, consistent — check `## Interactions` in registry.md before creating; same type = same timing)
- Scroll reveal: fade+translateY(24px), 500ms ease-out, trigger 10% from bottom, **Limit: once** always
- Hero load: sequence 0/150/300ms
- Card hover lift: `transform: translateY(-4px)` + shadow, var(--duration-base) ease-out
- Stagger: 2–3 items 100ms | 4–6 80ms | 7–12 60ms | >12 40ms/none. Never >150ms.

## Never animate (reflow → jank)
width, height (accordion exception, careful), margin, padding, top/left/right/bottom, font-size, border-width.
Use: transform translate/scale, opacity, filter. Max 3 props per element per step.

## Mobile
Parallax OFF at tablet+mobile. Hover→tap ok. Counters keep. Custom cursor display:none mobile. iOS scroll reveals: 10% bottom offset.

## Performance limits
Max 5 unique interaction types/page, max 20 scroll-trigger instances/page. Heavy pages: test 4× CPU throttle.

## Portable JS library (code embeds — cross-site safe)
Scroll reveal (head custom code):
```html
<style>[data-reveal]{opacity:0;transform:translateY(24px);transition:opacity .5s ease-out,transform .5s ease-out}[data-reveal].is-visible{opacity:1;transform:none}</style>
<script>const o=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');o.unobserve(e.target)}})},{rootMargin:'0px 0px -10% 0px'});document.querySelectorAll('[data-reveal]').forEach(el=>o.observe(el));</script>
```
Counter: IntersectionObserver on `[data-counter]`, animate int to `data-counter` value.
Accordion: native `<details>/<summary>`; exclusive-open = small JS closing siblings.
Wrap Webflow-dependent JS in `Webflow.push(function(){...})`.

## Registry entry format (append to `## Interactions` in registry.md)
`| name | trigger | element | type (IX2/CSS/JS) | duration/easing/stagger | used on |`

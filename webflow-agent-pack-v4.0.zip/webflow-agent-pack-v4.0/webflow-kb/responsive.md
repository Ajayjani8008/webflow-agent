# Responsive — full reference

## Webflow breakpoints (desktop-first cascade: Desktop → Tablet → Mobile-L → Mobile-P)
| Breakpoint | Range | Test at |
|-----------|-------|---------|
| Desktop (base) | ≥992px | 1200px |
| Tablet | 768–991px | 768px |
| Mobile landscape | 480–767px | 480px |
| Mobile portrait | ≤479px | 375px (not 479) |

Every section verified at all 4 before complete. Agent cannot render — breakpoint verification = pending Designer work, never self-checked.

## Standard patterns
- Grid: 3col → 2col (tablet) → 1col (mobile)
- Flex row → column at tablet/mobile (column-reverse for media swap)
- H1: 6xl → 5xl → 4xl. H2: 5xl → 4xl → 3xl (font-size vars)
- Section pad: 5xl → 4xl → 3xl. Container pad: lg → md → sm
- Mobile: images `width:100%; max-width:100%`; buttons `width:100%`; section headings `text-align:center` usually

## Common failures → fixes
| Problem | Fix |
|---------|-----|
| Nav links overflow tablet | display:none, hamburger active |
| Card text long on mobile | max-width or font-size override |
| Hero image wrong mobile | height override + object-fit:cover |
| 2-col narrow on tablet | stack 1 col or reduce padding |
| Absolute element bleeds | relative at mobile |
| Wrong gaps | gap override per breakpoint |
| Interaction wrong on touch | IX2 "Affects mobile" checkbox |

## Webflow notes
- Grid columns: override grid-template-columns per breakpoint in Designer
- Navbar element handles mobile menu — never custom-build hamburger

---
name: create-section
description: Builds a section on an existing Webflow page. Classifies complexity — simple sections build immediately; medium/large route to webflow-builder (owns classes, nodes, styles, interactions in one call). Native Webflow elements always.
---

# /create-section

1. Classify per core rules: simple section → FAST (build directly, no agent). Else → spawn `webflow-builder` with SITE/SITE_ID/MCP_MODE/PAGE(resolved) + description + grepped registry slices.
2. Missing requirements (page, content, layout) → ask ONCE, all questions together.
3. Verify handoff evidence → surface pending_designer_work → done. No separate class/style/interaction agents — builder owns all of it.

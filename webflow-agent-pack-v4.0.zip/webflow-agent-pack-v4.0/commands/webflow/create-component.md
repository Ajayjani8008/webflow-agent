---
name: create-component
description: Designs and builds a reusable component (Symbol). Builds node tree on the _components page via webflow-builder; Symbol creation itself is Designer-only.
---

# /create-component

1. Spawn `webflow-builder`: build component node tree on the `_components` page (create page if missing). Builder handles classes/styles/portability (check kb/portability.md if cross-site).
2. API cannot create Symbols → ledger entry: "right-click → Create Symbol in Designer + name it". Status partial until done.
3. Append component entry to `## Components` in registry.md.

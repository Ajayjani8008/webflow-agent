---
name: debug
description: Mandatory gate for all Webflow bugs. Routes to systematic-debugger. Never fix before diagnosis.
---

# /debug

Spawn `systematic-debugger` with BUG (verbatim) + evidence flags. Triggers: bug:: / issue:: prefix, "broken", "not working". It returns root cause + fix scope + fix owner. Then execute the fix (direct or via named agent). Blank-page issues: debugger self-serves from ledger + handoffs + kb/lessons.md route.

---
name: plan
description: Inline planning for medium/large Webflow features — requirements, phases, dependencies. Claude native; no planner agents.
---

# /plan

Do inline (no agents): 1) Requirement echo (pages, CMS needs — CMS if edited >1×/month, >5 instances, non-dev edits, or detail page; interactions; components). 2) Phase plan in build order: variables → CMS → components → pages/sections → interactions → SEO → publish, with agent per phase and Designer-only steps flagged. 3) ONE confirmation → execute phases. Store plan in project.md `## Open tasks`.

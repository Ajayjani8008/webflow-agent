---
name: figma-to-webflow
description: Figma URL → Webflow build. design-analyst extracts Design Spec (8-level traversal), user confirms spec once, then webflow-builder builds per section.
---

# /figma-to-webflow

1. Spawn `design-analyst` with the Figma URL (needs FIGMA_TOKEN). → Design Spec at docs/memory/webflow/design_spec_current.md.
2. Show 10-line spec summary → ONE user confirmation (this is a LARGE-path gate; spec drives everything downstream).
3. new_vars → create directly (kb/api.md). cms_collections_needed → `cms-builder`.
4. Per section: spawn `webflow-builder` with DESIGN_SPEC_FILE + resolved PAGE. Verify each handoff.
5. Surface pending_designer_work ledger → done. Auto-triggers on any figma.com/design URL.

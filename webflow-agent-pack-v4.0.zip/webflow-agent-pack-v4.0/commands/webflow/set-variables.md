---
name: set-variables
description: Creates or updates Webflow design variables. full-setup installs the standard 43-var set; add/update/audit for individual vars.
---

# /set-variables

Direct execution (FAST — no agent). Standard 43-var set + endpoint in kb/api.md. MCP: data_variable_tool; API: POST /sites/{id}/variables. Subcommands: full-setup | add | update | audit (audit = grep hardcoded hex/px in custom code + report off-scale values). Update `## Variables` in registry.md.

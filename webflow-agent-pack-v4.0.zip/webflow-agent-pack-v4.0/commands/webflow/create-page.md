---
name: create-page
description: Creates a new Webflow page via REST API/MCP. Sets slug, title, SEO meta. Registers in registry.md.
---

# /create-page

Direct execution (FAST — no agents): `POST /sites/{id}/pages` (or data_pages_tool) → `PATCH /pages/{id}` with seo{} → append to `## Pages` in docs/memory/webflow/registry.md. Sections on the page → /create-section per section.

---
name: connect-cms
description: Connects existing page elements to CMS fields via xattr bindings. Collection List wrapper binding is Designer-only.
---

# /connect-cms

Spawn `cms-builder` with page + collection + element↔field map. xattr schema in kb/cms.md (`textContent|src|alt|href|innerHTML|style` → field slug). Wrapper collection-binding + Limit/Sort/Filter = Designer steps → ledger. Unconfirmed bindings = partial, never claim complete.

---
name: add-interaction
description: Designs a Webflow interaction/animation — CSS hover, IX2 spec, or portable JS. Consistent site-wide timings from the interaction registry.
---

# /add-interaction

Direct execution (FAST — no agent): read kb/interactions.md once. Route: hover → CSS class transition; scroll reveal → IX2 spec (Designer work → ledger) or portable [data-reveal] if cross-site; counters/marquee → JS/CSS embed. Same type = same timing (check `## Interactions` in registry.md). Never animate layout props. Append registry entry + ledger items. Shortcut: `/add-interaction scroll-reveal .card`.

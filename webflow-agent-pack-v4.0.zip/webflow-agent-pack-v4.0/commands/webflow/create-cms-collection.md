---
name: create-cms-collection
description: Creates a Webflow CMS collection with fields and sample items via cms-builder. Schema documented in registry before creation.
---

# /create-cms-collection

Spawn `cms-builder` with SITE/SITE_ID/MCP_MODE + collection requirements + grepped `## CMS` registry slice. It designs schema → creates → verifies by read-back → updates registry. Verify handoff evidence; surface Designer binding steps.

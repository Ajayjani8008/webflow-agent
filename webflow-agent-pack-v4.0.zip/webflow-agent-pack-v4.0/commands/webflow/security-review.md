---
name: security-review
description: Security scan — XSS, exposed secrets, form security, SRI, clickjacking, mixed content.
---

# /security-review

Spawn `quality-reviewer` with SCOPE: security. Webflow ws- token exposure = CRITICAL. BLOCK on any HIGH+. Page passwords ≠ auth; no secrets in CMS fields.

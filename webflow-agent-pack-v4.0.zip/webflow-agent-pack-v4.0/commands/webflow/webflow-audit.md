---
name: webflow-audit
description: Site health check — connectivity, pages, SEO presence, CMS, assets, publish status.
---

# /webflow-audit

Direct execution (FAST): GET /sites/{id} (domains, lastPublished) | /pages (count + seo{} presence) | /collections (ids/slugs) | /assets (flag >200KB). Summarize health + gaps. Deep issues → route to /quality-gate or /debug.

---
name: screenshot-to-webflow
description: Screenshot/reference image → Webflow build. design-analyst (vision) extracts Design Spec with confidence ratings, then same pipeline as figma-to-webflow.
---

# /screenshot-to-webflow

Spawn `design-analyst` with the image → spec + CONFIDENCE ratings (~80% spacing accuracy — colors marked "verify hex"). Show summary + confidence caveats → one confirmation → continue /figma-to-webflow steps 3–5.

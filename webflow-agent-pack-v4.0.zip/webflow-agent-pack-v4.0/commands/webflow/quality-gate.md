---
name: quality-gate
description: Full pre-publish gate — code, security, performance, SEO in one reviewer pass. Writes quality_gate_verdict.json.
---

# /quality-gate

Spawn `quality-reviewer` with SCOPE: full. One agent, one code-collection pass, four dimensions. Consolidated findings by severity + VERDICT. Writes docs/memory/webflow/quality_gate_verdict.json (publish checks it). Also surface unchecked pending_designer_work.

---
name: code-review
description: Reviews all custom code (embeds, head/footer code) for native-first violations, shortcut CSS, var compliance, JS quality.
---

# /code-review

Spawn `quality-reviewer` with SCOPE: code. Collects custom_code + embeds, checks native-first/shortcut-CSS/vars/Webflow.push/DOMPurify. VERDICT BLOCK on CRITICAL.

---
name: fix-responsive
description: Audits and fixes responsive issues across the 4 Webflow breakpoints. Class-level fixes via style_tool or Designer steps.
---

# /fix-responsive

Direct execution unless cause unclear (then `systematic-debugger`). Breakpoints + failure→fix table in kb/responsive.md (test at 1200/768/480/375). Fixes: MCP style_tool per-breakpoint or DESIGNER STEPS + ledger. Breakpoint rendering can't be self-verified → ledger entries for human check.

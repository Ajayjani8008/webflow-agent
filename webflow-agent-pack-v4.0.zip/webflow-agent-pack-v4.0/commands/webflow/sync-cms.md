---
name: sync-cms
description: Syncs external content (CSV/JSON/API) into Webflow CMS collections via cms-builder bulk operations.
---

# /sync-cms

Spawn `cms-builder`: map source fields → transform (images = public URLs, RichText = HTML string, refs = existing item IDs) → `POST /collections/{id}/items/bulk` (100/call, 60 req/min) → verify item counts by read-back.

---
name: publish
description: Publishes the site to staging or production. Production always requires explicit confirmation + quality gate + pending-work check.
---

# /publish

Staging: `POST /sites/{id}/publish {publishToWebflowSubdomain:true}` — proceed after surfacing pending ledger. Production: 1) check quality_gate_verdict.json (missing/BLOCK → run /quality-gate first), 2) show unchecked pending_designer_work, 3) explicit warning + wait for "yes", 4) `{publishToWebflowSubdomain:false, customDomains:[...]}` (domains from GET /sites/{id}), 5) verify `curl -I` on domain.

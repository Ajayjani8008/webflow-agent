---
name: fix-spacing
description: Audits spacing consistency — hardcoded px, off-scale gaps, misaligned elements. Produces fix list and applies safe fixes.
---

# /fix-spacing

Direct execution (FAST): grep custom code for hardcoded px, read styles (style_tool/snapshot), compare to space scale (kb/api.md). Fix via style_tool (MCP) or DESIGNER STEPS + ledger (API). Off-scale values snap to nearest var.

# Webflow GOAT Agent — Backup v1.1.1

**Created:** 2026-07-16
**Source machine:** C:\Users\ajayk

Pixel-perfect, native-only Webflow build agent (Figma / screenshot / HTML → Webflow via MCP). Zero custom code.

## What's inside → where it lives on the machine

| Backup path | Restore to | What it is |
|---|---|---|
| `CLAUDE.md` | `C:\Users\ajayk\CLAUDE.md` | Agent brain: rules, workflow, source routing, portable mode, "never" list |
| `skills/*` | `C:\Users\ajayk\.claude\skills\` | 6 lazy-load skills: build-reference, design-intake, figma-setup, pixel-verify, responsive-pass, session-recovery |
| `docs-memory/*` | `C:\Users\ajayk\docs\memory\` | Registries, build_state, pending_designer_work, impossible_cases, figma-cache, screenshot scripts (shot-el.js / shot.js) |
| `auto-memory/*` | `C:\Users\ajayk\.claude\projects\C--Users-ajayk\memory\` | Cross-session memory (webflow-*.md) + MEMORY.md index |

`node_modules` (the `ws` dep for screenshots) intentionally excluded — reinstall with `npm i ws --no-save` at `C:\Users\ajayk`.

## v1.1.1 changes (this backup)
- Rule 3: `gap` and `border-radius` added to the shorthand→longhand list (they were leaking into Webflow's Custom Properties panel). Use `grid-column-gap`+`grid-row-gap` and the 4 per-corner radius props.
- design-intake: NODE-FIRST fetch — never `get_metadata` the page root (~1MB dump); climb one parent at most.
- pixel-verify: post-batch element-count check (catch builder duplicates early); PUBLISH ONCE (interim = element_snapshot); permanent element-clip screenshot script `shot-el.js`.
- CLAUDE.md Phases 2 & 3 updated to match.

## Known limits (native / MCP)
- No IX2/interaction API in MCP → all motion is manual Designer work.
- Gradient-clipped text not settable via API → solid fallback + Designer finish.
- CSS rotation not native.
See `docs-memory/impossible_cases.md` and `auto-memory/webflow-mcp-gotchas.md`.

## Restore
Copy each backup path back to its "Restore to" location (table above). Then `npm i ws --no-save` at `C:\Users\ajayk` if using published-page screenshots.

# Component Registry

## [Symbol Name]
**Root class:** .[class]
**Modifiers:** .[variant] × N
**CMS:** yes → [collection] | no
  - .[element] → [field-slug]
**Interaction:** [name]
**Cross-site safe:** yes | no
**Used on:** [pages]
**Built:** YYYY-MM-DD

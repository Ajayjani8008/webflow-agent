# Page Registry

## /[slug]
**Type:** Static | CMS Template
**Sections:** [list]
**CMS:** [collection name + Collection List location, or "none"]
**Symbols:** [list]
**Classes:** [primary section classes]
**Interactions:** [interaction names]
**SEO:** [title set | meta set | OG set | pending]
**Status:** Draft | Published
**Built:** YYYY-MM-DD

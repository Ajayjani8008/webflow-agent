# Class Registry

## [class-name]
**Purpose:** [one line]
**Styles:** [key properties with variable references]
**Responsive:** [breakpoint overrides or "none"]
**Symbol:** [symbol name or "none"]
**Used on:** [pages]

# Variable Registry

| Variable | Value | Description |
|----------|-------|-------------|
| --color-text | #1a1a1a | Body text |
| --color-text-secondary | #666666 | Muted text |
| --color-heading | #0d0d0d | Heading text |
| --color-background | #ffffff | Page background |
| --color-surface | #ffffff | Card/section surface |
| --color-surface-alt | #f5f5f5 | Alt surface |
| --color-primary | #0050ff | Primary brand |
| --color-primary-dark | #003db8 | Primary hover |
| --color-secondary | #6b3aff | Secondary brand |
| --color-accent | #ff6b00 | Accent |
| --color-border | #e5e5e5 | Borders/dividers |
| --color-success | #22c55e | Success |
| --color-error | #ef4444 | Error |
| --space-xs | 4px | Very tight |
| --space-sm | 8px | Tight |
| --space-md | 16px | Standard |
| --space-lg | 24px | Comfortable |
| --space-xl | 32px | Section elements gap |
| --space-2xl | 48px | Section internal padding |
| --space-3xl | 64px | Section spacing |
| --space-4xl | 96px | Large section padding |
| --space-5xl | 128px | Hero padding |
| --space-6xl | 192px | Max hero padding |
| --font-size-sm | 14px | Small text |
| --font-size-base | 16px | Body |
| --font-size-lg | 18px | Large body |
| --font-size-xl | 20px | Subtitle |
| --font-size-2xl | 24px | H4 |
| --font-size-3xl | 28px | H3 |
| --font-size-4xl | 36px | H2 |
| --font-size-5xl | 48px | H1 |
| --font-size-6xl | 60px | Hero H1 |
| --font-size-7xl | 72px | Large hero |
| --radius-sm | 4px | Buttons/badges |
| --radius-md | 8px | Cards |
| --radius-lg | 12px | Modals |
| --radius-xl | 16px | Sections |
| --duration-fast | 200ms | Hovers |
| --duration-base | 300ms | Standard |
| --duration-slow | 500ms | Reveals |
| --ease-out | cubic-bezier(0.4,0,0.2,1) | Standard easing |

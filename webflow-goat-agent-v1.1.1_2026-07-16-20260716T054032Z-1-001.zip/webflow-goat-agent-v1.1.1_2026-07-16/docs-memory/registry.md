# Project Registry — one line per item, grep the section you need

## VALIDATION RULES (apply before creating any item)

**Before creating a class:**
1. Grep `## Classes` for same name → if exists, reuse
2. Grep `## Classes` for same purpose (same element + same page/section) → if exists, reuse even if name differs
3. Validate name matches `/^[a-z][a-z0-9-]*(__[a-z][a-z0-9-]*)?(--[a-z][a-z0-9-]*)?$/`
4. No duplicate purpose: two classes doing the same job = debt

**Before creating a variable:**
1. Grep `## Variables` for same name → if exists, reuse
2. Grep `## Variables` for same value (within tolerance: color ±15/channel, spacing ±10%) → if exists, reuse
3. Validate value format: color = valid hex/rgba, spacing = numeric px, font-size = numeric px
4. Variable name must follow family pattern: `--color-*`, `--space-*`, `--font-size-*`, `--radius-*`, `--duration-*`, `--easing-*`

**Before creating a page entry:**
1. Grep `## Pages` for same slug → if exists, update sections built count, don't duplicate

**Before creating a component:**
1. Grep `## Components` for same structure + classes → if exists, reuse Symbol

**Before logging an interaction:**
1. Grep `## Interactions` for same type + trigger → if exists, reuse timing/easing

## Site
<!-- site: name | site_id | domain | mode: MCP/API | font(s) installed -->

## Classes
<!-- .class-name — purpose — page/section — YYYY-MM-DD -->
<!-- FORMAT: .block-name__element--modifier — description — page/section — date -->
<!-- DEDUP: grep this section before creating. Same purpose = reuse existing class -->
<!-- VALIDATION: name must match /^[a-z][a-z0-9-]*(__[a-z][a-z0-9-]*)?(--[a-z][a-z0-9-]*)?$/ -->

## Variables
<!-- --var-name: value — role — YYYY-MM-DD -->
<!-- FORMAT: --family-name: value — purpose — date -->
<!-- DEDUP: grep this section before creating. Same value within tolerance = reuse existing -->
<!-- VALIDATION: color = valid hex/rgba, spacing = numeric px, font-size = numeric px -->
<!-- TOLERANCE: color ±15/channel, spacing ±10%, font-size ±1px -->

## Pages
<!-- /slug — title — sections built — status -->
<!-- STATUS: complete | partial (with pending_designer_work.md items) | in-progress -->

## Components
<!-- Symbol name — classes — portable? — used on -->
<!-- PORTABLE: yes = no IX2/CMS deps, no = needs Designer re-init on target site -->

## Interactions
<!-- name — trigger — effect — timing/easing — applied to -->
<!-- CONSISTENCY: same interaction type site-wide = same timing/easing -->
<!-- LIMITS: max 3 animated props, max 150ms duration, no width/height/margin/padding -->

## CMS
<!-- collection — fields (slugs) — bound sections -->
<!-- DEPS: collection ids are site-specific, not portable -->
Help Articles (6a538d675def5a24216a734f) — name, slug, category, accent(Color, unused-see impossible), excerpt, tags, article-link, image, show-image(Switch), show-tags(Switch) — bound to hc-articles Collection List (partner-program). 4 items. Template page 6a538d675def5a24216a7355.

## Impossible-Cases
<!-- design-feature — why-impossible — alternative-offered — section — date -->
<!-- Every entry must have a native alternative offered -->
<!-- If no alternative exists: mark as "no-native-alternative" and flag to user -->
CMS Color→style-property binding — Webflow color fields have bindableTo:[] (cannot bind to text/bg color) — used fixed violet #7c3aed for all badges — hc-articles — 2026-07-12
3 article layouts in one Collection List — a list repeats ONE template — unified card template per user decision; hex SVG dropped — hc-articles — 2026-07-12
CMS text created via Data API not shown on open Designer canvas — store staleness — hard-reload Designer or publish — hc-articles — 2026-07-12

## Classes (Help Articles — 2026-07-12, node 578:2791, CMS dynamic, light)
.hc-art-list — DynamoList flex col, gap 24, width 100% — partner-program
.hc-art-card — card flex row, white, 1px #e8e4ff, radius 16, shadow, min-h 260; small→column — partner-program
.hc-art-card__media — 50% width, min-h 320, overflow hidden; small→100%/220 — partner-program
.hc-art-card__img — 100%x100% object-fit cover (bound: image) — partner-program
.hc-art-card__body — flex col justify-center, flex 1, pad 48; small→32; tiny→24 — partner-program
.hc-art-card__badge — pill inline-flex #f4f0fe / #e6ddfc border — partner-program
.hc-art-card__dot — 6px violet #7c3aed circle — partner-program
.hc-art-card__badge-text — 11px 700 uppercase #7c3aed (bound: category) — partner-program
.hc-art-card__title — H3 22px 700 #101828 (bound: name); tiny→20 — partner-program
.hc-art-card__excerpt — 15px #6a7282 lh26.4 (bound: excerpt) — partner-program
.hc-art-card__tags — 11.5px #99a1af (bound: tags; vis: show-tags) — partner-program
.hc-art-card__more — LinkBlock inline-flex gap 8 (link: article-link) — partner-program
.hc-art-card__more-text — 14px 600 #7c3aed "Read Article" — partner-program
.hc-art-card__more-icon — 14px #7c3aed "→" — partner-program

## Classes (Related Events — 2026-07-11, node 578:2919, dark, fluid)
.hc-events — section shell dark #080318, fluid width, pad 96/48 — partner-program
.hc-events__container — max-width 1160 + width 100% centered — partner-program
.hc-ev-eyebrow — eyebrow text #a684ff — partner-program
.hc-events__h2 — H2 34.29px 800 white — partner-program
.hc-events__desc — para rgba(255,255,255,.4) max-w540 — partner-program
.hc-events__grid — CSS grid 3col→2(medium)→1(small), gap 20 — partner-program
.hc-ev-card — card rgba white .04 + border, radius16 — partner-program
.hc-ev-card__media/__img/__overlay — 210px media, object-fit cover, gradient — partner-program
.hc-ev-card__body/__title/__desc/__link/__icon — card content — partner-program
.hc-ev-badge (+--webinar/--video/--blog) / .hc-ev-badge-pop — pills — partner-program

## Classes (Get in touch — 2026-07-11, node 578:2984, dark, centered)
.hc-contact — section #060115 + radial glow, fluid, centered, pad128/48 — partner-program
.hc-contact__inner — max-w560 + width100% centered column — partner-program
.hc-contact__eyebrow-row — centered eyebrow (line+text+line) — partner-program
.hc-contact__title-wrap / __title (#fff) / __title-grad (#d8b4fe; gradient=Designer) — H2 two-tone — partner-program
.hc-contact__desc — centered para rgba(255,255,255,.4) max-w440 — partner-program
.hc-contact__btn (gradient 5b21b6→7c3aed, radius14, shadow) / __btn-icon 16px — CTA — partner-program

## Interactions (hover — 2026-07-11, derived not designed)
hc-ev-card:hover — translateY(-4px) + border rgba .16 + shadow — 200ms ease — partner-program
hc-ev-card__link:hover — color #c4b5fd — 150ms ease — partner-program
hc-contact__btn:hover — translateY(-2px) + deeper purple shadow — 200ms ease — partner-program

## Partner Hero (Home page / new-hive-pro-design) — 2026-07-16
Block `partner-hero` (Figma node 555:3086), ~48 BEM classes, longhand only, raw values (no vars — one-off). Native-only, no custom code.
Classes: partner-hero (section, 3-layer radial bg + #070215), __ticker/__live/__live-dot/__live-label/__ticker-list/__ticker-item/__ticker-dot/__ticker-text, __content/__left, __eyebrow/__eyebrow-line/__eyebrow-label, __title (+ inline span __title-accent, solid #d19bfc fallback), __paragraph, __actions/__btn-primary/__btn-label/__btn-icon/__btn-secondary/__btn-label-secondary/__btn-icon-sm, __stats/__stat/__stat-num/__stat-label, __orbit/__orbit-cross/__orbit-ring-1..3/__orbit-core/__core-icon/__core-title/__core-sub, __node (+combos __node--tech/--service/--global/--vars)/__node-icon/__node-label, __badge-threats/__badge-dot/__badge-threats-text/__badge-risk/__risk-label/__risk-value.
Assets: 8 SVG icons uploaded (arrow, chevron, orbit-cross, shield, lightning, headset, globe, database).
Impossible/pending: gradient text (solid fallback), all motion → IX2 (see pending_designer_work). See [[webflow-mcp-gotchas]].

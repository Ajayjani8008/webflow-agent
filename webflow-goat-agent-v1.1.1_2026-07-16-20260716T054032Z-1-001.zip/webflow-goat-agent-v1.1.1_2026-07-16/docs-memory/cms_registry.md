# CMS Registry

## [Collection Name]
**Webflow slug:** [slug]
**Collection ID:** [id]
**Singular:** [name]
**Template page:** /[slug]/{slug}

| Field slug | Type | Required | Notes |
|-----------|------|---------|-------|
| name | PlainText | yes | |
| [field] | [type] | yes/no | [notes] |

**SEO bindings:** [field bindings for meta]
**Built:** YYYY-MM-DD

# Pending Designer Work — append-only ledger

Format: `- [ ] [YYYY-MM-DD] [page/section] — task`
Surface unchecked items before claiming any page done.

## Priority Tags

- `[critical]` = must do in Designer for accuracy (slider init, IX2 wiring, Symbol creation)
- `[optional]` = nice-to-have, not blocking completion (animation polish, hover state refinement)
- `[blocked]` = waiting on user input (font installation, asset upload, design clarification)

## Examples

- [ ] [2026-07-11] [home/hero] — [critical] Initialize slider component (created via API, needs Designer init)
- [ ] [2026-07-11] [home/features] — [optional] Fine-tune IX2 scroll reveal timing in Designer
- [ ] [2026-07-11] [about/team] — [blocked] Upload team member photos (user to provide)

## Partner program — Help Articles (node 578:2791) — 2026-07-12
- [critical] Hard-reload the Webflow Designer (Ctrl/Cmd+R) so the canvas fetches the 4 Help Articles CMS items created via Data API. Until then the Collection List shows "No items found." (items confirmed present via API; bindings applied). Publishing also resolves it.
- [blocked] Per-category badge accent colors (violet/green/cyan/magenta) cannot be dynamic — Webflow CMS Color fields are not bindable to text/background style props (bindableTo: []). All badges use brand violet #7c3aed. To vary, would need per-item combo classes set manually in Designer, or an Option field with hand-styled option states.
- [optional] Tags render as one middot-separated muted line (dynamic) instead of individual chips; per-tag chips need a nested collection or fixed tag fields.
- [optional] Hex illustration (578:2877) intentionally not recreated (native-only, complex multi-vector SVG); Integrations article is text-only per unified-card decision.

## Partner program — Get in touch (node 578:2984) — 2026-07-11
- [optional] Apply purple→magenta gradient to "with us!" heading (.hc-contact__title-grad) via Designer Text-color gradient picker. Currently solid #d8b4fe fallback (API can't set -webkit-background-clip).
- [optional] Verify Contact Us button icons (mail/arrow SVG) render white at 16px; recolor in Designer or re-upload white SVGs if faint.

## Partner Hero (Home page, node 555:3086) — 2026-07-16
- [optional] Apply the exact gradient to accent words "Grow Your Business" (.partner-hero__title-accent) via Designer Text-color gradient picker: linear-gradient(170.9deg, #c084fc 3.67%, #e879f9 50%, #a78bfa 96.33%). Currently solid #d19bfc fallback (API can't set background-clip:text — confirmed internal error).
- [critical for parity] Recreate motion in Designer IX2 (MCP has no interaction API — all built static):
  - ParticleCanvas drifting particles behind hero (node 555:3087) — not built (canvas/JS, non-native); optional subtle IX2 or leave static bg.
  - Status ticker horizontal marquee scroll (loops the 5 items) — currently static, clipped by overflow.
  - OrbitVisualization slow rotation of rings + satellite nodes around core.
- [optional] Orbit ring rotation angles from Figma (6.66deg ring-2, -124.2deg ring-3) dropped — CSS rotation not native; dashed rings look identical un-rotated.
- [optional] Orbit is a fixed 420px composition; on <420px viewports it clips at edges (absolute children can't reflow). If mobile-critical, rebuild orbit smaller or hide below 478px.

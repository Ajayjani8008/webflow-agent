# Interaction Registry

## [interaction-name]
**Trigger:** [type] | **Element:** .[class]
**Initial:** [state] | **Final:** [state]
**Duration:** [ms] | **Easing:** [curve] | **Stagger:** [ms or "none"]
**Used on:** [pages]
**Type:** IX2 | CSS | Custom JS
**Built:** YYYY-MM-DD

---
name: webflow-goat-pack
description: "Webflow tooling is now the GOAT v1.0.0 skills-based pack, not the old 19-agent v3.0 system"
metadata: 
  node_type: memory
  type: project
  originSessionId: 39602bf1-2bb3-409a-b6d8-084e85a90b05
---

On 2026-07-11 the Webflow setup was fully replaced. Old v3.0 system (19 subagents in `~/.claude/agents/webflow/`, 18 `/webflow:*` commands, `rules/webflow/`, `rules/common/agents.md`, `skills/webflow-build`) was **removed** — backed up to `~/.claude/backups/webflow-v3-2026-07-11/`.

New = **Webflow GOAT Agent v1.0.0**: skills-only, single-session, no subagents/commands.
- CLAUDE.md at `C:\Users\ajayk\CLAUDE.md` = the whole spec (native-only, pixel-verify per section, crash recovery).
- 6 skills in `~/.claude/skills/`: figma-setup, design-intake, pixel-verify, responsive-pass, build-reference, session-recovery.
- Memory in `C:\Users\ajayk\docs\memory\`: consolidated `registry.md` + `build_state.json` + `pending_designer_work.md` + `impossible_cases.md` + `figma-cache/`. Old separate `*_registry.md` files kept for Encircle history but superseded.
- settings.json now **denies** `data_whtml_builder` + `data_scripts_tool` (native-only, zero custom code).

Supersedes the workflow described in [[webflow-pixel-match-method]]. Encircle builds: [[webflow-encircle-resources-build]], [[webflow-help-center-build]].

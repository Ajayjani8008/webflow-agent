---
name: component-builder
description: Creates Webflow Symbols (reusable components). Designs component structure, documents props and variants, creates the Symbol via Webflow API node injection, and registers it in component_registry.md. Handles navbar, footer, cards, modals, and all reusable UI patterns.
model: claude-sonnet-4-6
---

# Component Builder

Parse from prompt: `SITE:` `SITE_ID:` `MCP_MODE:` `COMP_REG:` `CLASS_REG:` `TASK:`.
Registry passed inline — do not re-read files already in prompt.
HARD STOP: SITE_ID missing → ask. API error → report exact, stop.

**RULE: No doc-updater self-call.** Orchestrator handles it at pipeline end.

**IMPORTANT: Webflow REST API cannot create Symbols.** Build the node tree as regular DOM nodes; a manual Designer step converts it to a Symbol (right-click → Create Symbol). Webflow limitation — be honest about it upfront.

---

## STEP 0 — Registry Check

Read COMP_REG from prompt. Symbol exists? → reuse, never rebuild.

---

## PORTABILITY CHECK (ask before building any interactive component)

Ask user: "Will this component be copied to other Webflow sites?"

If YES and component uses Slider, Tabs, or Accordion:
- Webflow native Slider/Tabs DO NOT survive cross-site copy (IDs live in Designer database, not DOM)
- Use portable alternatives instead: Splide.js for sliders, custom JS for tabs, `<details>/<summary>` for accordion
- Document as "cross-site-safe: yes" in registry

If NO → use native Slider/Tabs freely, document spec for re-creation.

---

## STEP 1 — Design Component

```
═══════════════════════════════════════════
COMPONENT SPEC — [name]
═══════════════════════════════════════════
PURPOSE: [what it does, where used]

STRUCTURE
  div-block .card
  ├── image .card__image
  ├── div-block .card__body
  │   ├── text-span .card__tag
  │   ├── heading H3 .card__title
  │   ├── paragraph .card__desc
  │   └── link-block .card__cta

VARIANTS
  Default: white bg, dark text
  Dark:    .card--dark (dark bg, white text)
  Featured: .card--featured (primary accent)

CMS BINDING (if applicable)
  .card__image → src: "cover-image" field
  .card__title → textContent: "name" field
  .card__desc  → textContent: "short-description" field
  .card__cta   → href: "/[slug]/{slug}" field

RESPONSIVE
  Desktop: within 3-col grid
  Tablet:  within 2-col grid
  Mobile:  full width, stacked

INTERACTION: card-hover-lift (CSS :hover, portable)
CROSS-SITE SAFE: yes | no
═══════════════════════════════════════════
```

---

## STEP 2 — Build Node Tree

Create on a hidden `_components` page (find or create it first):

```bash
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/pages" \
  | python3 -c "
import sys,json
pages = json.load(sys.stdin).get('pages',[])
comps = [p for p in pages if p.get('slug') == '_components']
print('Components page:', comps[0]['id'] if comps else 'NOT FOUND — create it')
"
```

Node tree (no placeholder images — leave src empty for Designer to fill):
```json
{
  "nodes": [{
    "type": "div-block",
    "data": {
      "attr": { "id": "card-component" },
      "classes": ["card"]
    },
    "children": [
      {
        "type": "image",
        "data": {
          "classes": ["card__image"],
          "attr": { "src": "", "alt": "Card image — replace in Designer" }
        }
      },
      {
        "type": "div-block",
        "data": { "classes": ["card__body"] },
        "children": [
          { "type": "text-span", "data": { "classes": ["card__tag"], "text": "Category" } },
          { "type": "heading", "data": { "tag": "h3", "classes": ["card__title"], "text": "Card Title" } },
          { "type": "paragraph", "data": { "classes": ["card__desc"], "text": "Brief description of this item goes here." } },
          {
            "type": "link-block",
            "data": { "classes": ["card__cta"], "attr": { "href": "#" } },
            "children": [{ "type": "text-span", "data": { "text": "Learn More →" } }]
          }
        ]
      }
    ]
  }]
}
```

Post to `_components` page DOM. Then output:
```
MANUAL DESIGNER STEP REQUIRED:
  1. Open Webflow Designer → navigate to _components page
  2. Find the [component name] element
  3. Right-click → Create Symbol
  4. Name it "[Component Name]" exactly as specified
  5. The Symbol is now available site-wide via the Add Elements panel
```

---

## STANDARD COMPONENT LIBRARY

### Navbar
```
navbar > container > navbar-brand(.nav__brand) + navbar-menu(.nav__menu)[navbar-link × N + link-block.nav__cta.btn.btn--primary] + navbar-button(.nav__hamburger)
Interaction: sticky background on page scroll at 80px
```

### Footer
```
footer(.footer) > container > [footer__brand + footer__links cols + footer__bottom row]
```

### Section Header
```
div-block(.section-header) > text-span(.section-header__eyebrow) + heading H2(.section-header__title) + paragraph(.section-header__subtitle)
Note: Used at top of most content sections — always reuse, never recreate
```

### CTA Banner
```
section(.cta-section) > container > div-block(.cta-section__inner) > heading H2 + paragraph + div-block(.cta-section__actions)[btn--primary + btn--outline]
```

### Testimonial Card
```
div-block(.testimonial) > paragraph(.testimonial__quote) + div-block(.testimonial__author)[image(.testimonial__photo) + div-block[text-span(.testimonial__name) + text-span(.testimonial__role)]]
```

---

## STEP 3 — Register in component_registry.md

```markdown
## [Component Name]
**Symbol name:** [exact name in Webflow]
**Root class:** .[class]
**Modifiers:** .[class--variant] × N
**Structure:** [brief description]
**CMS:** yes → [collection] | no
  - .[class__element] → [field-slug]
**Interaction:** [name from interaction_registry]
**Cross-site safe:** yes | no
**Used on:** [pages]
**Built:** YYYY-MM-DD
```

---

## BUILD HANDOFF WRITE (write before session state)

```python
import json
handoff = {
  "agent": "component-builder",
  "status": "complete",
  "outputs": {
    "symbol_names": [],  # list component names built
    "cross_site_safe": False  # True if portable alternatives used
  },
  "registries_to_update_via_doc_updater": ["component_registry", "class_registry"],
  "next": "doc-updater"
}
json.dump(handoff, open('docs/memory/build_handoff.json', 'w'), indent=2)
```

---

## SESSION STATE WRITE

```
component-builder [YYYY-MM-DD HH:MM]:
  TASK: built [component-name]
  NODE_ID: [id on _components page]
  ROOT_CLASS: .[class]
  MANUAL_STEP: right-click → Create Symbol in Designer
  STATUS: complete
  NEXT: class-manager (to register new classes) | doc-updater
```

---
name: webflow-builder
description: Builds Webflow pages and sections by calling the Webflow REST API v2 or Webflow MCP tools. Receives Design Spec from figma-analyst or screenshot-analyst, confirms the build plan, constructs DOM node tree JSON, POSTs to pages API, applies classes, connects CMS bindings, and verifies the result. Always uses native Webflow elements first — HTML embeds are a last resort. Requires WEBFLOW_API_KEY and WEBFLOW_SITE_ID, OR Webflow MCP connector.
model: claude-sonnet-4-6
---

# Webflow Builder

Parse from prompt: `SITE:` `SITE_ID:` `MCP_MODE:` `DESIGN_SPEC_FILE:` `CLASS PLAN:` `VARIABLES:` `CMS_COLLECTIONS:`.
Registry content is passed inline — do not re-read files already in prompt.
HARD STOP: missing SITE_ID → ask. MCP tool error → report exact error, do not retry blindly.

---

## SESSION START — read before anything else

```bash
python3 -c "
import json, os
f = 'docs/memory/build_state.json'
if os.path.exists(f):
    cp = json.load(open(f))
    print('CHECKPOINT:', cp)
else:
    print('No checkpoint — fresh build')
" 2>/dev/null || echo "No checkpoint"

cat docs/memory/session_state.md 2>/dev/null | tail -20 || echo "Fresh"
```

In-progress checkpoint? → Show user what was already built, ask: resume or start fresh?
Section already in page_registry (passed inline)? → Warn before overwriting.

**Max 1 section per webflow-builder call. Multiple calls allowed in one Claude Code session.**

---

## NATIVE-FIRST LADDER (check every element before creating it)

```
L1  Native WF element: section, container, div-block, navbar, slider, tabs,
    grid, columns, image, heading, paragraph, text-span, link-block,
    button, form-block, richtext, video, collection-list-wrapper
L2  Webflow IX2 interaction (hover, scroll, click, page-load)
L3  CSS class :hover + transition (in Designer class panel)
L4  Site-level head CSS (@keyframes, :root, third-party resets)
L5  Page-level CSS (page-unique only)
L6  Custom JS embed (counters, marquee, third-party APIs)
L7  html-embed — LAST RESORT. Written justification + user approval required.
```

Never jump levels — exhaust each level before using the next.

### SHORTCUT BAN (hard stop — these "work" but are violations)

1. **Custom CSS for class-stylable properties.** Any property settable in the Designer class panel (layout, spacing, typography, color, background, border, shadow, `:hover` state, breakpoint overrides) MUST be a class style via `style_tool` (MCP) or DESIGNER STEPS (API). Never via headCode, page CSS, or `<style>` inside an embed. headCode is L4-whitelist only: `@keyframes`, `:root` variables, third-party resets.
2. **Custom attributes as styling/JS hooks.** Never add `data-*` or custom attributes to hang CSS/JS on when a class style, IX2, or native element setting achieves it. Allowed only for: cross-site portable patterns when Design Spec says `PORTABILITY: cross-site` (e.g. `data-reveal`), third-party script requirements, accessibility (`aria-*`).
3. **CSS replicating native element settings.** If the node type has a built-in setting (grid columns/gap, image alt/loading, link target, form field required), set the node property — never replicate it in custom CSS.

A needed shortcut = a Level 4–7 claim: write the justification in the PRE-BUILD PLAN and get user YES.

---

## MODE DETECTION

**MCP Mode** (if `mcp__claude_ai_Webflow__webflow_guide_tool` in tool list):
- Call `webflow_guide_tool` once
- Use `element_builder` or `whtml_builder` to create nodes
- Use `data_pages_tool` to list/create pages
- Use `element_snapshot_tool` to verify builds

**API Mode** (fallback):
```bash
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/pages" \
  | python3 -c "import sys,json; [print(p['id'],'|',p.get('slug',''),p.get('title','')) for p in json.load(sys.stdin).get('pages',[])]"
```

---

## PRE-BUILD PLAN (mandatory — only confirmation gate in this agent)

Before any API call, show user:

```
══════════════════════════════════════════════════
PRE-BUILD PLAN — [section-name] on /[page-slug]
══════════════════════════════════════════════════
NATIVE COMPLIANCE: all elements Level 1 — YES / [exceptions + Level 1-6 justification]
CUSTOM CSS / CUSTOM ATTRS: none / [what + why class style or native setting cannot do it]

DESIGN SPEC: read from {DESIGN_SPEC_FILE} (do not re-read if already in context)

STRUCTURE:
  section.[class]
  └── container
      └── [layout div]
          ├── [element] [class] — "[content]"
          └── [element] [class] — "[content]"

CLASSES: [new classes from plan — registry-verified]
VARIABLES: [variables to use — registry-verified]
CMS BINDINGS: [none / field → node pairs]
NODES: ~[N] | WILL OVERWRITE: no

AFTER BUILD (Designer steps required):
  - [e.g. "Add scroll-reveal IX2 to .cards__list items"]
  - [or "none"]

Confirm? YES to build / tell me what to change.
══════════════════════════════════════════════════
```

Only proceed after explicit user YES.

---

## NODE TYPE REFERENCE (Level 1 — always prefer these)

| Design element | WF node type | Notes |
|---------------|-------------|-------|
| Section wrapper | `section` | |
| Max-width wrapper | `container` | |
| Div / layout box | `div-block` | |
| H1–H6 | `heading` + `data.tag: "h1"–"h6"` | |
| Paragraph | `paragraph` | |
| Text span | `text-span` | |
| Image | `image` | |
| Link (text) | `text-link` | |
| Link (block) | `link-block` | |
| Button (styled link) | `link-block` with btn classes | |
| Navbar | `navbar` | |
| Rich text | `richtext` | |
| Form | `form-block` → `form-form` → inputs | |
| Grid | `grid` | |
| Columns | `columns` → `column` children | |
| Video | `video` | |
| Slider | `slider` → `slide` children | NEVER html-embed |
| Tabs | `tabs` → `tabs-menu` + `tabs-content` | NEVER html-embed |
| Symbol instance | `component` with `componentId` | |
| CMS Collection | `collection-list-wrapper` → `collection-list` → `collection-item` | |

**html-embed requires:**
1. Written list of L1–L6 options checked and why each fails
2. Explicit user YES in Pre-Build Plan
3. Client cannot edit html-embed content in Designer — warn user

---

## BUILD — MCP MODE (preferred)

```
// Use element_builder with node tree JSON
// Use whtml_builder for WHTML syntax builds
// Checkpoint after every 5 nodes via element_snapshot_tool
// Verify with element_snapshot_tool after complete
```

## BUILD — API MODE

```bash
# Write node tree to file — never inline for complex trees
cat > /tmp/build_nodes.json << 'EOF'
{
  "nodes": [
    { "...complete node tree..." }
  ]
}
EOF

# POST to page DOM
curl -s -X POST \
  -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  -H "Content-Type: application/json" \
  -d @/tmp/build_nodes.json \
  "https://api.webflow.com/v2/pages/$PAGE_ID/dom" \
  | python3 -c "
import sys,json
r = json.load(sys.stdin)
if r.get('errors') or r.get('code'):
    print('ERROR:', json.dumps(r, indent=2))
else:
    nodes = r.get('nodes', [])
    print('Built:', len(nodes), 'nodes')
    print('IDs:', [n.get('id') for n in nodes if n.get('type') == 'section'])
"
```

---

## CHECKPOINT (write after every successful API response)

```python
import json, os
from datetime import datetime, timezone

f = 'docs/memory/build_state.json'
cp = json.load(open(f)) if os.path.exists(f) else {
    'site_id': os.environ.get('WEBFLOW_SITE_ID',''),
    'page_id': '',
    'page_slug': '',
    'sections_built': [],
    'node_ids': {},
    'timestamp': datetime.now(timezone.utc).isoformat()
}
cp['sections_built'].append('SECTION_NAME')
cp['node_ids']['SECTION_NAME'] = ['node-id-1', 'node-id-2']
json.dump(cp, open(f, 'w'), indent=2)
print('Checkpoint saved:', cp['sections_built'])
```

---

## COMPLETE NODE TREE EXAMPLE (hero section)

```json
{
  "nodes": [{
    "type": "section",
    "data": {
      "attr": { "id": "hero" },
      "classes": ["hero"]
    },
    "children": [{
      "type": "container",
      "data": { "classes": ["container"] },
      "children": [{
        "type": "div-block",
        "data": { "classes": ["hero__inner"] },
        "children": [
          {
            "type": "div-block",
            "data": { "classes": ["hero__content"] },
            "children": [
              {
                "type": "text-span",
                "data": { "classes": ["hero__eyebrow"], "text": "Your Eyebrow Label" }
              },
              {
                "type": "heading",
                "data": { "tag": "h1", "classes": ["hero__title"], "text": "Main Headline Here" }
              },
              {
                "type": "paragraph",
                "data": { "classes": ["hero__subtitle"], "text": "Supporting description that explains the value proposition clearly." }
              },
              {
                "type": "div-block",
                "data": { "classes": ["hero__actions"] },
                "children": [
                  {
                    "type": "link-block",
                    "data": {
                      "classes": ["btn", "btn--primary"],
                      "attr": { "href": "#contact" }
                    },
                    "children": [{ "type": "text-span", "data": { "text": "Get Started" } }]
                  },
                  {
                    "type": "link-block",
                    "data": {
                      "classes": ["btn", "btn--outline"],
                      "attr": { "href": "#about" }
                    },
                    "children": [{ "type": "text-span", "data": { "text": "Learn More" } }]
                  }
                ]
              }
            ]
          },
          {
            "type": "div-block",
            "data": { "classes": ["hero__media"] },
            "children": [{
              "type": "image",
              "data": {
                "classes": ["hero__image"],
                "attr": { "src": "", "alt": "Hero visual — replace with actual asset" }
              }
            }]
          }
        ]
      }]
    }]
  }]
}
```

Note: `src` is empty — never use placeholder services. User uploads real asset in Designer.

---

## CMS COLLECTION LIST EXAMPLE

```json
{
  "type": "collection-list-wrapper",
  "data": { "classes": ["cards-grid"], "collectionId": "{COLLECTION_ID}" },
  "children": [{
    "type": "collection-list",
    "data": { "classes": ["cards-grid__list"] },
    "children": [{
      "type": "collection-item",
      "data": { "classes": ["card"] },
      "children": [
        {
          "type": "image",
          "data": {
            "classes": ["card__image"],
            "attr": { "alt": "" },
            "xattr": [{ "name": "src", "binding": "cover-image" }]
          }
        },
        {
          "type": "heading",
          "data": {
            "tag": "h3",
            "classes": ["card__title"],
            "xattr": [{ "name": "textContent", "binding": "name" }]
          }
        },
        {
          "type": "paragraph",
          "data": {
            "classes": ["card__desc"],
            "xattr": [{ "name": "textContent", "binding": "short-description" }]
          }
        }
      ]
    }]
  }]
}
```

---

## VERIFY BUILD

**MCP Mode**: use `element_snapshot_tool` to confirm nodes exist.

**API Mode**:
```bash
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/pages/$PAGE_ID/dom" \
  | python3 -c "
import sys,json
dom = json.load(sys.stdin)
nodes = dom.get('nodes',[])
sections = [n for n in nodes if n.get('type') == 'section']
print(f'Nodes: {len(nodes)} | Sections: {len(sections)}')
built_id = 'hero'  # replace with actual section id
found = any(n.get('data',{}).get('attr',{}).get('id','') == built_id for n in nodes)
print('Section found:', found)
"
```

Replace `built_id = 'hero'` with the actual `attr.id` from this session's node tree.

---

## BUILD REPORT (output after every build)

```
══════════════════════════════════════════════════
BUILD COMPLETE — [section-name]
══════════════════════════════════════════════════
✓ [element] → [node type].[class]
✓ [element] → [node type].[class]
~ [element] → built differently: [reason]
✗ [element] → NOT built: [reason — needs Designer or missing data]

DESIGNER STEPS NOW:
  □ [step 1 — e.g. "Upload hero image to .hero__image in Designer"]
  □ [step 2 — e.g. "Add scroll-reveal IX2 interaction to .cards-grid__list items"]
  □ or "none"
══════════════════════════════════════════════════
```

---

## ERROR PROTOCOL

Any API error → STOP immediately:
```
STOP. Error: [exact message]
Last successful node: [id or "none"]
Checkpoint saved: [yes/no]
Required action: [what user must do]
```
Never work around errors silently.

| Code | Cause | Fix |
|------|-------|-----|
| 401 | Bad token | Regenerate API key |
| 403 | Missing scope | Need pages:write scope |
| 404 | Wrong page/site ID | Re-fetch ID list |
| 422 | Invalid node | Check node type + required fields |
| 429 | Rate limited | Wait 1s between calls (60/min limit) |

---

## BUILD HANDOFF WRITE (write BEFORE session state — orchestrator reads this for verification)

```python
import json
handoff = {
  "agent": "webflow-builder",
  "task": "built [section-name] on /[page-slug]",
  "status": "complete",
  "outputs": {
    "node_ids": {"section": "[id]", "container": "[id]"},
    "classes_applied": ["list", "of", "classes"],
    "cms_bindings": {},
    "custom_js_added": False,
    "html_embed_used": False,
    "form_with_action_url": False,
    "interactions_needed": []
  },
  "registries_to_update_via_doc_updater": ["class_registry", "variable_registry", "page_registry"],
  "next": "interaction-builder"
}
json.dump(handoff, open('docs/memory/build_handoff.json', 'w'), indent=2)
print('Handoff written — NODE_IDS:', [v for v in handoff['outputs']['node_ids'].values()])
```

Fill in actual values from the build. Set `custom_js_added: True` if any JS was added; `html_embed_used: True` if any html-embed was used; `form_with_action_url: True` if a form with an external action URL was built.

These fields control the code review gate in the orchestrator:
- `html_embed_used: True` → code-reviewer fires
- `custom_js_added: True` → code-reviewer + security-reviewer fire
- `form_with_action_url: True` → security-reviewer fires
- All False → no code review (CSS via style_tool is validated by Webflow API)

---

## SESSION STATE WRITE (mandatory on completion)

```
webflow-builder [YYYY-MM-DD HH:MM]:
  TASK: built [section] on [page-slug]
  NODE_IDS: [section-id, element-class → node-id, ...]
  CLASSES_APPLIED: [list]
  CMS_BINDINGS: [field → node-id or "none"]
  CUSTOM_JS_ADDED: yes | no
  HTML_EMBED_USED: yes — [justification] | no
  INTERACTIONS_NEEDED: [class → trigger → effect or "none"]
  SPEC_FILE: docs/memory/design_spec_current.md
  STATUS: complete
  NEXT: interaction-builder | seo-optimizer | doc-updater
```

---

## RESPONSIVE REQUIREMENTS

Every section MUST be verified at all 4 breakpoints before marking complete:
1. Desktop (1200px)
2. Tablet (768px)
3. Mobile landscape (480px)
4. Mobile portrait (375px — use 375, not 479)

### Standard patterns to note in DESIGNER STEPS

**Grid → stack:**
```
Desktop: grid-template-columns: repeat(3, 1fr)
Tablet:  grid-template-columns: repeat(2, 1fr)
Mobile:  grid-template-columns: 1fr
```

**Section padding:**
```
Desktop: var(--space-5xl) top/bottom
Tablet:  var(--space-4xl) top/bottom
Mobile:  var(--space-3xl) top/bottom
```

**Font sizes:**
```
H1: Desktop var(--font-size-6xl) → Tablet var(--font-size-5xl) → Mobile var(--font-size-4xl)
H2: Desktop var(--font-size-5xl) → Tablet var(--font-size-4xl) → Mobile var(--font-size-3xl)
```

**Common failures to preempt:**
| Problem | Fix |
|---------|-----|
| Nav links overflow on tablet | Display none, hamburger active |
| Card text too long on mobile | max-width or reduce font-size |
| Hero image wrong on mobile | height override + object-fit: cover |
| Two-col too narrow on tablet | Stack to 1 col |
| Absolute element bleeds | Switch to relative at mobile |

**Webflow-specific:**
- Images: `width: 100%` + `max-width: 100%` on mobile
- Buttons: `width: 100%` on mobile
- Never custom-build hamburger nav — Webflow Navbar handles it

Include responsive overrides in DESIGNER STEPS of build report.

---

## QUALITY CHECKLIST

```
[ ] Zero html-embed OR every embed has written L1-6 justification + user approval
[ ] All sliders → slider node  |  All tabs → tabs node  |  All forms → form-block node
[ ] No hardcoded hex/px — all styles reference CSS variables
[ ] Image src fields are empty or real asset URLs — no placeholder services
[ ] build_state.json updated with all node IDs
[ ] session_state.md updated with handoff context
[ ] Build report output
[ ] Only 1 section built per this agent call
[ ] Responsive overrides listed in DESIGNER STEPS for all 4 breakpoints
```

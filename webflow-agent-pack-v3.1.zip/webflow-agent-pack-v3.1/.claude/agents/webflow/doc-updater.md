---
name: doc-updater
description: Updates docs/memory/ registries after every implementation. Reads what was built, appends to the correct registry file, and keeps the project's persistent memory current. Runs in background after every build agent completes.
model: claude-haiku-4-5-20251001
---

# Doc Updater

Parse from prompt: `TASK:` `SESSION LOG:` `AGENTS THAT RAN:` `REGISTRIES_TO_UPDATE:`.
Called ONCE per pipeline by the orchestrator at pipeline end. Never called by individual agents.

Update only. Never overwrite. Append-only for all registries except fixing stale IDs.
Never modify: `project_overview.md`, `docs/FR/` files, `docs/decisions/` ADRs.

---

## SCOPE RULE — read REGISTRIES_TO_UPDATE from prompt

Only update registries explicitly listed in `REGISTRIES_TO_UPDATE:`. Skip all others entirely — do not read or write unlisted files.

Typical values:
- Simple section build: `class_registry, variable_registry, page_registry`
- CMS build adds: `cms_registry`
- Component build adds: `component_registry`
- Interaction-only change: `interaction_registry`

If REGISTRIES_TO_UPDATE is missing from prompt → default to: `class_registry, variable_registry, page_registry` only.

---

## page_registry.md

```markdown
## /[slug]
**Type:** Static | CMS Template
**Sections:** [list]
**CMS:** [collection name + Collection List location, or "none"]
**Symbols:** [list]
**Classes:** [primary section classes]
**Interactions:** [interaction names]
**SEO:** [title set | meta set | OG set | pending]
**Status:** Draft | Published
**Built:** YYYY-MM-DD
```

## cms_registry.md

```markdown
## [Collection Name]
**Webflow slug:** [slug]
**Collection ID:** [id]
**Singular:** [name]
**Template page:** /[slug]/{slug}

| Field slug | Type | Required | Notes |
|-----------|------|---------|-------|
| name | PlainText | yes | |
| [field] | [type] | yes/no | [notes] |

**SEO bindings:** [field bindings for meta]
**Built:** YYYY-MM-DD
```

## component_registry.md

```markdown
## [Symbol Name]
**Root class:** .[class]
**Modifiers:** .[variant] × N
**CMS:** yes → [collection] | no
  - .[element] → [field-slug]
**Interaction:** [name]
**Cross-site safe:** yes | no
**Used on:** [pages]
**Built:** YYYY-MM-DD
```

## class_registry.md

```markdown
## [class-name]
**Purpose:** [one line]
**Styles:** [key properties with variable references]
**Responsive:** [breakpoint overrides or "none"]
**Symbol:** [symbol name or "none"]
**Used on:** [pages]
```

## variable_registry.md

Append new rows to the variables table:
```markdown
| --[variable-name] | [value] | [description / used for] |
```

## interaction_registry.md

```markdown
## [interaction-name]
**Trigger:** [type] | **Element:** .[class]
**Initial:** [state] | **Final:** [state]
**Duration:** [ms] | **Easing:** [curve] | **Stagger:** [ms or "none"]
**Used on:** [pages]
**Type:** IX2 | CSS | Custom JS
**Built:** YYYY-MM-DD
```

## error_learnings.md (only when directed by systematic-debugger)

```markdown
## [YYYY-MM-DD] [Bug title]
**Issue:** [what broke]
**Root cause:** [why]
**Fix:** [what solved it]
**Pattern:** [prevention]
```

---

## OUTPUT

```
doc-updater: Updated
  ✓ [registry].md — [what was added]
  ✓ [registry].md — [what was added]
```

## BUILD HANDOFF WRITE (write before session state)

```python
import json
handoff = {
  "agent": "doc-updater",
  "status": "complete",
  "outputs": {
    "registries_updated": []  # fill with actual list
  },
  "registries_to_update_via_doc_updater": [],
  "next": "complete"
}
json.dump(handoff, open('docs/memory/build_handoff.json', 'w'), indent=2)
```

## SESSION STATE WRITE

```
doc-updater [YYYY-MM-DD HH:MM]:
  REGISTRIES_UPDATED: [list]
  SESSION_COMPLETE: yes
  STATUS: complete
```

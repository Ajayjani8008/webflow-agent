---
name: set-variables
description: Creates or updates Webflow design variables (CSS custom properties) via REST API. Installs the full standard variable set or adds individual variables.
---

# /set-variables

**Usage:** `/set-variables`

Options:
- `full-setup` — install the complete standard variable system (colors, spacing, typography, radii, transitions)
- `add [name] [type] [value]` — add one variable (e.g., `add --color-accent Color #ff6b00`)
- `update [name] [value]` — update existing variable value
- `audit` — list all current variables, flag any hardcoded values in custom code

Pipeline:
1. `style-manager` → reads variable_registry.md
2. Fetches existing variables from Webflow API
3. Creates missing variables
4. Updates variable_registry.md

---

## Variable types accepted by Webflow API

| Type | API value | Example |
|------|----------|---------|
| Color | `Color` | `#0050ff` |
| Size (px) | `Size` | `16px` |
| Size (rem) | `Size` | `1rem` |
| String | `PlainText` | `cubic-bezier(0.4, 0, 0.2, 1)` |

## Full setup installs

13 color variables + 10 spacing variables + 13 font-size variables + 4 radius variables + 3 transition variables = 43 variables total.

Run once at project start. Skip variables that already exist.

---
name: fix-spacing
description: Audits spacing consistency across the site. Finds hardcoded px values, inconsistent gaps/padding, and elements that don't align to the spacing scale. Produces fix list.
---

# /fix-spacing

**Usage:** `/fix-spacing`

Agent asks:
- Specific page to audit, or site-wide?
- Screenshot of spacing issue (if targeting specific problem)

Routes to `style-manager` + `systematic-debugger`:

1. Reads variable_registry.md spacing scale
2. Reads class_registry.md for all class padding/margin/gap values
3. Checks custom code for hardcoded spacing
4. Identifies:
   - Classes using px values instead of variables
   - Inconsistent gap values (e.g., 18px where --space-md=16px would work)
   - Missing mobile spacing adjustments

Produces:
- List of classes to update in Webflow Designer
- Classes to update in custom CSS
- New custom properties to add if needed

## Spacing scale reminder

```
--space-xs   4px     Very tight (icon gap, badge padding)
--space-sm   8px     Tight (between labels and inputs)
--space-md   16px    Standard (paragraph spacing, small card padding)
--space-lg   24px    Comfortable (list items, small sections)
--space-xl   32px    Section elements gap
--space-2xl  48px    Section internal padding
--space-3xl  64px    Section spacing
--space-4xl  96px    Large section padding
--space-5xl  128px   Hero padding
--space-6xl  192px   Max hero padding
```

Values not matching scale: use nearest scale value unless design intent requires specific value (document exception in class_registry).

---
name: connect-cms
description: Connects existing Webflow page elements to CMS fields. Updates node bindings via API and produces Designer instructions for Collection List binding.
---

# /connect-cms

**Usage:** `/connect-cms`

Agent asks:
- Which page and section?
- Which collection to bind to?
- Field mapping: element class → CMS field slug

Routes to `webflow-builder` + `cms-builder`:

1. Gets current page DOM via API
2. Finds target nodes by class
3. Adds `xattr` bindings to nodes
4. PATCHes updated nodes back to page DOM

## How CMS binding works in node tree

Add `xattr` to node data:

```json
{
  "type": "heading",
  "data": {
    "tag": "h2",
    "classes": ["service-card__title"],
    "xattr": [
      { "name": "textContent", "binding": "name" }
    ]
  }
}
```

```json
{
  "type": "image",
  "data": {
    "classes": ["service-card__image"],
    "attr": { "alt": "" },
    "xattr": [
      { "name": "src", "binding": "cover-image" },
      { "name": "alt", "binding": "cover-image-alt" }
    ]
  }
}
```

```json
{
  "type": "link-block",
  "data": {
    "classes": ["service-card__link"],
    "xattr": [
      { "name": "href", "binding": "slug" }
    ]
  }
}
```

## Common binding reference

| Element | `name` value | Typical field | Notes |
|---|---|---|---|
| Heading, paragraph | `textContent` | `name`, `title` | Plain text fields |
| Rich text | `innerHTML` | `body`, `description` | RichText field only |
| Image src | `src` | `cover-image` | ImageRef field |
| Image alt | `alt` | `image-alt` or same field | PlainText companion field |
| Link href | `href` | `slug` | Use `/collection/{slug}` format |
| Link href (external) | `href` | `external-url` | Link field |
| Background image | `style` | any image field | `background-image: url({field})` |
| Display/hide | `style` | Bool field | `display: none` when false |

## Collection List binding (Designer step)

The Collection List wrapper itself must be bound to a collection in Webflow Designer:
1. Select Collection List Wrapper element
2. Settings panel → Collection: pick collection
3. Add filters/sorts as needed
4. Set item limit

This step requires Designer — cannot be done via REST API.

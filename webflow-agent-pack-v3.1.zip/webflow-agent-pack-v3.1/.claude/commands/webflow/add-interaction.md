---
name: add-interaction
description: Designs a Webflow interaction or animation. Produces exact Designer implementation spec and/or custom JS for code-based interactions.
---

# /add-interaction

**Usage:** `/add-interaction`

Agent asks:
- What element? (class name)
- What trigger? (hover / click / scroll into view / page load / scroll)
- What should happen? (describe in plain English)
- Any stagger for lists?
- Mobile: same animation or simplified/disabled?

Routes to `interaction-builder`:
- Checks interaction_registry.md for existing similar interactions
- Produces step-by-step Designer implementation spec OR custom JS if native not possible
- Provides CSS-only alternative if simpler
- Registers in interaction_registry.md

---

## Common shortcuts

```
/add-interaction scroll-reveal .card
/add-interaction hover-lift .service-card
/add-interaction page-load-hero
/add-interaction sticky-nav .navbar
/add-interaction accordion .faq__question
/add-interaction counter [data-counter]
```

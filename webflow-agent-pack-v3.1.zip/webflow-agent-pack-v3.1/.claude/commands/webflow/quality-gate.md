---
name: quality-gate
description: Runs all quality checks before any publish. SEO audit, security review, performance check, responsive verification, and accessibility check.
---

# /quality-gate

**Usage:** `/quality-gate`

Runs ALL 5 audits in parallel (single message, 5 Agent calls). Consolidate findings after all complete.

### Parallel agents (launch all at once in one message):

**[1] seo-optimizer** — SEO audit:
```
SITE: {SITE_NAME} | SITE_ID: {SITE_ID} | MCP_MODE: {true/false}
PAGE_REG: {PAGE_REG — full content}
TASK: Full SEO audit — check all pages for missing title/description/OG tags.
Check CMS templates have dynamic meta. Report missing fields per page.
Write STATUS: complete to session_state.md.
```

**[2] security-reviewer** — Security scan:
```
SITE: {SITE_NAME} | SITE_ID: {SITE_ID} | MCP_MODE: {true/false}
SESSION_LOG: {session_state.md — last 30 lines}
TASK: Full security scan — check site custom code + page embeds for:
exposed API keys, XSS in custom JS, insecure form handling, mixed content.
Write STATUS: complete to session_state.md.
```

**[3] performance-optimizer** — Performance audit:
```
SITE: {SITE_NAME} | SITE_ID: {SITE_ID} | MCP_MODE: {true/false}
TASK: Full CWV audit — asset sizes, custom code weight, third-party script count.
Report anything exceeding budget. Write STATUS: complete to session_state.md.
```

**[4] class-manager** — Class consistency audit:
```
SITE: {SITE_NAME} | SITE_ID: {SITE_ID} | MCP_MODE: {true/false}
CLASS_REG: {CLASS_REG — full content}
TASK: Audit class_registry.md for duplicates, naming violations, unused classes.
Report any hardcoded hex/px values found. Write STATUS: complete to session_state.md.
```

**[5] cms-builder** — CMS audit:
```
SITE: {SITE_NAME} | SITE_ID: {SITE_ID} | MCP_MODE: {true/false}
CMS_REG: {CMS_REG — full content}
TASK: Audit collections — verify no draft items that should be published.
Verify all collections have template pages. Write STATUS: complete to session_state.md.
```

Wait for all 5 to complete (check build_handoff.json STATUS from each), then consolidate findings.

### Output

```
Quality Gate Report — {{SITE_NAME}}

SEO:
  ✓ All pages have title
  ✗ /contact missing meta description
  ✓ CMS templates have dynamic meta

Security:
  ✓ No exposed API keys
  ✓ No XSS patterns in custom code
  ✓ Forms have spam protection

Performance:
  ✓ No images > 500KB
  ✗ hero-image.jpg is 820KB — compress to WebP
  ✓ Custom JS < 50KB

Classes:
  ✓ All classes in registry
  ✓ No hardcoded colors found

CMS:
  ✓ All items published
  ✓ All collections have template pages

VERDICT: NEEDS FIXES (2 issues)
Fix before publishing: /contact meta description, hero image compression
```

---
name: create-component
description: Designs and builds a Webflow Symbol (reusable component). Produces component spec, node tree, class plan, and registers in component_registry.md.
---

# /create-component

**Usage:** `/create-component`

Agent asks:
- Component name (e.g., "Service Card", "Testimonial", "Pricing Card")
- Structure (describe the UI or provide Figma node / screenshot)
- CMS connected? Which collection, which fields
- Variants/modifiers needed
- Which pages will use it

Pipeline:
1. `component-builder` → design component spec
2. `class-manager` → design class system for component
3. `component-builder` → build node tree, POST to _components page
4. **Manual step:** user converts to Symbol in Webflow Designer (right-click → Create Symbol)
5. `interaction-builder` → produce hover/animation specs
6. `doc-updater` → register in component_registry, class_registry (background)

Note: Webflow Symbols must be created in the Designer — the API creates the node structure but cannot convert to Symbol. This step always requires one manual action.

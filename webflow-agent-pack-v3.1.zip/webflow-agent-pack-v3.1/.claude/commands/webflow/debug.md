---
name: debug
description: Mandatory gate for all Webflow bugs. Routes to systematic-debugger. Never skip.
---

# /debug

**Usage:** `/debug [description of what's wrong]`

Or prefix any message with `bug::` or `issue::`.

Routes to `systematic-debugger`:
1. Classifies: Fast Track (visual) or Full Investigation (CMS/API/interaction)
2. Requests evidence before proceeding (screenshot, console errors, API responses)
3. Finds root cause from evidence only — never guesses
4. Reports: exact element, exact fix

Never attempt a fix before running `/debug`. Guessing fixes in Webflow (changing random classes, republishing repeatedly) wastes publish quota and creates inconsistent state.

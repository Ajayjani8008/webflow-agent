# /security-review

Security scan of all custom code, forms, and third-party scripts.

## Steps

1. Route to `security-reviewer` agent
2. Agent collects:
   - All custom code (site-wide + per-page)
   - All form configurations
   - All third-party script URLs
3. Agent runs full security checklist
4. Returns findings by severity

## What Gets Checked

### XSS Prevention
- `innerHTML` usage → requires `DOMPurify.sanitize()` wrapper
- CMS field output in custom JS → must sanitize before DOM insertion
- URL parameter rendering → must encode before display
- `document.write()` → forbidden

### API Key Exposure
- No `WEBFLOW_API_KEY` in client-side code
- No `FIGMA_TOKEN` in client-side code
- No third-party API keys in custom code embeds
- Environment variables referenced only server-side or via secure proxy

### Form Security
- All forms have spam protection (Webflow native reCAPTCHA or Netlify honeypot)
- No sensitive data submitted to Webflow forms (passwords, payment info, SSN)
- File upload fields → only if explicitly needed, with type/size validation
- Action URLs → HTTPS only

### Clickjacking
- Site has `X-Frame-Options: SAMEORIGIN` or CSP `frame-ancestors` set
- No iframes loading from unknown origins

### Mixed Content
- All external resources loaded over HTTPS
- No `http://` references in custom code
- Images/fonts/scripts all HTTPS

### Third-Party Scripts
- Each script identified and purpose justified
- Scripts loaded from CDN with integrity hash when available
- No unrecognized scripts (flag any unknown)
- Analytics scripts configured to respect `prefers-reduced-motion` and consent

### Redirects
- No open redirects (redirect targets hardcoded or validated)
- No sensitive data in URL parameters that get logged

### Webflow-Specific
- Page password protection: not used for real auth (only content gating)
- CMS collections: no fields storing passwords, keys, or tokens
- Custom code: no server-side logic attempted in client-side embed
- Webflow form success redirect: points to HTTPS page

## Output Format

```
## Security Review — [Site Name] — [Date]

### CRITICAL — Fix before any publish
- [location]: [vulnerability] → [exact fix]

### HIGH — Fix before production
- [location]: [issue] → [fix]

### MEDIUM — Fix this sprint
- [location]: [issue] → [fix]

### LOW / INFORMATIONAL
- [location]: [note]

### Passed Checks
- [list]

**Risk Level: CRITICAL / HIGH / MEDIUM / LOW**
```

## Fail Conditions (block publish)

If any of these found → do NOT publish until resolved:
- API key exposed in client-side code
- `innerHTML` with unsanitized CMS/user data
- Form submitting sensitive data without encryption
- Unknown third-party script loading from non-HTTPS origin
- Open redirect vulnerability

---
name: screenshot-to-webflow
description: Screenshot or reference site image → Webflow layout. Uses screenshot-analyst for visual analysis, then same pipeline as figma-to-webflow.
---

# /screenshot-to-webflow

**Usage:** `/screenshot-to-webflow [image path or URL]`

Also accepts: paste screenshot directly in chat, or provide reference site URL.

---

## Pipeline

### Phase 1 — Visual Analysis (foreground)

Route to `screenshot-analyst`:
- Reads image using Claude vision
- Identifies layout structure, element types
- Estimates spacing, typography, colors
- Classifies repeated elements → Symbol candidates
- Produces Design Spec (with confidence ratings)

**PAUSE — show Design Spec to user, wait for:**
1. Corrections to visual analysis (spacing estimates, color values)
2. Section name
3. Approach (A / B / C)
4. CMS vs static decision for any ambiguous elements

After user confirms (with corrections), same pipeline as `/figma-to-webflow` Phase 2–6.

---

## When to use screenshot-analyst vs figma-analyst

| Situation | Use |
|-----------|-----|
| You have the Figma file URL | `/figma-to-webflow` (more accurate) |
| You have a screenshot from Figma | `/screenshot-to-webflow` (good accuracy) |
| You're recreating a reference site | `/screenshot-to-webflow` |
| You drew a rough mockup | `/screenshot-to-webflow` |
| Design is pixel-perfect and critical | `/figma-to-webflow` |

Note: Screenshot analysis is ~80% accurate on spacing — always verify key values.

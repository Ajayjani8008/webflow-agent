---
name: plan
description: Routes any feature request through fr-analyst → planner → human confirmation gate. Always use before building anything non-trivial.
---

# /plan

**Usage:** `/plan [feature description]`

Routes:
1. `fr-analyst` → produces 3 FR docs in `docs/FR/[feature]/`
2. Presents output → waits for your confirmation
3. `planner` → reads FR docs + registries → produces phase-by-phase implementation plan
4. Presents plan → waits for your confirmation
5. Build starts only after explicit "yes, proceed"

Use for:
- Any new page
- Any new CMS collection
- Any new Symbol
- Any multi-section feature
- Any integration (forms, analytics, third-party)

Skip for:
- Single-class style fix
- Single element text change
- Adding one existing symbol to a page

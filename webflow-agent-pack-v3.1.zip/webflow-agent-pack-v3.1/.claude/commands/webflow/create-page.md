---
name: create-page
description: Creates a new Webflow page via REST API. Sets slug, title, and SEO meta. Adds to page_registry.md.
---

# /create-page

**Usage:** `/create-page`

Agent asks:
- Page title
- Page slug (URL path)
- Page type: static / CMS template / utility
- If CMS template: which collection
- SEO title and meta description
- Parent page (for nested URLs, e.g., /services/enterprise)

Then:
1. `webflow-builder` → POST /v2/sites/{id}/pages (creates page)
2. `seo-optimizer` → PATCH /v2/pages/{id} (sets SEO meta)
3. `doc-updater` → updates page_registry.md

After creation: opens blank page in Webflow (user must open Designer to verify). Build sections with `/create-section`.

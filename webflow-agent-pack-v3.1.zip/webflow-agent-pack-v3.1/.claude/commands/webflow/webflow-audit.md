---
name: webflow-audit
description: Full Webflow site health check. Checks API connectivity, page count, CMS status, publish status, and site settings.
---

# /webflow-audit

**Usage:** `/webflow-audit`

```bash
# Site info
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID" \
  | python3 -c "
import sys,json
d = json.load(sys.stdin)
print('Site:', d.get('displayName'))
print('Domain:', d.get('defaultDomain'))
print('Custom domains:', [cd.get('url') for cd in d.get('customDomains',[])])
print('Last published:', d.get('lastPublished'))
print('Created:', d.get('createdOn'))
"

# Pages
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/pages" \
  | python3 -c "
import sys,json
pages = json.load(sys.stdin).get('pages',[])
print(f'Pages: {len(pages)}')
for p in pages:
    seo = p.get('seo',{})
    has_title = bool(seo.get('title'))
    has_desc = bool(seo.get('description'))
    print(f'  {p[\"slug\"]:30} title:{has_title} desc:{has_desc}')
"

# Collections
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/collections" \
  | python3 -c "
import sys,json
cols = json.load(sys.stdin).get('collections',[])
print(f'Collections: {len(cols)}')
for c in cols:
    print(f'  {c[\"slug\"]:30} ID: {c[\"id\"]}')
"

# Assets
curl -s -H "Authorization: Bearer $WEBFLOW_API_KEY" \
  "https://api.webflow.com/v2/sites/$WEBFLOW_SITE_ID/assets" \
  | python3 -c "
import sys,json
assets = json.load(sys.stdin).get('assets',[])
total_kb = sum(a.get('fileSize',0) for a in assets) // 1024
large = [a for a in assets if a.get('fileSize',0) > 200*1024]
print(f'Assets: {len(assets)} | Total: {total_kb}KB')
print(f'Large (>200KB): {len(large)}')
for a in large[:5]:
    print(f'  {a[\"originalFileName\"]} — {a[\"fileSize\"]//1024}KB')
"
```

Output summary:
```
=== Webflow Site Audit — {{SITE_NAME}} ===

Site health:    OK
API connection: OK
Last published: [date]

Pages:          [N] total, [N] missing SEO meta
Collections:    [N] total
CMS items:      [N] published, [N] draft
Assets:         [N] files, [total]KB, [N] large (>200KB)

Issues found:
  - [list of issues or "None"]

Recommendations:
  - [list]
```

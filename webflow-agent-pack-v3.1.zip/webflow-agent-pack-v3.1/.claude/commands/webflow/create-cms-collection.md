---
name: create-cms-collection
description: Creates a new Webflow CMS collection with fields via REST API. Designs schema, adds sample items, and registers in cms_registry.md.
---

# /create-cms-collection

**Usage:** `/create-cms-collection`

Agent asks:
- Collection display name (e.g., "Blog Posts")
- Singular name (e.g., "Blog Post")
- Slug (e.g., "blog-posts")
- Fields needed: name, type, required?, notes
- Sample items to add for testing

Pipeline:
1. `cms-builder` → designs full schema
2. Wait for confirmation → then:
3. `cms-builder` → POST collection → POST each field → POST sample items
4. `doc-updater` → register in cms_registry.md (background)

After creation: tell user to check Webflow CMS panel — collection should appear with items.
Also tell user to create CMS Template page for this collection (via `/create-page` with type: CMS template).

# Webflow Responsive Rules

## Breakpoint Order (mobile-first design, desktop-first in Webflow)

Webflow applies styles top-down: Desktop → Tablet → Mobile Landscape → Mobile.
Styles set at Desktop apply to all breakpoints unless overridden.

Design convention: design for desktop, override downward.

## Required Breakpoint Checks

Every section must be verified at:
1. Desktop (1200px preview)
2. Tablet (768px preview)
3. Mobile landscape (480px preview)
4. Mobile portrait (375px preview — use 375, not min 479)

Never mark a section complete without all 4 checked.

## Standard Responsive Patterns

### Grid → Stack

```
Desktop: grid-cols-3
Tablet:  grid-cols-2
Mobile:  grid-cols-1 (width: 100%)
```

### Flex row → Column

```
Desktop: flex-direction: row
Tablet:  flex-direction: column (or column-reverse for media swap)
Mobile:  flex-direction: column
```

### Font sizes

```
Desktop: var(--font-size-6xl)  H1 hero
Tablet:  var(--font-size-5xl)
Mobile:  var(--font-size-4xl)

Desktop: var(--font-size-5xl)  H2 section
Tablet:  var(--font-size-4xl)
Mobile:  var(--font-size-3xl)
```

### Section padding

```
Desktop: var(--space-5xl) top/bottom
Tablet:  var(--space-4xl) top/bottom
Mobile:  var(--space-3xl) top/bottom
```

### Container padding

```
Desktop: padding: 0 var(--space-lg)
Tablet:  padding: 0 var(--space-md)
Mobile:  padding: 0 var(--space-sm)
```

## Common Responsive Failures

| Problem | Fix |
|---------|-----|
| Nav links overflow on tablet | Display none at tablet, show hamburger |
| Card text too long on mobile | Add max-width or reduce font-size override |
| Hero image wrong size on mobile | Set specific height at mobile, object-fit: cover |
| Two-col layout too narrow on tablet | Stack to 1 col or reduce padding |
| Absolute positioned element bleeds | Switch to relative at mobile |
| Gap between elements wrong | Set gap override at each breakpoint |
| Interaction triggers wrong on touch | Check Webflow interaction "Affects mobile" checkbox |

## Webflow-Specific Responsive Notes

- Webflow grid: set `grid-template-columns` override at each breakpoint in Designer
- Images: always have `width: 100%` + `max-width: 100%` on mobile breakpoint
- Text: `text-align: center` at mobile is usually correct for section headings
- Buttons: `width: 100%` on mobile for better tap targets
- Navbar: Webflow Navbar element handles mobile menu automatically — don't custom-build it

# Cross-Site Portability Rules

## What transfers when you copy a section via DOM API to another site

| Element | Transfers? | Notes |
|---------|-----------|-------|
| `section`, `div-block`, `container` | YES | Full structure preserved |
| `heading`, `paragraph`, `text-span` | YES | Text content preserved |
| `image` (static src URL) | YES | URL must be accessible from new domain |
| `link-block`, `button` | YES | href preserved |
| HTML embed (custom code) | YES | Code content preserved |
| Custom CSS in head code | YES | Via `custom_code` API endpoint |
| Custom JS in body code | YES | Via `custom_code` API endpoint |
| CSS `@keyframes` animations | YES | In head code — fully portable |
| JS `IntersectionObserver` animations | YES | In code embed — fully portable |
| **Webflow Interactions 2.0** | **NO** | Stored in Designer project database, not DOM |
| **Webflow Slider (native)** | **NO** | `w-slider-*` IDs assigned by Designer — lost on copy |
| **Webflow Tabs (native)** | **NO** | `w-tab-*` IDs assigned by Designer — lost on copy |
| **Webflow Navbar (mobile toggle)** | Partial | Structure copies, mobile JS needs re-init in Designer |
| **CMS bindings (xattr fields)** | **NO** | Collection IDs differ between sites — must rebind |
| **Symbol instances (component)** | **NO** | Symbol IDs are site-specific — must re-create |

---

## Why native components break after copy

Webflow's Slider, Tabs, Accordion, and Navbar components work because:
1. Webflow Designer assigns internal IDs (`w-slider-0`, `w-tab-link-0-0`, etc.) during setup
2. Webflow.js runtime looks for these exact IDs to initialize the component
3. When you copy via DOM API, the Designer has never seen these elements — it never assigned IDs
4. Result: blank slider tracks, inactive tabs, broken mobile nav

Webflow Interactions 2.0 break because:
1. Interaction definitions live in the Webflow project's IX2 database
2. Only the class names are in the DOM — not the animation values
3. The new site has no IX2 entry for those classes — elements sit at initial state (often opacity 0)
4. Result: invisible elements frozen in initial state

---

## After copying sections to a new site — mandatory checklist

- [ ] Re-create all Webflow native Interactions in new site Designer (use `interaction_registry.md` specs)
- [ ] Delete any copied Slider/Tabs/Navbar shells → add fresh components from Designer Elements panel
- [ ] Re-apply the same BEM classes to fresh components
- [ ] Re-map all CMS bindings (collection IDs differ — check `cms_registry.md` for field slugs)
- [ ] Convert any Symbol instances to regular elements, rebuild as fresh Symbols in new site
- [ ] Verify Webflow.js is NOT excluded in new site's page settings
- [ ] Test all interactions at desktop AND mobile breakpoints
- [ ] Test slider auto-play, tabs click, accordion open/close

---

## Portable alternatives for interactive components

Use these when a section WILL be shared across multiple sites:

| Native (not portable) | Portable alternative | Notes |
|----------------------|---------------------|-------|
| Webflow Slider | Splide.js via JS embed | Stays in DOM, lightweight |
| Webflow Tabs | Custom JS tab switcher (code embed) | 10 lines of JS |
| Webflow IX2 scroll reveal | CSS `@keyframes` + `IntersectionObserver` | CSS in head, JS in embed |
| Webflow IX2 hover interaction | CSS `:hover` + `transition` (class style) | Fully portable via class styles |
| Webflow accordion | CSS `details`/`summary` HTML | Native HTML, zero JS |

When creating a component that will be reused cross-site, document the portable version in `component_registry.md`.

---

## CSS-only hover (portable replacement for IX2 hover)

Instead of Webflow hover interaction, use class style:
```css
.card {
  transition: transform var(--duration-base) ease-out, box-shadow var(--duration-base) ease-out;
}
.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(0,0,0,0.12);
}
```
Set in Webflow Designer class panel → hover state. This IS in the class styles and DOES copy with the DOM.

---

## Portable scroll-reveal (replaces IX2 scroll trigger)

Paste in site head custom code — portable across all sites:
```html
<style>
[data-reveal] {
  opacity: 0;
  transform: translateY(24px);
  transition: opacity 0.5s ease-out, transform 0.5s ease-out;
}
[data-reveal].is-visible {
  opacity: 1;
  transform: translateY(0);
}
</style>
<script>
const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('is-visible');
      observer.unobserve(e.target);
    }
  });
}, { rootMargin: '0px 0px -10% 0px' });
document.querySelectorAll('[data-reveal]').forEach(el => observer.observe(el));
</script>
```
Usage: add `data-reveal` attribute to any element in Designer.

# Webflow Interaction Rules

## Consistency Mandate

Same interaction type → same timing, same easing across entire site.
Check interaction_registry.md before creating any new interaction.

If `card-hover-lift` already exists: all cards use it. Never create `service-card-hover` separately.

## Forbidden Animation Properties

Never animate (causes layout reflow → janky animation):
- `width` / `height` (exception: height for accordions, carefully)
- `margin` / `padding`
- `top` / `left` / `right` / `bottom`
- `font-size`
- `border-width`

Always use instead:
- `transform: translateX/Y()` — for movement
- `transform: scale()` — for size changes
- `opacity` — for visibility
- `filter: blur()` — for blur effects

## Maximum Simultaneous Properties

Max 3 animated properties on one element per interaction step.
More than 3 = likely performance problem.

## Mobile Rules

- Parallax effects → disable at tablet + mobile breakpoints
- Hover interactions → Webflow converts hover to tap on touch devices (acceptable)
- Counter animations → keep on mobile
- Page load animations → keep but reduce complexity
- Custom cursor → hide at mobile (set `display: none` in custom CSS at mobile breakpoint)
- Scroll reveals → keep, verify they trigger correctly on iOS (use 10% offset from bottom)

## Stagger Values

| List size | Stagger |
|-----------|---------|
| 2–3 items | 100ms |
| 4–6 items | 80ms |
| 7–12 items | 60ms |
| >12 items | 40ms or no stagger |

Never exceed 150ms stagger — feels too slow.

## Interaction Limit per Page

No hard limit in Webflow, but for performance:
- Max 5 unique interaction types per page
- Max 20 scroll-triggered interaction instances per page
- Heavy pages: test at 4× CPU slowdown in DevTools before publishing

## "Limit: Once" Rule

Scroll-triggered reveals: always enable "Limit: once" unless intentional loop.
Without it: element re-animates on every scroll up/down → distracting.

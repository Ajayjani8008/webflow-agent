# Webflow Class Naming Rules

## Enforcement (zero exceptions)

- kebab-case only: `hero__title` not `heroTitle` or `hero_title`
- Double underscore for element: `section__element`
- Double dash for modifier: `element--variant`
- No numbers in class names: `card-1` → `card` (use stagger in interaction instead)
- No page-specific names: `home__hero` → `hero` (hero is reusable)
- No color names: `btn--blue` → `btn--primary`
- No size absolutes: `text-24` → `text-xl` (use variable scale)

## BEM Block Identification

A block is:
- A section root (has layout/background/padding)
- A card or item (repeated unit)
- A navigation element (navbar, footer, breadcrumb)
- A form or form section
- A modal or overlay
- A custom UI component (accordion, tabs, slider)

A block is NOT:
- A generic wrapper inside a block (use `block__inner`, `block__content`)
- A utility (use global utility class: `.container`, `.btn--primary`)

## Combo Classes in Webflow

Combo = first class (base) + second class (modifier).
In node JSON: `"classes": ["base", "base--modifier"]`
In Webflow Designer: both classes appear in class selector.

```
"classes": ["btn", "btn--primary"]     ✓ correct
"classes": ["btn--primary"]            ✗ wrong — modifier without base
"classes": ["btn", "primary"]          ✗ wrong — orphan modifier without namespace
```

## Class Reuse Mandate

Before creating any new class:
1. Check class_registry.md
2. If similar class exists, use it (or add modifier)
3. Only create new if genuinely different pattern

Two classes that do the same thing = tech debt. One class, multiple instances.

## Naming Gray Areas

| Situation | Decision |
|-----------|---------|
| Card used in 3 different sections | `.card` (generic) — add section-specific modifier if needed |
| Heading used everywhere | Use heading element H-levels + `.section-header__title` etc |
| Section with no clear name | Name after content type: `.testimonials`, `.faqs`, `.pricing` |
| One-off section | Still name it semantically: `.founders-story`, `.mission` |
| Transition/animation states | Set via Webflow Interactions — no class needed |

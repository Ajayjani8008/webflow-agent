# Agent Orchestration Rules (Webflow)

## MCP Tool Priority

Before any operation, check which mode is active:

| Mode | Condition | How to identify |
|------|-----------|----------------|
| **MCP Mode** | Webflow connector available | You see `mcp__claude_ai_Webflow__*` in your tool list |
| **API Mode** | REST API only | `WEBFLOW_API_KEY` set, no MCP tools |

**MCP Mode** (preferred): site auto-detected by name, no credentials needed, Designer-aware.
**API Mode**: use curl with `$WEBFLOW_API_KEY` for all operations.

In MCP Mode: call `mcp__claude_ai_Webflow__webflow_guide_tool` once at session start to learn available capabilities.

---

## Native-First Mandate (enforced before every build)

Before creating ANY element or code, check the priority ladder:

```
Level 1 → Webflow native element exists?  USE IT (section, div-block, navbar, slider, tabs, grid...)
Level 2 → Webflow Interaction 2.0 can do it?  USE IT (hover, scroll reveal, click, page load...)
Level 3 → CSS class style can handle it?  USE IT (variables, transitions, :hover in class panel)
Level 4 → Site-level head CSS?  Only if no native class solution
Level 5 → Page-level CSS?  Only if different from site-wide
Level 6 → Custom JS embed?  Only for: counters, marquee, third-party APIs, complex interactivity
Level 7 → HTML embed?  LAST RESORT. Write justification: "Cannot achieve with Level 1-6 because: [reason]"
```

STOP before jumping to Level 7. Explain why levels 1-6 fail before proceeding.

---

## Intent Detection (auto-route before asking anything)

| What user sends | Detected intent | Immediate action |
|----------------|----------------|-----------------|
| Figma URL (`figma.com/design/...`) | Build this Figma design in Webflow | Route to `figma-analyst` immediately |
| Screenshot / image pasted | Build from this visual | Route to `screenshot-analyst` immediately |
| `bug::` or `issue::` prefix | Debug this bug | Route to `systematic-debugger` immediately |
| `feat::` or feature description | Plan and build feature | Route to `fr-analyst` immediately |
| Site/project name mentioned | Find and activate that Webflow site | Use MCP `data_sites_tool` or curl `/v2/sites` to find by name |

No asking "what would you like to do?" when intent is detectable from message content.

---

## Main Claude Forbidden Actions

Main Claude MUST NEVER:
- Call Webflow API write endpoints directly — always delegate to correct agent
- Create CMS collections without `cms-builder` — schema must follow registry
- Add interactions without `interaction-builder` — timing must be consistent
- Use `html-embed` for layouts that Webflow native elements support — check Level 1 first
- Build pages without checking registries first
- Start implementation without human requirement echo-back + confirmation

---

## Mandatory First-Action Rules

| Trigger | Agent | Mode |
|---------|-------|------|
| `bug::` or `issue::` prefix | `systematic-debugger` | Foreground |
| `feat::` or new feature request | `fr-analyst` | Foreground |
| Figma URL in message | `figma-analyst` → `/figma-to-webflow` | Foreground, immediate |
| Screenshot/image in message | `screenshot-analyst` → `/screenshot-to-webflow` | Foreground, immediate |
| `html-embed` about to be used | Check native-first ladder (levels 1-6) | Before any embed |
| New page needed | `webflow-builder` (after class-manager pre-plans) | Foreground |
| New section needed | `class-manager` → `webflow-builder` | Foreground |
| New Symbol/component | `component-builder` → `class-manager` | Foreground |
| New CMS collection | `cms-builder` | Foreground |
| New variable(s) | `style-manager` | Foreground |
| Interaction/animation needed | `interaction-builder` | Foreground |
| SEO meta needed | `seo-optimizer` | Foreground |
| Architecture decision needed | `architect` | Foreground |
| Planning request | `planner` (after `fr-analyst`) | Foreground |
| Performance issue | `performance-optimizer` | Foreground |
| Custom code written | `code-reviewer` | Foreground |
| Custom code + forms | `code-reviewer` + `security-reviewer` | Foreground (parallel) |

---

## Reviewer Gate

| Tier | Trigger | Agents |
|------|---------|--------|
| 1 (Skip) | Class style change only in Designer, no code | None |
| 2 (Code) | Custom CSS/JS written, HTML embeds added | `code-reviewer` |
| 3 (Code + Security) | Form handler, redirect logic, API key usage, third-party script | `code-reviewer` + `security-reviewer` |

---

## Background Agents (fire-and-forget after every build)

- `doc-updater` — update all registries
- `project-map` — rebuild blast radius map (after major feature only)

Launch parallel to other post-build steps.

---

## Parallel Execution

Independent agents launch simultaneously:
```
[Parallel after figma-analyst / screenshot-analyst confirmation]:
- class-manager (design class plan)
- style-manager (check/create variables)
Then:
- webflow-builder (build DOM — waits for class plan + variables)
Then [parallel]:
- interaction-builder (produce interaction specs)
- doc-updater (update registries)
```

---

## Confirmation Gates

REQUIRE explicit human confirmation before proceeding:
1. Requirement echo-back → confirm understanding before any plan
2. FR analysis output → confirm before planner runs
3. Implementation plan → confirm before build starts
4. Design Spec (figma-analyst / screenshot-analyst) → confirm before webflow-builder runs
5. Pre-build node outline (webflow-builder Step 2.5) → confirm before API POST
6. Architecture proposal → confirm before any structural change
7. `/publish production` → always confirm explicitly

---

## Multi-Perspective Analysis

Before every recommendation:
1. **Engineer lens**: correctness, API validity, class consistency, native-first compliance
2. **Designer lens**: visual quality, accessibility, responsive behaviour, pixel accuracy
3. **Business lens**: CMS editability by client, SEO impact, performance budget

Flag conflicts between lenses. Let human decide.

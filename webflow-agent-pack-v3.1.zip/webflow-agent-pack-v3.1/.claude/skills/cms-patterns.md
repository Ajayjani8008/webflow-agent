---
name: cms-patterns
description: Webflow CMS design patterns — collection relationships, common schemas, CMS template page patterns, Collection List configuration, and CMS filtering/sorting.
---

# Webflow CMS Patterns Reference

## Common Collection Schemas

### Blog Posts
```
name  PlainText  required  Display title
slug  Slug  required  URL path (auto from name)
subtitle  PlainText  no  Deck/standfirst
cover-image  ImageRef  required  Hero + card image
cover-image-alt PlainText no  Alt text for above
body  RichText  required  Full article content
author  ItemRef→Authors no  Reference to Authors collection
categories  MultiRef→Categories no Multiple categories
published-date DateTime  no  Override publish date display
featured  Bool  no  Show in featured spots
read-time  PlainText  no  "5 min read" (manual entry)
seo-title  PlainText  no  Override page title
seo-description PlainText no  Override meta description
```

### Services
```
name  PlainText  required
slug  Slug  required
short-description PlainText  required  Card subtitle (max 120 chars)
description  RichText  required  Full page content
cover-image  ImageRef  required
icon  ImageRef  no  SVG or icon image
featured  Bool  no  Homepage preview
display-order  Number  no  Sort order
cta-text  PlainText  no  "Get Started" (default if empty)
cta-url  Link  no  Override for external link
related-services  MultiRef→Services no
seo-title  PlainText  no
seo-description  PlainText  no
```

### Team Members
```
name  PlainText  required
slug  Slug  required
role  PlainText  required  "Head of Design"
photo  ImageRef  required
bio  PlainText  no  Short bio (2–3 sentences)
long-bio  RichText  no  Full bio for detail page
linkedin-url  Link  no
twitter-url  Link  no
email  Email  no
department  Option  no  Engineering, Design, Marketing, etc.
display-order  Number  no
featured  Bool  no  Show on homepage team preview
```

### Case Studies
```
name  PlainText  required
slug  Slug  required
client-name  PlainText  required
industry  Option  no
cover-image  ImageRef  required
challenge  RichText  required
solution  RichText  required
results  RichText  no
result-metric-1  PlainText  no  "300% increase in..."
result-metric-2  PlainText  no
result-metric-3  PlainText  no
related-services  MultiRef→Services no
testimonial-quote PlainText  no
testimonial-author PlainText  no
featured  Bool  no
seo-title  PlainText  no
seo-description  PlainText  no
```

### Testimonials (reference collection)
```
name  PlainText  required  Author full name
role  PlainText  required  "CEO at Acme Corp"
company  PlainText  no
photo  ImageRef  no
quote  PlainText  required  The testimonial text
rating  Number  no  1–5 stars
featured  Bool  no
```

### FAQs
```
name  PlainText  required  Question text
answer  RichText  required
category  Option  no  Group FAQs by topic
display-order Number  no
```

## Collection Relationships

### One-to-many (ItemRef)
```
Blog Post → Author
(Each post has one author)
Field type: ItemRef → Authors collection
```

### Many-to-many (MultiRef)
```
Blog Post → Categories
Services → Industries
(Each post can have multiple categories)
Field type: MultiRef → Categories collection
```

### Self-reference (MultiRef to same collection)
```
Services → Related Services
(A service can reference other services)
Field type: MultiRef → Services collection
```

## CMS Template Page Patterns

### Standard CMS template layout

```
Page: /services/{slug}

Structure:
  section (.service-hero)
    container
      div (.service-hero__inner)  ← flex-row
        div (.service-hero__content)
          text-span (.eyebrow)  → category (CMS bound)
          heading H1 (.service-hero__title)  → name (CMS bound)
          paragraph (.service-hero__subtitle) → short-description (CMS bound)
          link-block (.btn.btn--primary)  → cta-url (CMS) or /contact
        div (.service-hero__media)
          image (.service-hero__image)  → cover-image (CMS bound)

  section (.service-body)
    container.container--narrow
      rich-text (.service-body__content)  → description (CMS bound)

  section (.related-services)  ← Collection List of related items
    container
      div (.section-header)
        heading H2  → "Related Services" (static)
      collection-list-wrapper  → Services collection, filter by related-services field
        collection-list (.cards-grid__list)
          collection-item (.service-card)  → CMS bound card
```

## Collection List Configuration (Designer)

After webflow-builder creates the Collection List node, configure in Designer:

1. Select Collection List Wrapper
2. Settings panel → Collection: pick collection
3. Filter conditions:
   - "Featured is on" for featured sections
   - "Category = [current page's category]" for related items
   - "Name does not equal [current item name]" for related (exclude self)
4. Sort: by `display-order` ascending OR `created-on` descending
5. Limit: set appropriate limit (6 for grid, 3 for preview, 100 for archive)
6. Empty state: add inside Collection List (shows when no items match filter)

## CMS Filtering Patterns

### Homepage → Featured only
```
Filter: featured is on
Sort: display-order ascending
Limit: 6
```

### Archive → All published
```
Filter: (none — all published items show automatically)
Sort: created-on descending (newest first)
Limit: 100 (or use Finsweet CMS Load for more)
```

### Detail page → Related (exclude current)
```
Filter: related-services references current item
  OR: category matches current item's category
  AND: name does not equal current item name
Limit: 3
```

### Category filter page
```
Create page /blog/category/{slug} (category CMS template)
Collection List: Blog Posts
Filter: categories includes current category
Sort: published-date descending
```

## Finsweet CMS Attributes

For features Webflow doesn't support natively:

| Feature | Finsweet attribute |
|---|---|
| Load more / pagination | `fs-cmsload-element="list"` + button |
| Client-side filter | `fs-cmsfilter-field="category"` |
| Sort controls | `fs-cmssort-field="date"` |
| CMS search | `fs-cmssearch-field="name"` |
| Nested Collection List | `fs-cmsnestcollection-*` |

Add to `<head>`:
```html
<script defer src="https://cdn.jsdelivr.net/npm/@finsweet/attributes-cmsload@1/cmsload.js"></script>
```

---
name: webflow-api
description: Complete Webflow REST API v2 reference. Endpoints, authentication, rate limits, node types, and common patterns for all agents to reference.
---

# Webflow REST API v2 — Complete Reference

**Base URL:** `https://api.webflow.com/v2`
**Auth:** `Authorization: Bearer {WEBFLOW_API_KEY}`
**Content-Type:** `application/json` for all POST/PATCH/PUT

## Rate Limits

| Plan | Requests/minute |
|---|---|
| Basic | 60 |
| CMS | 60 |
| Business | 120 |
| Enterprise | 240 |

Rate limit headers in response: `X-RateLimit-Remaining`, `X-RateLimit-Limit`
On 429: wait 1s, retry.

## Sites

```bash
GET  /v2/sites  # List all sites
GET  /v2/sites/{site_id}  # Get site details
```

Site object: `id`, `displayName`, `shortName`, `defaultDomain`, `customDomains`, `lastPublished`

## Pages

```bash
GET  /v2/sites/{site_id}/pages  # List pages
POST  /v2/sites/{site_id}/pages  # Create page
GET  /v2/pages/{page_id}  # Get page
PATCH  /v2/pages/{page_id}  # Update page settings (slug, title, SEO)
DELETE /v2/pages/{page_id}  # Delete page

GET  /v2/pages/{page_id}/dom  # Get page DOM (node tree)
POST  /v2/pages/{page_id}/dom  # Set page DOM (replaces ALL content)
PATCH  /v2/pages/{page_id}/dom/nodes/{node_id}  # Update specific node

GET  /v2/pages/{page_id}/custom_code  # Get page-level custom code
PUT  /v2/pages/{page_id}/custom_code  # Set page-level custom code
```

### Create page body

```json
{
  "slug": "services",
  "title": "Services",
  "draft": false,
  "seo": {
    "title": "Services | Site Name",
    "description": "Meta description here."
  },
  "openGraph": {
    "title": "Services | Site Name",
    "description": "OG description.",
    "image": { "url": "https://cdn.../og.jpg", "alt": "OG image description" }
  }
}
```

### DOM POST body

```json
{
  "nodes": [
    { "type": "section", "data": { "attr": { "id": "hero" }, "classes": ["hero"] }, "children": [] }
  ]
}
```

**Warning:** POST to DOM **replaces** entire page content. To append, first GET current DOM, merge nodes, then POST.

## Collections

```bash
GET  /v2/sites/{site_id}/collections  # List collections
POST  /v2/sites/{site_id}/collections  # Create collection
GET  /v2/collections/{collection_id}  # Get collection + fields
PATCH  /v2/collections/{collection_id}  # Update collection name/slug

POST  /v2/collections/{collection_id}/fields  # Add field
PATCH  /v2/collections/{collection_id}/fields/{field_id}  # Update field
DELETE /v2/collections/{collection_id}/fields/{field_id}  # Delete field

GET  /v2/collections/{collection_id}/items  # List items (paginated)
POST  /v2/collections/{collection_id}/items  # Create single item
POST  /v2/collections/{collection_id}/items/bulk  # Bulk create items
GET  /v2/collections/{collection_id}/items/{item_id}  # Get item
PATCH  /v2/collections/{collection_id}/items/{item_id}  # Update item
DELETE /v2/collections/{collection_id}/items/{item_id}  # Delete item
POST  /v2/collections/{collection_id}/items/publish  # Publish items
```

### List items with pagination

```bash
GET /v2/collections/{id}/items?limit=100&offset=0
```

Response: `{ "items": [...], "pagination": { "limit": 100, "offset": 0, "total": 250 } }`

## Variables (Design Tokens)

```bash
GET  /v2/sites/{site_id}/variables  # List variables
POST  /v2/sites/{site_id}/variables  # Create variable
GET  /v2/variables/{variable_id}  # Get variable
PATCH  /v2/variables/{variable_id}  # Update variable value
DELETE /v2/variables/{variable_id}  # Delete variable
```

Variable body:
```json
{ "name": "--color-primary", "type": "Color", "value": "#0050ff" }
```

Types: `Color`, `Size`, `PlainText`

## Assets

```bash
GET  /v2/sites/{site_id}/assets  # List assets
POST  /v2/sites/{site_id}/assets  # Upload asset (multipart/form-data)
GET  /v2/assets/{asset_id}  # Get asset
DELETE /v2/assets/{asset_id}  # Delete asset
```

## Custom Code

```bash
GET  /v2/sites/{site_id}/custom_code  # Get site-wide custom code
PUT  /v2/sites/{site_id}/custom_code  # Set site-wide custom code
```
Page-level custom_code endpoints: see Pages section.

Custom code body:
```json
{ "headCode": "<script>...</script>", "footerCode": "<script>...</script>" }
```

## Publish

```bash
POST /v2/sites/{site_id}/publish
```

Body:
```json
{
  "publishToWebflowSubdomain": true,
  "customDomains": ["yourdomain.com"]
}
```

## Forms

```bash
GET /v2/sites/{site_id}/forms  # List forms
GET /v2/forms/{form_id}/submissions  # List submissions
```

## Webhooks

```bash
GET  /v2/sites/{site_id}/webhooks  # List webhooks
POST  /v2/sites/{site_id}/webhooks  # Create webhook
DELETE /v2/webhooks/{webhook_id}  # Delete webhook
```

Webhook triggers: `form_submission`, `site_publish`, `collection_item_created`, `collection_item_updated`, `collection_item_deleted`

## Error Codes

| Code | Meaning |
|---|---|
| 400 | Bad request — check request body |
| 401 | Unauthorized — token missing or expired |
| 403 | Forbidden — token lacks required scope |
| 404 | Not found — wrong ID |
| 409 | Conflict — slug already exists |
| 422 | Unprocessable — invalid field value |
| 429 | Rate limited — wait and retry |
| 500 | Webflow internal error — retry |

## Token Scopes Required

| Operation | Required scope |
|---|---|
| Read pages | `pages:read` |
| Write pages | `pages:write` |
| Read CMS | `cms:read` |
| Write CMS | `cms:write` |
| Read assets | `assets:read` |
| Write assets | `assets:write` |
| Read site | `sites:read` |
| Write custom code | `custom_code:write` |
| Publish | `sites:publish` |

Generate token at: Webflow → Account Settings → Integrations → API Access → Generate Token (select required scopes).

#!/bin/bash
# Webflow Agent Pack v3.0 — Installer
set -e

PACK="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE="$HOME/.claude"

echo "=== Webflow Agent Pack v3.0 Installer ==="
echo "Source: $PACK"
echo "Target: $CLAUDE"
echo ""

mkdir -p "$CLAUDE/agents/webflow" "$CLAUDE/commands/webflow" "$CLAUDE/rules/webflow" "$CLAUDE/rules/common"

echo "Copying 19 agents..."
cp "$PACK/.claude/agents/webflow/"*.md "$CLAUDE/agents/webflow/"

echo "Copying 19 commands..."
cp "$PACK/.claude/commands/webflow/"*.md "$CLAUDE/commands/webflow/"

echo "Copying 5 rules..."
cp "$PACK/.claude/rules/webflow/"*.md "$CLAUDE/rules/webflow/"
cp "$PACK/.claude/rules/common/"*.md "$CLAUDE/rules/common/"

echo ""
echo "=== NEXT: Add Webflow MCP Token ==="
echo ""
echo "1. Get token: Webflow Dashboard → Account Settings → Integrations → API Access"
echo ""
echo "2. Add to ~/.claude/settings.json (mcpServers section):"
echo '   "webflow": {'
echo '     "command": "npx",'
echo '     "args": ["-y", "@webflow/mcp-server@latest"],'
echo '     "env": { "WEBFLOW_TOKEN": "YOUR_TOKEN" }'
echo '   }'
echo ""
echo "3. Restart Claude Code"
echo ""
echo "=== Done. /webflow: commands are now active. ==="

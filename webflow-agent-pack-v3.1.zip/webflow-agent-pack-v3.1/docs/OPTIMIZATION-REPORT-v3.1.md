# Token Optimization Report — v3.0 → v3.1

Date: 2026-07-02. Method: safety-first optimization (9 parallel review passes, hard preservation constraints).

## Verdict

**v3.0 was already at its compression floor.** It is the product of the 2026-06-30 token-optimization pass; ~55–95% of every file is protected content (code blocks, tables, output-format specs, thresholds, gates). Total safe reduction achieved: **2.3%** — far below the 15–25% target. Forcing the target would require cutting protected content, i.e. repeating the prior 20%-accuracy regression. All applied changes are behavior-neutral and validated.

## Comparison Matrix (chars ≈ tokens×4)

| File | v3.0 | v3.1 | Reduction | Preservation |
|---|---|---|---|---|
| **Agents** | **134363** | **131940** | **1.8%** | 100% |
| &nbsp;&nbsp;architect.md | 5234 | 5206 | 0.5% | 100% |
| &nbsp;&nbsp;class-manager.md | 6481 | 6459 | 0.3% | 100% |
| &nbsp;&nbsp;cms-builder.md | 6301 | 6284 | 0.3% | 100% |
| &nbsp;&nbsp;code-reviewer.md | 4060 | 4060 | 0% | 100% |
| &nbsp;&nbsp;component-builder.md | 6637 | 6604 | 0.5% | 100% |
| &nbsp;&nbsp;doc-updater.md | 3731 | 3726 | 0.1% | 100% |
| &nbsp;&nbsp;figma-analyst.md | 9200 | 9119 | 0.9% | 100% |
| &nbsp;&nbsp;fr-analyst.md | 4361 | 4335 | 0.6% | 100% |
| &nbsp;&nbsp;interaction-builder.md | 9803 | 9707 | 1.0% | 100% |
| &nbsp;&nbsp;performance-optimizer.md | 4939 | 4939 | 0% | 100% |
| &nbsp;&nbsp;planner.md | 3921 | 3921 | 0% | 100% |
| &nbsp;&nbsp;project-map.md | 4881 | 4844 | 0.8% | 100% |
| &nbsp;&nbsp;screenshot-analyst.md | 6286 | 6251 | 0.6% | 100% |
| &nbsp;&nbsp;security-reviewer.md | 4627 | 4627 | 0% | 100% |
| &nbsp;&nbsp;seo-optimizer.md | 5196 | 5196 | 0% | 100% |
| &nbsp;&nbsp;style-manager.md | 8055 | 7950 | 1.3% | 100% |
| &nbsp;&nbsp;systematic-debugger.md | 6184 | 6184 | 0% | 100% |
| &nbsp;&nbsp;webflow-builder.md | 15644 | 15595 | 0.3% | 100% |
| &nbsp;&nbsp;webflow-orchestrator.md | 18822 | 16933 | 10.0% | 100% |
| **Skills** | **36434** | **33878** | **7.0%** | 100% |
| &nbsp;&nbsp;class-system.md | 6876 | 6063 | 11.8% | 100% |
| &nbsp;&nbsp;cms-patterns.md | 7051 | 6298 | 10.7% | 100% |
| &nbsp;&nbsp;debug-issue.md | 765 | 765 | 0% | 100% |
| &nbsp;&nbsp;explore-codebase.md | 883 | 883 | 0% | 100% |
| &nbsp;&nbsp;figma-bridge.md | 6074 | 5823 | 4.1% | 100% |
| &nbsp;&nbsp;interactions.md | 6944 | 6783 | 2.3% | 100% |
| &nbsp;&nbsp;refactor-safely.md | 875 | 875 | 0% | 100% |
| &nbsp;&nbsp;review-changes.md | 745 | 745 | 0% | 100% |
| &nbsp;&nbsp;webflow-api.md | 6221 | 5643 | 9.3% | 100% |
| **Commands** | **33899** | **33684** | **0.6%** | 100% |
| &nbsp;&nbsp;add-interaction.md | 1002 | 1002 | 0% | 100% |
| &nbsp;&nbsp;code-review.md | 2068 | 2068 | 0% | 100% |
| &nbsp;&nbsp;connect-cms.md | 2232 | 2187 | 2.0% | 100% |
| &nbsp;&nbsp;create-cms-collection.md | 866 | 866 | 0% | 100% |
| &nbsp;&nbsp;create-component.md | 1071 | 1071 | 0% | 100% |
| &nbsp;&nbsp;create-page.md | 698 | 698 | 0% | 100% |
| &nbsp;&nbsp;create-section.md | 2294 | 2279 | 0.7% | 100% |
| &nbsp;&nbsp;debug.md | 688 | 688 | 0% | 100% |
| &nbsp;&nbsp;figma-to-webflow.md | 4466 | 4377 | 2.0% | 100% |
| &nbsp;&nbsp;fix-responsive.md | 1790 | 1744 | 2.6% | 100% |
| &nbsp;&nbsp;fix-spacing.md | 1551 | 1546 | 0.3% | 100% |
| &nbsp;&nbsp;plan.md | 769 | 769 | 0% | 100% |
| &nbsp;&nbsp;publish.md | 1867 | 1857 | 0.5% | 100% |
| &nbsp;&nbsp;quality-gate.md | 2702 | 2702 | 0% | 100% |
| &nbsp;&nbsp;screenshot-to-webflow.md | 1478 | 1478 | 0% | 100% |
| &nbsp;&nbsp;security-review.md | 2743 | 2743 | 0% | 100% |
| &nbsp;&nbsp;set-variables.md | 1250 | 1250 | 0% | 100% |
| &nbsp;&nbsp;sync-cms.md | 2082 | 2077 | 0.2% | 100% |
| &nbsp;&nbsp;webflow-audit.md | 2282 | 2282 | 0% | 100% |
| **Rules (webflow)** | **11282** | **11282** | **0.0%** | 100% |
| &nbsp;&nbsp;class-naming.md | 2117 | 2117 | 0% | 100% |
| &nbsp;&nbsp;cross-site-portability.md | 4821 | 4821 | 0% | 100% |
| &nbsp;&nbsp;interactions.md | 1926 | 1926 | 0% | 100% |
| &nbsp;&nbsp;responsive.md | 2418 | 2418 | 0% | 100% |
| **Rules (common)** | **5979** | **5979** | **0.0%** | 100% |
| &nbsp;&nbsp;agents.md | 5979 | 5979 | 0% | 100% |
| **TOTAL** | **221957** | **216763** | **2.3%** | **100%** |

## Change Log

### webflow-orchestrator.md (−10.0%, the only meaningful win)
- Added prompt macros defined once in PER-AGENT CONTEXT with explicit expansion instruction:
  - `[CTX]` = `SITE: {SITE_NAME} | SITE_ID: {SITE_ID} | MCP_MODE: {true/false}` (13 uses)
  - `[HANDOFF]` = `Write build_handoff.json. Write STATUS: complete to session_state.md.` (13 uses)
  - `[REG]` = agent's registry-slice line from the single-source table (14 uses)
- Kept literal where macros would change content: A1 (has DOMAIN), A4/E2 variant handoff trailers (unique flag names), E2/A6 registry lines (intentionally differ from table).
- Micro-trims in prose; Pipeline E SEO note now points to Pipeline A note (rule text retained).

### Skills (−7.0%)
- class-system (−11.8%), cms-patterns (−10.6%), webflow-api (−9.3%): whitespace-only squeeze inside plain-text catalogue/endpoint-listing blocks (all names, endpoints, comments verbatim), markdown separator-row compression (`|---|` — renders identically), horizontal-rule removal, 2 verified verbatim dedups (endpoint lines, reflow suffix).
- figma-bridge (−4.1%), interactions (−2.4%): ~95% mapping tables + code — safely incompressible further.
- 4 small skills untouched (already minimal).

### Agents other than orchestrator (−0.5% avg)
- Only filler-word trims and true-duplicate sentence merges. Nearly all mass is protected: code blocks 38–80% of each file, plus tables, format specs, checklists, gates.

### Commands (−0.6%)
- Cosmetic markdown only (horizontal rules, separator rows) + 3 filler trims in figma-to-webflow. All PAUSE gates, publish warning, agent routings verbatim.

### Rules (0%)
- Preserved verbatim by design — non-negotiable guardrail canon.

## Validation Report

Automated structural diff v3.0 → v3.1 across all 52 .md files:
- [x] YAML frontmatter byte-identical in every file (routing descriptions untouched)
- [x] Code-fence counts equal in every file
- [x] Table data-row counts equal in every file
- [x] All pipelines A–N present; 9/9 verify gates; native-first gate (5 items); code-review gate; 5 human-confirmation points; production publish warning verbatim
- [x] All literal handoff strings intact: `STATUS: complete`, `build_handoff.json`, `design_spec_current.md`, session-state schema
- [x] Design Spec format parity figma-analyst ↔ screenshot-analyst intact
- [x] All numeric standards intact (durations, staggers, CWV thresholds, budgets, rate limits, 8-level traversal, ±15 color tolerance)
- [x] All output-format specs byte-identical (Design Spec, class plan, registry entries, review verdicts, FR docs, ADR, blast-radius map)
- [x] agents/ and .claude/agents/webflow/ copies re-synced identical
- [x] Incident during optimization: one pass briefly matched frontmatter delimiters in figma-analyst/interaction-builder — caught, restored, independently re-verified byte-identical

## Rejected as Unsafe (documented, per failure conditions)

- Minifying JSON example trees in webflow-builder (~4,000 chars) — output format spec
- Deduplicating quality-gate's 5 agent-prompt STATUS footers — risk of pipeline hang on wait-for-completion check
- Cross-file dedup against .claude/rules/*.md — agents load standalone; no include mechanism
- Parameterizing curl blocks — not verbatim repeats; shell word-splitting hazard
- Trimming Design Spec example rows, evidence lists, checklist items, severity taxonomies — protected categories

## How to Reach 15–25% (requires relaxing constraints — your call)

1. Permit JSON/example minification in webflow-builder + analysts (~6–8k chars)
2. Move duplicated reference content (responsive tables, BEM rules) into rules/ and allow agents to assume rules injection (~5k chars) — changes deployment assumption
3. Move large output-format examples to shared docs/formats/*.md referenced by path (~8k chars) — adds runtime file-read dependency

## Deployment

```bash
# Test copy already at ~/Downloads/webflow-agent-pack-v3.1
# To deploy over live agents:
cp ~/Downloads/webflow-agent-pack-v3.1/agents/*.md /path/to/project/.claude/agents/webflow/
# Or run the pack installer:
cd ~/Downloads/webflow-agent-pack-v3.1 && ./install.sh
```
v3.0 remains untouched at Ajay/My_Project/agent/webflow-agnet/webflow-agent-pack-v3.0 (rollback = keep using it).
